import{n as i}from"./index-DrMxwgAs.js";const a=i.div`
  .caseStudie {
    .row {
      border-bottom: 1px solid ${({theme:t})=>t.lightgray};
    }

    .caseStudieImg {
      max-width: 150px;
      max-height: 150px;
      width: 100%;
    }
  }

  .caseStudieDetails img {
    max-width: 150px;
    max-height: 150px;
    width: 100%;
  }

  .caseStudieDetails ul {
    margin: 25px;
    padding: 0;
  }
`;export{a as C};
