import{r as n,h as R,z as te,ad as ie,a8 as E,ae as G,af as L,ag as Y,j as e,T as J,t as oe,B as Z,A as de,L as T,v as $,y as k,a6 as re,ah as O,n as ue,e as pe,ai as ge,x as me,k as ee,a as fe,i as he,b as ve,aj as xe,Q as be,U as Se,E as se,l as we,V as ae,m as Ne,ak as ye,K as _e,d as je,M as Ce,a1 as Le,a2 as Ee}from"./index-DrMxwgAs.js";import{B as $e}from"./index-DpfQMTHo.js";import{D as ne}from"./DeleteDialog-BPphzh6L.js";import{g as ke,d as Fe}from"./menuUtil-BP39w6Ck.js";import{N as De}from"./index-ByNTAwhR.js";import"./Styled-PageBanner-BsuMNpbu.js";const Ie=({setSelectedServiceProject:g,selectedServiceProject:x,pageType:f})=>{const[l,o]=n.useState(""),[F,S]=n.useState(""),[D,s]=n.useState([]),[r,_]=n.useState(""),[j,M]=n.useState(""),I=n.useRef(!0),[A,C]=n.useState(!1),{serviceMenu:m,serviceerror:Q}=R(a=>a.serviceMenu),{menuList:w,menuRawList:H}=R(a=>a.auth),h=n.useRef(null),b=te(),B=ie(),V=a=>{S(""),o(a.target.value)};n.useEffect(()=>{M(E("userName"))},[]),n.useEffect(()=>{if(m.length>0){let a=G.filter(m,i=>{var c;return((c=i==null?void 0:i.page_url)==null?void 0:c.toLowerCase())!=="/services/addservices"});s(a)}else s(m)},[m]);async function N(a){if(l===""){S("Please Enter Service  name");return}let i="",c={services_page_title:l,created_by:j,pageType:f,publish:!!(r!=null&&r.publish)};try{if(r!=null&&r.id){const y=G.cloneDeep(r);c.id=r.id,c.updated_by=j,c.page_url=r.page_url,i=await $.put(`/services/updateService/${r.id}/`,c),z(i.data.services,!0,r.services_page_title),o(""),_({})}else c.page_url=`/services/${l.replace(/\s/g,"").toLowerCase()}`,i=await $.post("/services/createService/",c),z(i.data.services,!1,"");(i==null?void 0:i.status)===201||(i==null?void 0:i.status)===200?(k.success(`${l} service is created `),o(""),b(L()),g(i.data.services)):S(i.data.message)}catch{S(`${l} is already register`),k.error(`${l} is already register`)}}n.useEffect(()=>{(m==null?void 0:m.length)===0&&I.current&&(I.current=!1,b(L())),(m==null?void 0:m.length)===0&&(Y("pageLoadServiceID"),Y("pageLoadServiceName"))},[m]);const p=async a=>{try{let i=await $.patch(`/services/publishService/${a.id}/`,{publish:!a.publish});if(i.status===200){let c=i.data.services;k.success(`Service ${c.publish?"published":"un published"} successfully`),g(i.data.services),b(L())}}catch{console.log("unable to publish the services")}},P=a=>{K(),a.id;const i=a.services_page_title,c=async()=>{(await $.delete(`/services/updateService/${a.id}/`)).status===204&&(await Fe(a.menu_ID),b(L()),b(O()),k.success(`${i} is deleted`))};re.confirmAlert({customUI:({onClose:y})=>e.jsx(ne,{onClose:y,callback:c,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:i})," Service?"]})})})},U=a=>{o(a==null?void 0:a.services_page_title),_(a),C(!0),h.current&&h.current.focus()},K=()=>{o(""),_({}),C(!1)},z=async(a,i,c)=>{await ke(w,B,a,i,c),b(L()),b(O())};return e.jsxs("div",{className:"pb-3 border border-0",children:[e.jsx(J,{title:"Create New Service Page",cssClass:"p-3 fs-6 text-dark"}),e.jsx("hr",{className:"m-0 mb-5"}),e.jsx("div",{className:"container",children:e.jsxs("div",{className:"row",children:[F?e.jsx(oe,{children:F}):"",e.jsxs("div",{className:`col-md-6 pb-2 pb-md-0 
          d-flex flex-column justify-content-start align-items-center 
          text-center 
          addPageForm`,children:[e.jsx("input",{type:"text",className:`form-control py-4 text-center fs-4  ${A?"border border-warning text-warning":""}`,name:"services_page_title",id:"",value:l,placeholder:"Add Service Name",onChange:V,ref:h}),e.jsxs("div",{className:"d-flex gap-2",children:[e.jsx(Z,{type:"submit",cssClass:"btn btn-secondary mt-3",handlerChange:N,label:r!=null&&r.id?"Change Name":"Save"}),r!=null&&r.id?e.jsx(Z,{cssClass:"btn btn-primary mt-3",handlerChange:K,label:"Cancel"}):""]})]}),e.jsx("div",{className:"col-md-6 servicePageLinks",children:e.jsx("ul",{children:D&&D.map(a=>e.jsxs("li",{className:`d-flex justify-content-between align-items-center p-1 px-3
                     ${A&&a.id===(r==null?void 0:r.id)?"border border-warning":""} 
              ${a.id===(x==null?void 0:x.id)?"border border-1 border-info shadow-md":""}`,children:[e.jsx("div",{className:"w-50",children:e.jsx(de,{Ancherpath:a.page_url,AncherClass:"text-dark pageTitle",handleModel:"",AncherLabel:a.services_page_title})}),e.jsxs("div",{className:"w-50 text-end",children:[e.jsx(T,{onClick:()=>p(a),title:a.publish?"Page Published":"Page Not Published",children:a.publish?e.jsx("span",{className:"text-success fs-5 fw-bold",children:"P"}):e.jsx("span",{className:"fs-5 fw-bold notPublished",children:"P"})}),e.jsxs(T,{onClick:()=>U(a),children:[" ",e.jsx("i",{className:"fa fa-pencil text-warning fs-5 mx-3","aria-hidden":"true"})]}),e.jsxs(T,{onClick:()=>P(a),children:[" ",e.jsx("i",{className:"fa fa-trash-o text-danger fs-5","aria-hidden":"true"})]})]})]},a.id))})})]})})]})},Ae=ue.div`
    background-color: ${({theme:g})=>g.white};

    .services {
      ul, ol {
        margin: 40px 25px;

        li {
            padding: 15px;
          }
      }
    }
      
      .services ul 
      
      .normalCSS,
      .flipCSS {
      }
      
      .flipCSS {
        flex-direction: row-reverse;
      }
      
      .servicesPage {
        ul, ol {
            margin: 15px 10px;

            li {
                border-bottom: 1px solid ${({theme:g})=>g.lightgray};
                padding: 12px 7px;
              }
        }

        img {
            object-fit: cover;
            object-position: center;
            width: 100%;
            // height: 100%;
        }
      }
      
      
      
      .servicePageLinks {

        // width: 600px; 
        // margin: 0 auto;
        height: 120px;
        overflow-y: scroll;
}
        
        li {
            cursor: pointer;

            span.notPublished {
              color: #ccc !important;
            }
          }

        .pageTitle {
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
            overflow: hidden;
            // height: 20px;
          }
      }
      
      .addPageForm {
        // background-color: ${({theme:g})=>g.teritoryColor};
        // width: 600px; 
        // margin: 0 auto;
      }

      .servicePageLinks {
        background-color: ${({theme:g})=>g.white};
      }

      
`,Ve=()=>{var c,y,q,W;const g={addSection:!1,editSection:!1,banner:!1,briefIntro:!1},x="services",{isAdmin:f,hasPermission:l}=pe(),[o,F]=n.useState(g),[S,D]=n.useState(!1),[s,r]=n.useState({}),[_,j]=n.useState([]),[M,I]=n.useState(),[A,C]=n.useState({});let{uid:m}=ge();const Q=me();E("pageLoadServiceID");const w=E("pageLoadServiceName");E("pageLoadServiceURL");const H=ie(),{serviceMenu:h,serviceerror:b}=R(t=>t.serviceMenu);n.useEffect(()=>{const t=H.pathname;if(t&&h.length>0){const d=G.filter(h,u=>{var v;return((v=u==null?void 0:u.page_url)==null?void 0:v.toLowerCase())===t})[0];d?(ee(d),r(d)):(ee(h[0]),r(h[0])),j([])}},[H,h]),n.useEffect(()=>{const t=document.getElementById("ServicesnavbarDropdown");t&&t.classList.add("active")}),n.useEffect(()=>{fe()},[]),n.useEffect(()=>{s!=null&&s.id&&(C({serviceID:s?s==null?void 0:s.id:"",services_page_title:s?s==null?void 0:s.services_page_title:""}),I(he(s==null?void 0:s.services_page_title)),B(s.id))},[s]);const B=async t=>{if(!t&&!E("access")){Q("/");return}try{let d=await ve.get(`/services/getSelectedClientService/${t}/`);const u=xe(d.data.servicesFeatures);j(u)}catch{console.log("Unable to get the intro")}},V=t=>{const d=t.id,u=t.feature_title,v=async()=>{if((await $.delete(`/services/updateFeatureService/${d}/`)).status===204){const ce=_.filter(le=>le.id!==d);j(ce),k.success(`${u} is deleted`)}};re.confirmAlert({customUI:({onClose:X})=>e.jsx(ne,{onClose:X,callback:v,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:u})," Service?"]})})})};n.useEffect(()=>{!o.editSection&&!o.addSection&&(s==null?void 0:s.id)!==void 0&&B(s.id)},[o.editSection,o.addSection]);const N=(t,d,u)=>{if(F(v=>({...v,[t]:d})),D(!S),u!=null&&u.id){let v=u;v.services_page_title=s==null?void 0:s.services_page_title,C(v)}document.body.style.overflow="hidden"},[p,P]=n.useState([]),U=te(),{error:K,success:z,showHideList:a}=R(t=>t.showHide);n.useEffect(()=>{a.length>0&&P(be(a))},[a]);const i=async(t,d)=>{if(t)U(Le(t));else{const u={componentName:d.toLowerCase(),pageType:x};U(Ee(u))}};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:(c=p==null?void 0:p.servicebanner)!=null&&c.visibility&&f&&l?"border border-info mb-2":"",children:[f&&l&&e.jsx(Se,{showhideStatus:(y=p==null?void 0:p.servicebanner)==null?void 0:y.visibility,title:"Banner",componentName:"servicebanner",showHideHandler:i,id:(q=p==null?void 0:p.servicebanner)==null?void 0:q.id}),((W=p==null?void 0:p.servicebanner)==null?void 0:W.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[f&&l&&e.jsx(se,{editHandler:()=>N("banner",!0)}),e.jsx($e,{getBannerAPIURL:`banner/clientBannerIntro/${x}-${w}-banner/`,bannerState:o.banner,pageLoadServiceName:w})]}),o.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:N,componentType:"banner",popupTitle:`Service ${w?"-"+w:""} Banner`,pageType:`${x}-${w}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:Ne(`${x}-${M}-banner`),dimensions:ae("banner")})})]})]}),e.jsxs(Ae,{children:[f&&l&&e.jsx(Ie,{setSelectedServiceProject:r,selectedServiceProject:s,pageType:"service"}),e.jsx("div",{className:f&&l?"container-fluid my-md-3 servicesPage":"container my-md-3 servicesPage",id:"servicesPage",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12",children:[f&&l&&(s==null?void 0:s.id)&&s.page_url!=="/services/addservices"&&e.jsxs("div",{className:"d-flex justify-content-center align-items-center my-4 p-2 border border-info",children:[e.jsxs("span",{className:"mx-2 text-dark",children:[" ","Add new section in",e.jsx("span",{className:"text-dark fw-bold mx-1",children:s.services_page_title}),"page"]}),e.jsx("button",{type:"submit",className:"btn btn-outline px-3",onClick:()=>N("addSection",!0),children:e.jsx("i",{className:"fa fa-plus","aria-hidden":"true"})})]}),o.editSection||o.addSection?e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(De,{editHandler:N,category:"services",editCarousel:A,setEditCarousel:C,componentType:`${o.editSection?"editSection":"addSection"}`,imageGetURL:"services/createServiceFeatures/",imagePostURL:"services/createServiceFeatures/",imageUpdateURL:"services/updateFeatureService/",imageDeleteURL:"services/updateFeatureService/",imageLabel:"Add Service Banner",showDescription:!1,showExtraFormFields:ye(s?s==null?void 0:s.id:"",s?s==null?void 0:s.services_page_title:"",s?s==null?void 0:s.page_url:""),dimensions:ae("addService")})}):"",e.jsx("div",{className:"row ",children:e.jsx("div",{className:"col-12 col-md-8"})}),_.map((t,d)=>e.jsxs("div",{className:`row mb-5 my-md-5 ${f?"border border-warning mb-3 position-relative":"border border-md-1"} ${d%2===0?"normalCSS":"flipCSS"}`,children:[f&&l&&e.jsxs(e.Fragment,{children:[e.jsx(se,{editHandler:()=>N("editSection",!0,t)}),e.jsx(T,{className:"deleteSection",onClick:()=>V(t),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:"col-md-8 p-4",children:[t.feature_title&&e.jsx(J,{title:t.feature_title?t.feature_title:"Update Feature title",cssClass:"fs-3 fw-medium "}),t.feature_sub_title&&e.jsx(J,{title:t.feature_sub_title?t.feature_sub_title:"Update Feature sub title",cssClass:"fs-5 text-secondary mb-2"}),t.feature_description&&e.jsx(_e,{data:t.feature_description,className:"",showMorelink:!1})]}),e.jsx("div",{className:"col-md-4 p-0",children:e.jsx("img",{src:je(t.path),alt:"",className:"h-100 "})})]},t.id))]})})})]}),S&&e.jsx(Ce,{})]})};export{Ve as default};
