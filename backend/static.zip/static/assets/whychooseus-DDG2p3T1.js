import{n as $,r as c,j as e,d as M,w as E,b as C,e as k,E as f,l as T,V as F,a7 as U,z as R,h as W,Q as O,a as z,U as B,m as J,X as Q,Y as V,M as X,a1 as Y,a2 as _}from"./index-DrMxwgAs.js";import{B as q}from"./index-DpfQMTHo.js";import"./Styled-PageBanner-BsuMNpbu.js";const G=$.div`
    
    .IconsMainKeys {
        padding: 16px;
        // background-color: ${({theme:i})=>i.clientColor};
    //    background: linear-gradient(163deg,rgba(109, 47, 155, 0.76) 0%, rgba(1, 32, 96, 0.7) 40%);
       background: linear-gradient(163deg,rgba(1, 32, 96, 0.80) 0%, rgba(109, 47, 155, 0.9) 50%);
        color: ${({theme:i})=>i.white};
        margin-bottom: 32px;
        border-radius: 8px;
        // box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .10) !important;
        
    }

    .keyPoint {
        background:rgba(255, 255, 255, 0.75);
        border-radius: 50%;
        box-shadow: 0 .5rem 3rem rgba(0, 0, 0, .50) !important;
        width: 80px;
        height: 80px;
        display: flex;
        justify-content: center;
        align-items: center;
        img {
            width: 48px;
        }
    }
`,Z=({getBannerAPIURL:i,keyPointsState:l,imageCss:t=""})=>{const[o,r]=c.useState([]),[n,m]=c.useState([]);return c.useEffect(()=>{l||(async()=>{try{const d=await C.get(i);(d==null?void 0:d.status)===200?m(d.data.imageModel):m({})}catch{m({}),console.log("unable to access ulr because of server is down")}})()},[l,i]),e.jsx(G,{children:e.jsx("div",{className:"container-fluid",children:e.jsxs("div",{className:"row IconsMainKeys",children:[e.jsx("div",{className:"col-md-2 p-2 d-flex align-items-center keyPoint",children:n.path?e.jsx("img",{src:n!=null&&n.path?M(n.path):E(),alt:n==null?void 0:n.alternitivetext,className:t}):e.jsx("img",{src:E(),className:t})}),e.jsx("div",{className:"col-md-10 p-2 d-flex align-items-center",children:n==null?void 0:n.banner_title})]})})})},H=({editHandler:i,objectstatus:l,pageType:t})=>{const{isAdmin:o,hasPermission:r}=k();return e.jsxs("div",{className:"position-relative",children:[o&&r&&e.jsx(f,{editHandler:()=>i(t,!0)}),e.jsx(Z,{getBannerAPIURL:`banner/clientBannerIntro/${t}/`,keyPointsState:l}),l&&e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(T,{editHandler:i,componentType:t,pageType:t,imageLabel:"Key Points",showDescription:!1,showExtraFormFields:U(t),dimensions:F("banner")})})]})},ie=()=>{var g,p,j,w,v,S,I,N;const i={banner:!1,briefIntro:!1,dynamickeypoints1:!1,dynamickeypoints2:!1,dynamickeypoints3:!1,dynamickeypoints4:!1,dynamickeypoints5:!1,dynamickeypoints6:!1},l=R(),t="whychooseus",{isAdmin:o,hasPermission:r}=k(),[n,m]=c.useState(i),[y,d]=c.useState(!1),[s,K]=c.useState([]),P=[1,2,3,4,5,6],{error:L,success:ee,showHideList:b}=W(a=>a.showHide);c.useEffect(()=>{b.length>0&&K(O(b))},[b]);const x=async(a,u)=>{if(a)l(Y(a));else{const D={componentName:u.toLowerCase(),pageType:t};l(_(D))}};c.useEffect(()=>{window.scrollTo(0,0)},[]),c.useEffect(()=>{z()},[]);const h=(a,u,D)=>{m(A=>({...A,[a]:u})),d(!y),document.body.style.overflow="hidden"};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:(g=s==null?void 0:s.whychooseusbanner)!=null&&g.visibility&&o&&r?"border border-info mb-2":"",children:[o&&r&&e.jsx(B,{showhideStatus:(p=s==null?void 0:s.whychooseusbanner)==null?void 0:p.visibility,title:"Banner",componentName:"whychooseusbanner",showHideHandler:x,id:(j=s==null?void 0:s.whychooseusbanner)==null?void 0:j.id}),((w=s==null?void 0:s.whychooseusbanner)==null?void 0:w.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[o&&r&&e.jsx(f,{editHandler:()=>h("whychooseus",!0)}),e.jsx(q,{getBannerAPIURL:`banner/clientBannerIntro/${t}-banner/`,bannerState:n.whychooseus})]}),n.whychooseus&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(T,{editHandler:h,componentType:"whychooseus",popupTitle:"Why Choose US",pageType:`${t}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:J(`${t}-banner`),dimensions:F("banner")})})]})]}),e.jsxs("div",{className:(v=s==null?void 0:s.whychooseusbriefintro)!=null&&v.visibility&&o&&r?"border border-info mb-2":"",children:[o&&r&&e.jsx(B,{showhideStatus:(S=s==null?void 0:s.whychooseusbriefintro)==null?void 0:S.visibility,title:"A Brief Introduction Component",componentName:"whychooseusbriefintro",showHideHandler:x,id:(I=s==null?void 0:s.whychooseusbriefintro)==null?void 0:I.id}),((N=s==null?void 0:s.whychooseusbriefintro)==null?void 0:N.visibility)&&e.jsxs("div",{className:"breiftopMargin",children:[o&&r&&e.jsx(f,{editHandler:()=>h("briefIntro",!0)}),e.jsx(Q,{introState:n.briefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center",detailsContainerCss:"col-md-10 offset-md-1 py-3",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:t}),n.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(V,{editHandler:h,componentType:"briefIntro",popupTitle:"Why Choose us Brief Intro",pageType:t})})]})]}),e.jsx("div",{className:"container my-5",children:e.jsx("div",{className:"row",children:P.map(a=>e.jsx("div",{className:"col-md-6",children:e.jsx(H,{editHandler:h,objectstatus:n[`dynamickeypoints${a}`],pageType:`dynamickeypoints${a}`})},a))})}),y&&e.jsx(X,{})]})};export{ie as default};
