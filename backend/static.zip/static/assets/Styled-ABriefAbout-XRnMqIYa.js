import{e as S,r as a,j as r,d as E,E as F,T as l,A as B,l as C,m as L,M as k,b as I,n as _}from"./index-DrMxwgAs.js";import{C as N}from"./ContactForm-DpKhs2Pk.js";const H=({cssClass:s,col1:c,col2:p,imageClass:x,dimensions:h,pageType:i="HomeWhoWeAre",componentFlip:T=!1,showForm:g=!1,categoryId:u})=>{const b={whoweare:!1},{isAdmin:f,hasPermission:w}=S(),[o,j]=a.useState(b),[d,A]=a.useState(!1),[e,v]=a.useState(""),m=(n,t)=>{j(y=>({...y,[n]:t})),A(!d),document.body.style.overflow="hidden"};return a.useEffect(()=>{const n=async()=>{try{const t=await I.get(`banner/clientBannerIntro/${i}/`);(t==null?void 0:t.status)===200&&v(t.data.imageModel)}catch{console.log("unable to access ulr because of server is down")}};o.whoweare||n()},[o.whoweare]),r.jsxs(r.Fragment,{children:[r.jsx("div",{className:`${c}`,children:r.jsx("img",{src:E(e==null?void 0:e.path),alt:"",className:x})}),r.jsxs("div",{className:`${p}`,children:[f&&w&&r.jsx(F,{editHandler:()=>m("whoweare",!0)}),e!=null&&e.banner_title?r.jsx(l,{title:e.banner_title,cssClass:s}):"",e.banner_subTitle?r.jsx(l,{title:e.banner_subTitle,cssClass:"fs-6 my-3"}):"",r.jsx("div",{children:r.jsx("p",{className:"lh-md",children:e!=null&&e.banner_descripiton?e.banner_descripiton:"Update description"})}),g&&r.jsx(N,{categoryId:u}),e.moreLink?r.jsx("div",{children:r.jsx(B,{AncherLabel:"more...",Ancherpath:e.moreLink?e.moreLink:"",AncherClass:"moreLink d-flex justify-content-center align-items-center gap-3",AnchersvgColor:"#ffffff"})}):""]}),o.whoweare&&r.jsx("div",{className:"adminEditTestmonial selected",children:r.jsx(C,{editHandler:m,componentType:"whoweare",pageType:i,popupTitle:"Who We Are Banner",imageLabel:"Banner Image",showDescription:!1,dimensions:h,showExtraFormFields:L(i)})}),d&&r.jsx(k,{})]})},M=_.div`
    .productForm {
        background: rgb(225,242,253);
        background: linear-gradient(90deg, rgba(225,242,253,1) 0%, rgba(255,255,255,1) 50%, rgba(225,242,253,1) 100%);
    }

    .randomServices {
        margin-top: 96px;
        margin-bottom: 96px;

        @media(max-width: 768px) {
            margin-top: 48px;
            margin-bottom: 48px;
        }

        img {
            height: 300px;
            // filter: grayscale(100%);
            transition: filter 0.3s ease-in-out, transform 0.3s ease-in-out;
            
            @media(max-width: 768px) {
                height: 200px;
            }

            &:hover {
                // filter: grayscale(0%);
                transform: scaleX(1.05);
            }
        }

        .imgStylingLeft {
            border-radius: 12px;
            // border-top-right-radius: 30px;
            // border-bottom-right-radius: 30px;

            // @media(max-width: 768px) {
            //     border-radius: 10px
            // }
        }

        .imgStylingRight {
            border-radius: 12px;
            // border-top-left-radius: 30px;
            // border-bottom-left-radius: 30px;

            // @media(max-width: 768px) {
            //     border-radius: 10px
            // }
        }
    }

    
    

    form {
        // padding: 30px 50px;
        border-radius: 15px;
        border: 1px solid ${({theme:s})=>s.lightgray};
        // background: ${({theme:s})=>s.white};

        @media(max-width: 576px) {
            padding: 30px;   
        }
    }
`;export{M as A,H as a};
