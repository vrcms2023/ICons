import{n as z,ad as V,h as G,e as S,r as l,j as e,A as q,aH as J,T as $,L as w,d as M,K as L,M as D,b as K,aa as W,ab as X,aJ as Z,a6 as Q,v as ee,am as se}from"./index-DrMxwgAs.js";import{D as ae}from"./DeleteDialog-BPphzh6L.js";import{N as te}from"./index-ByNTAwhR.js";import{D as ne,C as ie,P as oe}from"./dnd.esm-hB_vzQGM.js";import{S as le}from"./SkeltonNews-DsHR9DP8.js";const re=z.div`
  .card {
    position: relative;
    min-height: 440px;
    background-color: ${({theme:s})=>s.newsCardBg};
    color: ${({theme:s})=>s.newsCardTextColor};
    margin-bottom: 30px;
    border-radius: 0px;
    border: 1px solid ${({theme:s})=>s.grayddd};
    // overflow: hidden;

    .ql-editor {
      padding: 0 !important;
    }

    .cardInfo {
      h5 {
        font-size: 1.1rem !important;
        color: ${({theme:s})=>s.gray444};
      }
      .newsDate {
        color: ${({theme:s})=>s.clientSecondaryColor};
      }

      a {
        font-size: .9rem
        position: absolute;
      }
    }

    .title {
      color: ${({theme:s})=>s.newsCardTitleColor};
    }

    img {
      // height: 160px;
      // width: 100%;
      // object-fit: cover;
      // object-position: bottom;
    }

    .card-body {
      // a {
      //     color:${({theme:s})=>s.primaryColor} !important;

      //     &:hover {
      //         color:${({theme:s})=>s.secondaryColor} !important;
      //     }
      // }
    }
    
  }
  .homeNews img {
    height: 240px;
    width: 100%;
    object-fit: cover;
  }
  .adminView {
    img {
      width: 80px !important;
      height: 80px;
    }

    .moreLink {
      font-size: .9rem
    }
  }
`,we=({addNewsState:s,news:r,setNews:c,setResponseData:f,pagetype:m,searchQuery:t,setNewsEditState:x})=>{const d=V(),N={news:!1},{isLoading:u}=G(n=>n.loader),{isAdmin:k,hasPermission:I}=S(),[g,_]=l.useState(N),[b,E]=l.useState(!1),[T,C]=l.useState({}),[p,P]=l.useState({}),[F,v]=l.useState(!1),[R,y]=l.useState(!1),A=(n,a,i)=>{C(i),_(o=>({...o,[n]:a})),E(!b),x(!a),document.body.style.overflow="hidden"};l.useEffect(()=>{const n=async()=>{try{const a=await K.get("/appNews/clientAppNews/");(a==null?void 0:a.status)===200&&(m==="home"?c(a==null?void 0:a.data):f(a==null?void 0:a.data))}catch{console.log("unable to access ulr because of server is down")}};(g.news||!s)&&!t&&n()},[g.news,s,m,t]);const U=(n,a)=>{const i=async()=>{if((await se.delete(`appNews/updateAppNews/${n}/`)).status===204){const j=r.filter(h=>h.id!==n);c(j)}};Q.confirmAlert({customUI:({onClose:o})=>e.jsx(ae,{onClose:o,callback:i,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:a})," News?"]})})})},H=n=>{P(n),v(!0),y(!0)},B=()=>{v(!1),y(!1)},O=async n=>{const{source:a,destination:i}=n;if(!i)return!0;const o=W(r,a.index,i.index),j=X(o,"news_position"),h=await Y(j);h.length>0&&c(h)},Y=async n=>{var a;try{let i=await ee.put("/appNews/updateNewsIndex/",n);if((a=i==null?void 0:i.data)!=null&&a.appNews)return i.data.appNews}catch{console.log("unable to save news position")}};return e.jsxs(e.Fragment,{children:[u?e.jsx("div",{className:"row",children:[1,2,3,4].map((n,a)=>e.jsx("div",{className:"col-md-6 col-lg-3 mb-4 mb-lg-0",children:e.jsx(le,{})},a))}):"",e.jsx(ne,{onDragEnd:O,children:e.jsx(ie,{droppableId:"NewsList",id:"newsList",children:(n,a)=>e.jsxs("div",{className:"row",ref:n.innerRef,...n.droppableProps,children:[r.length>0?r.map((i,o)=>e.jsx(ce,{item:i,index:o,handleModel:H,DeleteNews:U,editHandler:A},i.id)):e.jsx("div",{className:"text-center",children:k&&I?e.jsx(e.Fragment,{children:d.pathname==="/news"?e.jsx("p",{className:"text-center fs-6",children:"Please add news items"}):e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"text-center fs-6",children:"Currently there are no news items found."}),e.jsx(q,{AncherLabel:"Go To News",Ancherpath:"/news",AncherClass:"btn btn-secondary d-flex justify-content-center align-items-center gap-3",AnchersvgColor:"#ffffff"})]})}):e.jsx("p",{className:"text-center fs-6",children:!u&&"Currently there are no news items found."})}),n.placeholder]})})}),g.news&&e.jsx("div",{className:"adminEditTestmonial  selected",children:e.jsx(te,{editHandler:A,editCarousel:T,setEditCarousel:C,componentType:"news",popupTitle:"Edit News",imageGetURL:"appNews/createAppNews/",imagePostURL:"appNews/createAppNews/",imageUpdateURL:"appNews/updateAppNews/",imageDeleteURL:"appNews/updateAppNews/",imageLabel:"Add News Image",showDescription:!1,showExtraFormFields:J()})}),F?e.jsx("div",{className:"newsModel ",children:e.jsxs("div",{className:"newsModalWrapper p-4 bg-white shadow-lg",children:[e.jsxs("div",{className:"d-flex justify-content-between align-items-center gap-4 mb-1 pb-2 border-bottom",children:[e.jsx($,{title:p.news_title,cssClass:"fw-medium"}),e.jsx(w,{onClick:B,className:"text-secondary ",children:e.jsx("i",{className:"fa fa-times fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:"my-3 newsDetails",children:[e.jsx("img",{className:"w-100 mb-3",style:{height:"240px",objectFit:"cover"},src:M(p.path),alt:p.news_title}),p.news_description?e.jsx(L,{data:p.news_description,className:"",showMorelink:!1}):"update new description"]})]})}):"",R&&e.jsx(D,{}),b&&e.jsx(D,{})]})},ce=({item:s,index:r,handleModel:c,DeleteNews:f,editHandler:m})=>{const{isAdmin:t,hasPermission:x}=S();return e.jsx(oe,{isDragDisabled:!t,index:r,draggableId:s.id,id:s.id,children:d=>e.jsx("div",{className:`${t?"col-12":"col-sm-6 col-lg-3 px-2 px-md-4 px-lg-3"} image`,ref:d.innerRef,...d.draggableProps,children:e.jsx("div",{className:`col-md-12 col-lg-12 ${t?"px-3":""}`,children:e.jsx(re,{children:e.jsx("div",{className:`card homeNews ${t?"adminView":""}`,style:{minHeight:t?"auto":""},children:e.jsxs("div",{className:`${t?"d-flex align-items-center p-2 px-3 mb-3 border":""} `,children:[!t&&e.jsx("img",{src:M(s.path),className:"img-fluid",alt:s.alternitivetext}),t&&x?e.jsx("i",{className:"fa fa-bars text-secondary","aria-hidden":"true",...d.dragHandleProps}):"",e.jsxs("div",{className:"cardInfo",style:{display:"flex",justifyContent:"space-between"},children:[e.jsxs("div",{className:`${t?"px-3":"p-3"}`,children:[e.jsx($,{title:s.news_title?s.news_title:"Update news Title",cssClass:`fs-6 lineClamp lc2 ${!t&&"fw-bold"}`,mainTitleClassess:` fw-medium lh-sm lineClamp lc1 ${t?"fs-6":"fs-5"}`,subTitleClassess:""}),!t&&e.jsx("small",{className:"d-block mb-3 newsDate",children:Z(s.created_at).format("MMM DD, YYYY")}),!t&&e.jsx("div",{className:`card-text  ${t?"mb-0":"mb-2"}`,children:s.news_description?e.jsx(L,{data:s==null?void 0:s.news_description,className:`lineClamp ${t?"lc1":"lc2"}`,showMorelink:!1}):"update new description"}),e.jsx(w,{className:"moreLink",onClick:()=>c(s),children:"More.."})]}),t&&x&&e.jsxs("div",{className:"d-flex justify-content-end gap-2",children:[e.jsx(w,{onClick:()=>m("news",!0,s),className:" p-2",children:e.jsx("i",{className:"fa fa-pencil fs-5 text-warning","aria-hidden":"true"})}),e.jsx(w,{onClick:N=>f(s.id,s.news_title),className:"p-2",children:e.jsx("i",{className:"fa fa-trash-o fs-5 text-danger","aria-hidden":"true"})})]})]})]})})})},s.id)})},s.id)};export{we as H};
