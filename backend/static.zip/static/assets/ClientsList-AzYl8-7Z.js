import{n as ee,h as O,j as e,S as te,aa as ie,ab as ne,e as z,E as w,L as se,d as ae,T as q,K as oe,v as K,r,b as le,z as re,Q as ce,U as $,l as de,V as _,m as me,X as pe,Y as xe,aw as ge,p as ue,at as fe,a1 as be,a2 as he,a6 as je,y as ye}from"./index-DrMxwgAs.js";import{D as Se}from"./DeleteDialog-BPphzh6L.js";import{N as ve}from"./index-ByNTAwhR.js";import{S as Ce}from"./index-DSjIgb-e.js";import{C as we}from"./CustomPagination-B7rpvrGc.js";import{D as Ne,C as Le,P as De}from"./dnd.esm-hB_vzQGM.js";import{N as Ie}from"./NoteComponent-ck7yItQ5.js";import{B as Ae}from"./index-DpfQMTHo.js";import"./Styled-PageBanner-BsuMNpbu.js";const M=ee.div`
  // .clients hr:last-child {
  //   display: none;
  // }
  .clientAvatar{

     img {
      width: auto;
      height: 100px;
      object-fit: contain;
    }
  }
 
  .clientFrontend  {
    // border-radius: 10px;
    
    .details p {
      margin: 0px
    }

    &.overlayContainer {
      //background: ${({theme:n})=>n.primaryColor};
      border: 1px solid ${({theme:n})=>n.grayddd};
      border-radius: 2px;
      position: relative;
      // width: 50%;
      // max-width: 300px;
      // min-height: 200px;
    }
    
    /* Make the image to responsive */
    .image {
      display: block;
      // width: 100%;
      // height: auto;
    }
  
    // .overlay {
    //   position: absolute;
    //   bottom: 0;
    //   left: 0;
    //   background: rgb(0, 0, 0);
    //   background: rgba(0, 0, 0, .8); /* Black see-through */
    //   color: #f1f1f1;
    //   width: 100%;
    //   transition: .5s ease;
    //   opacity:0;
    //   color: white;
    //   font-size: 20px;
    //   padding: 20px;
    //   // border-radius: 10px;
    //   height: 100%;
    //   max-height: 250px;
    //   overflow-y: auto;
    //   visibility: visible !important;
    //   display: flex;
    //   flex-direction: column;
    //   justify-content: center;
    //   align-items: center;


    //   &::before {
    //     font-size: 3rem;
    //     position: sticky;
    //     right: 15px !important;
    //     top: -10px;
    //     color: rgba(255, 165, 0, .8);  
    //     display: block;
    //     width: 100%;  
    //   }

    //   &::-webkit-scrollbar {
    //     width: 8px;
    //   }
      
    //   &::-webkit-scrollbar-track {
    //       -webkit-box-shadow: inset 0 0 6px rgba(225,242,253,0.3); 
    //       border-radius: 3px;
    //   }
      
    //   &::-webkit-scrollbar-thumb {
    //       border-radius: 10px;
    //       -webkit-box-shadow: inset 0 0 6px rgba(232,252,187,0.5); 
    //   }
      
    // }

    p {
      font-size: .9rem;
      margin: 5px 0 !important;
      font-family: poppins
    }
  
    &.overlayContainer:hover .overlay {
      opacity: 1;
    }
  }

  .clientAdmin .details {
    display: flex;
    flex-direction: row;
    gap: 15px;
    flex-wrap: wrap;
  }
  .quill .ql-editor {
    padding: 0px;
  }
`,ke=({clientsList:n,setClientsList:c,deleteAboutSection:o,editHandler:d})=>{const{isLoading:s}=O(a=>a.loader),h=async a=>{const{source:p,destination:l}=a;if(!l)return!0;const b=ie(n,p.index,l.index),j=ne(b,"client_position"),u=await g(j);u.length>0&&c(u)},g=async a=>{var p;try{let l=await K.put("/client/updateindex/",a);if((p=l==null?void 0:l.data)!=null&&p.clientLogo)return l.data.clientLogo}catch{console.log("unable to save clinet position")}};return e.jsx("div",{children:e.jsx(M,{children:e.jsxs("div",{className:"clients my-5",children:[s&&e.jsx("div",{className:"",children:[1,2,3,4].map((a,p)=>e.jsx("div",{className:"col-12",children:e.jsx(te,{})},p))}),e.jsx(Ne,{onDragEnd:h,children:e.jsx(Le,{droppableId:"clientList",id:"clientList",children:(a,p)=>e.jsxs("div",{className:"row",ref:a.innerRef,...a.droppableProps,children:[(n==null?void 0:n.length)>0?n.map((l,b)=>e.jsx(Te,{item:l,index:b,editHandler:d,deleteAboutSection:o},b)):e.jsx("div",{className:"text-center text-muted py-5",children:!s&&e.jsx("p",{children:"Please add page contents..."})}),a.placeholder]})})})]})})})},Te=({item:n,index:c,editHandler:o,deleteAboutSection:d})=>{const{isAdmin:s,hasPermission:h}=z();return e.jsx(De,{isDragDisabled:!s,draggableId:n.id,index:c,id:n.id,children:g=>e.jsx("div",{className:`${s?"col-12 clientAdmin":"col-md-3 clientFrontend "} image`,ref:g.innerRef,...g.draggableProps,...g.dragHandleProps,children:e.jsxs("div",{className:`mb-3 ${s?"border border-warning mb-3 position-relative":"clientFrontend overlayContainer p-3 d-flex justify-content-center aling-items-center flex-column"} ${c%2===0?"normalCSS":"flipCSS"}`,children:[s&&h&&e.jsxs(e.Fragment,{children:[e.jsx(w,{editHandler:()=>o("editSection",!0,n)}),e.jsx(se,{className:"deleteSection",onClick:()=>d(n),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:`${s?"d-md-flex p-3":"d-flex justify-content-center align-items-center flex-column"}`,children:[e.jsx("div",{className:"text-center clientAvatar",children:e.jsx("img",{src:ae(n.path),alt:"",className:"img-fluid  mb-3"})}),e.jsxs("div",{className:"mt-1 d-flex justify-content-center align-items-center justify-content-md-center align-items-md-start flex-column  clientDetails ",children:[n.client_title&&e.jsx(q,{title:n.client_title,cssClass:"fs-5 text-start"}),n.client_description&&e.jsx(oe,{data:n.client_description,className:"details ",showMorelink:!1})]})]})]},n.id)})},n.id)},Ke=()=>{var A,k,T,E,F,R,P,B;const n={banner:!1,briefIntro:!1,addSection:!1,editSection:!1},c="clients",{isAdmin:o,hasPermission:d}=z(),[s,h]=r.useState(n),[g,a]=r.useState([]),[p,l]=r.useState(!1),[b,j]=r.useState({}),[u,Q]=r.useState({}),[V,G]=r.useState(!1),[y,J]=r.useState(""),[X,N]=r.useState(1),S=t=>{var x;if(((x=t==null?void 0:t.results)==null?void 0:x.length)>0){const m=ue(t.results,"client_position");a(m),Q(fe(t)),N(1)}else a(t.clientLogo)};r.useEffect(()=>{(!s.addSection||!s.editSection)&&!y&&L()},[s.addSection,s.editSection]);const L=async()=>{try{const t=await le.get("/client/getAllClientLogos/");(t==null?void 0:t.status)===200&&S(t.data)}catch{console.log("unable to access ulr because of server is down")}};r.useEffect(()=>{const t=document.getElementById("KnowledgeHubnavbarDropdown");t&&t.classList.add("active")});const f=(t,x,m)=>{h(C=>({...C,[t]:x})),l(!p),m!=null&&m.id?j(m):j({}),document.body.style.overflow="hidden"},Y=t=>{const x=t.id,m=t.client_title,C=async()=>{if((await K.delete(`/client/updateClientLogo/${x}/`)).status===204){const Z=g.filter(H=>H.id!==x);a(Z),ye.success(`${m} is deleted`)}};je.confirmAlert({customUI:({onClose:U})=>e.jsx(Se,{onClose:U,callback:C,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:m})," service?"]})})})},[i,W]=r.useState([]),D=re(),{error:Ee,success:Fe,showHideList:v}=O(t=>t.showHide);r.useEffect(()=>{v.length>0&&W(ce(v))},[v]);const I=async(t,x)=>{if(t)D(be(t));else{const m={componentName:x.toLowerCase(),pageType:c};D(he(m))}};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:(A=i==null?void 0:i.clientlistbanner)!=null&&A.visibility&&o&&d?"border border-info mb-2":"",children:[o&&d&&e.jsx($,{showhideStatus:(k=i==null?void 0:i.clientlistbanner)==null?void 0:k.visibility,title:"Banner",componentName:"clientlistbanner",showHideHandler:I,id:(T=i==null?void 0:i.clientlistbanner)==null?void 0:T.id}),((E=i==null?void 0:i.clientlistbanner)==null?void 0:E.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[o&&d&&e.jsx(w,{editHandler:()=>f("banner",!0)}),e.jsx(Ae,{getBannerAPIURL:`banner/clientBannerIntro/${c}-banner/`,bannerState:s.banner})]}),s.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(de,{editHandler:f,componentType:"banner",popupTitle:"Client List Banner",pageType:`${c}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:me(`${c}-banner`),dimensions:_("banner")})})]})]}),e.jsxs("div",{className:(F=i==null?void 0:i.clientsbriefintro)!=null&&F.visibility&&o&&d?"border border-info mb-2":"",children:[o&&d&&e.jsx($,{showhideStatus:(R=i==null?void 0:i.clientsbriefintro)==null?void 0:R.visibility,title:"A Brief Introduction Component",componentName:"clientsbriefintro",showHideHandler:I,id:(P=i==null?void 0:i.clientsbriefintro)==null?void 0:P.id}),((B=i==null?void 0:i.clientsbriefintro)==null?void 0:B.visibility)&&e.jsxs("div",{children:[o&&d&&e.jsx(w,{editHandler:()=>f("briefIntro",!0)}),e.jsx(pe,{introState:s.briefIntro,pageType:c,introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center"}),s.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(xe,{editHandler:f,popupTitle:"Client list",componentType:"briefIntro",pageType:c})})]})]}),e.jsxs("div",{className:"container-fluid container-lg my-md-5 ",children:[e.jsx("div",{className:"row",children:o&&d&&e.jsx("div",{className:"col-md-12",children:e.jsx("div",{className:"d-flex justify-content-end align-items-center mb-3",children:e.jsxs("button",{type:"submit",className:"btn btn-primary px-3",onClick:()=>f("addSection",!0,{}),children:["Add New Client"," ",e.jsx("i",{className:"fa fa-plus ms-2","aria-hidden":"true"})]})})})}),e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6 fs-3 mt-4 mt-md-0",children:e.jsx(q,{title:"Clients",cssClass:"fs-1 pageTitle"})}),e.jsx("div",{className:"col-md-6",children:e.jsx(Ce,{setObject:S,clientSearchURL:"/client/searchClientLogos/",adminSearchURL:"/client/createClientLogo/",clientDefaultURL:"/client/getAllClientLogos/",searchfiledDeatails:"client Title",setPageloadResults:G,setSearchquery:J,searchQuery:y,addStateChanges:s.addSection,editStateChanges:!s.editSection})})]}),s.editSection||s.addSection?e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ve,{editHandler:f,category:"about",popupTitle:"Client",editCarousel:b,setEditCarousel:j,componentType:`${s.editSection?"editSection":"addSection"}`,imageGetURL:"client/createClientLogo/",imagePostURL:"client/createClientLogo/",imageUpdateURL:"client/updateClientLogo/",imageDeleteURL:"client/updateClientLogo/",imageLabel:"Add Client Logo",showDescription:!1,showExtraFormFields:ge(),dimensions:_("aboutus"),scrollEnable:!1})}):"",e.jsx("br",{}),o&&e.jsx(Ie,{note:"Use drag option to shuffle the Items"}),e.jsx(M,{children:e.jsx(ke,{clientsList:g,setClientsList:a,deleteAboutSection:Y,editHandler:f,getClinetDetails:L})}),u!=null&&u.total_count?e.jsx(we,{paginationData:u,paginationURL:o?"/client/createClientLogo/":"/client/getAllClientLogos/",paginationSearchURL:y?`/client/searchClientLogos/${y}/`:o?"/client/createClientLogo/":"/client/getAllClientLogos/",searchQuery:y,setCurrentPage:N,currentPage:X,setResponseData:S,pageLoadResult:V}):""]})]})};export{Ke as default};
