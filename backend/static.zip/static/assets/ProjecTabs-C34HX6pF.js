import{r as s,j as e,b as G,y as L,ag as z,av as V,T as H,c as Y,M as ie,a8 as W,x as _,a6 as re,n as ce,ad as de,e as me,B as q}from"./index-DrMxwgAs.js";import{A as pe}from"./Alert-dncnt3n1.js";import{D as be}from"./DeleteDialog-BPphzh6L.js";import{P as he}from"./ProjectGalleryView-uNF1grbv.js";import"./DynamicCarousel-BV6-0HJX.js";const xe=({closeModel:a,downloadPDF:n})=>{const o={firstName:"",email:"",phoneNumber:"",description:""},[p,h]=s.useState(o),[x,t]=s.useState({}),[g,u]=s.useState(!1),j=c=>{u(!1);const{name:b,value:v}=c.target;h(y=>({...y,[b]:v})),t(y=>({...y,[b]:""}))},f=async c=>{c.preventDefault();const b=I(p);if(t(b),!(Object.keys(b).length>0))try{(await G.post("/contactus/",{...p})).status===201?(L.success("Your request is submit succuessfully"),z("clientInformation"),V("clientInformation",p.email,{maxAge:86400}),h(o),t(""),u(!0),a(),n()):L.error("unable to process your request")}catch{L.error("unable to process your request")}},I=c=>{const b={},v=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;return c.firstName||(b.firstName="Please Enter Name"),c.phoneNumber||(b.phoneNumber="Please Enter Phone Number"),c.email?v.test(c.email)||(b.email="Enter Valid Email"):b.email="Please Enter Email",b};return e.jsx(e.Fragment,{children:e.jsxs("div",{className:"col-md-12 d-flex justify-content-center align-items-center flex-column",children:[g&&e.jsx(pe,{mesg:"Thank you for contact us",cssClass:"alert text-white w-75 mt-3 p-2 text-center bg-success"}),e.jsxs("form",{className:"my-2 py-3 py-md-5 contactForm",onSubmit:f,children:[e.jsxs("div",{className:"mb-3 row",children:[e.jsx("label",{htmlFor:"exampleInputFName",className:"col-sm-2 col-form-label",children:"Name"}),e.jsxs("div",{className:"col-sm-10",children:[e.jsx("input",{type:"textbox",name:"firstName",value:p.firstName,onChange:j,className:"form-control",id:"exampleInputFName","aria-describedby":"emailHelp"}),x.firstName!==null?e.jsx("div",{id:"emailHelp",className:"form-text text-danger",children:x.firstName}):""]})]}),e.jsxs("div",{className:"mb-3 row",children:[e.jsx("label",{htmlFor:"exampleInputEmail1",className:"col-sm-2 col-form-label",children:"Email"}),e.jsxs("div",{className:"col-sm-10",children:[e.jsx("input",{type:"email",name:"email",value:p.email,onChange:j,className:"form-control",id:"exampleInputEmail1","aria-describedby":"emailHelp"}),x.email!==null?e.jsx("div",{id:"emailHelp",className:"form-text text-danger",children:x.email}):""]})]}),e.jsxs("div",{className:"mb-3 row",children:[e.jsx("label",{htmlFor:"exampleInputPhone",className:"col-sm-2 col-form-label",children:"Phone"}),e.jsxs("div",{className:"col-sm-10",children:[e.jsx("input",{type:"textbox",name:"phoneNumber",value:p.phoneNumber,onChange:j,className:"form-control",id:"exampleInputPhone","aria-describedby":"emailHelp"}),x.phoneNumber!==null?e.jsx("div",{id:"emailHelp",className:"form-text text-danger",children:x.phoneNumber}):""]})]}),e.jsxs("div",{className:"mb-3 row",children:[e.jsx("label",{htmlFor:"exampleFormMesg",className:"col-sm-2 col-form-label",children:"Message"}),e.jsx("div",{className:"col-sm-10",children:e.jsx("textarea",{className:"form-control",value:p.description,onChange:j,name:"description",id:"exampleFormMesg",rows:"3"})})]}),e.jsxs("div",{className:"mb-3 row",children:[e.jsx("div",{className:"col-sm-2"}),e.jsx("div",{className:"col-sm-10",children:e.jsx("button",{type:"submit",className:"btn btn-primary w-100 text-uppercase py-2",children:"Send Request"})})]})]})]})})},ge="/static/assets/project1-P8ULbn8S.png",ue=({closeModel:a,downloadPDF:n})=>e.jsx("div",{className:"modal d-block modal-lg",tabIndex:"-1",children:e.jsx("div",{className:"modal-dialog modal-dialog-centered",children:e.jsxs("div",{className:"modal-content",children:[e.jsxs("div",{className:"modal-header",children:[e.jsx("h5",{className:"modal-title text-dark fw-bold",children:"Contact"}),e.jsx("button",{type:"button",className:"btn-close","data-bs-dismiss":"modal","aria-label":"Close",onClick:a})]}),e.jsx("div",{className:"modal-body px-4 py-3",children:e.jsx(xe,{closeModel:a,downloadPDF:n})})]})})}),fe=({project:a,thumbImgs:n,pdfs:o})=>{var M;const[p,h]=s.useState(!1),[x,t]=s.useState(""),[g,u]=s.useState(""),{aboutstitle:j,aboutussubtitle:f,description:I}=a,c=Y(),b=(m,T)=>{t(m),u(T),W("clientInformation")!==void 0?v():y()},v=()=>{const m=document.createElement("a");m.download=g,m.href=c+x,m.target="_blank",m.click()},y=()=>{h(!p)},A=()=>{h(!p)};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"px-5",children:[e.jsx(H,{title:j,cssClass:"title"}),e.jsx(H,{title:f,cssClass:"subTitle"}),e.jsx("div",{className:"py-3",children:I}),o.length>0&&e.jsxs("div",{className:"pdfDownloadsAsSelectBox",children:["PDF's Download ",e.jsx("i",{class:"fa fa-download  fs-5 ms-2","aria-hidden":"true"}),e.jsx("div",{className:"documents",children:o.length>0?o.map((m,T)=>e.jsxs("span",{className:"d-block cursorPointer",onClick:()=>b(m.path,m.originalname),children:[e.jsx("svg",{width:"18",height:"23",viewBox:"0 0 16 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e.jsx("path",{d:"M7.57917 10.0039C7.37083 9.37891 7.375 8.17187 7.49583 8.17187C7.84583 8.17187 7.8125 9.61328 7.57917 10.0039ZM7.50833 11.8477C7.1875 12.6367 6.7875 13.5391 6.325 14.2969C7.0875 14.0234 7.95 13.625 8.94583 13.4414C8.41667 13.0664 7.90833 12.5273 7.50833 11.8477ZM3.5875 16.7227C3.5875 16.7539 4.1375 16.5117 5.04167 15.1523C4.7625 15.3984 3.82917 16.1094 3.5875 16.7227ZM10.3333 6.25H16V19.0625C16 19.582 15.5542 20 15 20H1C0.445833 20 0 19.582 0 19.0625V0.9375C0 0.417969 0.445833 0 1 0H9.33333V5.3125C9.33333 5.82812 9.78333 6.25 10.3333 6.25ZM10 12.9609C9.16667 12.4844 8.6125 11.8281 8.22083 10.8594C8.40833 10.1367 8.70417 9.03906 8.47917 8.35156C8.28333 7.20313 6.7125 7.31641 6.4875 8.08594C6.27917 8.80078 6.47083 9.80859 6.825 11.0938C6.34167 12.1719 5.62917 13.6172 5.125 14.4453C5.12083 14.4453 5.12083 14.4492 5.11667 14.4492C3.9875 14.9922 2.05 16.1875 2.84583 17.1055C3.07917 17.375 3.5125 17.4961 3.74167 17.4961C4.4875 17.4961 5.22917 16.793 6.2875 15.082C7.3625 14.75 8.54167 14.3359 9.57917 14.1758C10.4833 14.6367 11.5417 14.9375 12.2458 14.9375C13.4625 14.9375 13.5458 13.6875 13.0667 13.2422C12.4875 12.7109 10.8042 12.8633 10 12.9609ZM15.7083 4.10156L11.625 0.273438C11.4375 0.0976562 11.1833 0 10.9167 0H10.6667V5H16V4.76172C16 4.51563 15.8958 4.27734 15.7083 4.10156ZM12.6208 14.0742C12.7917 13.9687 12.5167 13.6094 10.8375 13.7227C12.3833 14.3398 12.6208 14.0742 12.6208 14.0742Z",fill:"#017DB9"})}),e.jsx("span",{className:"text-dark ms-2",download:!0,children:m.originalname})]},T)):null})]}),e.jsx("div",{className:"d-flex justify-content-left my-2 clearfix projectHomeImage",children:e.jsx("img",{src:n.length>0?`${c}${(M=n[0])==null?void 0:M.path}`:ge,className:"rounded img-fluid",alt:"..."})})]}),p&&e.jsx(ue,{closeModel:A,downloadPDF:v}),p&&e.jsx(ie,{})]})},je=({amenities:a})=>{const{amenitie:n,feature:o}=a||{};return e.jsx("div",{className:"amenities container my-4",children:e.jsxs("div",{className:"row",children:[n===""?"":e.jsxs("div",{className:"col-6",children:[e.jsx("h4",{children:"Amenities"}),e.jsx("div",{children:n})]}),o===""?"":e.jsxs("div",{className:"col-6",children:[e.jsx("h4",{children:"Features"}),e.jsx("div",{children:o})]})]})})},ve=({specifications:a})=>e.jsx(e.Fragment,{children:a.map((n,o)=>e.jsxs("div",{className:"mt-4 px-3",children:[e.jsx("h6",{className:"text-dark fw-bold",children:n.title}),e.jsx("p",{children:n.feature})]},o))}),Ne=({amenities:a})=>{const{googleMap:n}=a||{};return e.jsx(e.Fragment,{children:n===""?"":e.jsxs("div",{className:"px-5",children:[e.jsx(H,{title:"Project Location",cssClass:"fs-5 mb-4 text-center"}),e.jsx("iframe",{className:"googlemap",src:n,height:"600",width:"100%"})]})})},Z=({images:a,pdfs:n})=>{const o=_(),p=Y(),h=(g,u)=>{const j=()=>{z("previousPath"),V("previousPath",window.location.pathname),o("/contact")};if(W("clientInformation")!==void 0){const f=document.createElement("a");f.download=u,f.href=p+g,f.click()}else re.confirmAlert({customUI:({onClose:f})=>e.jsx(be,{onClose:f,callback:j,label:"to Download PDF's",message:"We need some of your personal details to download PDF's",buttonStyle:"btn-success",title:" "})})};let x,t;return a.length>0&&(x=a.map((g,u)=>e.jsx("div",{className:"my-1 text-center zoomImg",children:e.jsx("img",{src:`${p}${g.path}`,alt:"",className:""})},u))),n.length>0&&(t=n.map((g,u)=>e.jsx("p",{className:"text-end",children:e.jsxs("span",{className:"d-block my-3 cursorPointer",onClick:()=>h(g.path,g.originalname),children:[e.jsx("span",{className:"text-dark me-2",download:!0,children:g.originalname}),e.jsx("svg",{width:"18",height:"23",viewBox:"0 0 16 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e.jsx("path",{d:"M7.57917 10.0039C7.37083 9.37891 7.375 8.17187 7.49583 8.17187C7.84583 8.17187 7.8125 9.61328 7.57917 10.0039ZM7.50833 11.8477C7.1875 12.6367 6.7875 13.5391 6.325 14.2969C7.0875 14.0234 7.95 13.625 8.94583 13.4414C8.41667 13.0664 7.90833 12.5273 7.50833 11.8477ZM3.5875 16.7227C3.5875 16.7539 4.1375 16.5117 5.04167 15.1523C4.7625 15.3984 3.82917 16.1094 3.5875 16.7227ZM10.3333 6.25H16V19.0625C16 19.582 15.5542 20 15 20H1C0.445833 20 0 19.582 0 19.0625V0.9375C0 0.417969 0.445833 0 1 0H9.33333V5.3125C9.33333 5.82812 9.78333 6.25 10.3333 6.25ZM10 12.9609C9.16667 12.4844 8.6125 11.8281 8.22083 10.8594C8.40833 10.1367 8.70417 9.03906 8.47917 8.35156C8.28333 7.20313 6.7125 7.31641 6.4875 8.08594C6.27917 8.80078 6.47083 9.80859 6.825 11.0938C6.34167 12.1719 5.62917 13.6172 5.125 14.4453C5.12083 14.4453 5.12083 14.4492 5.11667 14.4492C3.9875 14.9922 2.05 16.1875 2.84583 17.1055C3.07917 17.375 3.5125 17.4961 3.74167 17.4961C4.4875 17.4961 5.22917 16.793 6.2875 15.082C7.3625 14.75 8.54167 14.3359 9.57917 14.1758C10.4833 14.6367 11.5417 14.9375 12.2458 14.9375C13.4625 14.9375 13.5458 13.6875 13.0667 13.2422C12.4875 12.7109 10.8042 12.8633 10 12.9609ZM15.7083 4.10156L11.625 0.273438C11.4375 0.0976562 11.1833 0 10.9167 0H10.6667V5H16V4.76172C16 4.51563 15.8958 4.27734 15.7083 4.10156ZM12.6208 14.0742C12.7917 13.9687 12.5167 13.6094 10.8375 13.7227C12.3833 14.3398 12.6208 14.0742 12.6208 14.0742Z",fill:"#017DB9"})})]})},u))),e.jsxs("div",{className:"d-flex flex-wrap justify-content-start align-items-center gap-3 planThumbs px-2",children:[n.length>0?t:null,a.length>0?x:null]})},ye=ce.div`
   
    .projectsList {
         padding: 48px 0;

        h5 {
            text-transform: capitalize;
        }

        h5:first-letter {
            color: ${({theme:a})=>a.clientSecondaryColor};
        }

        .box {
            border-radius: 5px;
            overflow: hidden;
        }

        .infoStrip {
            position: absolute;
            z-index: 999;
            background-color: rgba(0, 152, 218, 0.75);
            bottom: 0;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 7px 0;
            transition: padding 300ms ease;

            &:hover {
                // background-color: rgba(41, 90, 147, 0.95);
                background-color: rgba(239, 64, 54, .65);
                padding: 15px 0;

                a {
                    color: #a8c849;
                    letter-spacing: 0.15rem;
                }
            }

            a {
                text-decoration: none;
                font-weight: 500;
                transition: letter-spacing 300ms ease;
            }

            h5, h5:first-letter {
                color: ${({theme:a})=>a.white} !important;
                color: #EF4036
            }
        }

        .infoStrip + img {
            width: 100%;
            height: 148px;
            object-fit: cover;
        }

        
    }
    .projectTabs {
        select#projectStatus {
            border: 1px solid ${({theme:a})=>a.grayeee} !important;
            border-radius: 4px !important;
            max-width: 190px;galleryThumbs
        }

        .breadCrumb {
            text-transform: capitalize;

            span {
                color: ${({theme:a})=>a.primaryColor}
            }
        }

        .nav-link {
            border: 0px !important;
            border-radius: 0px !important;
            margin-right: 2px;

            &:hover {
                color: ${({theme:a})=>a.primaryColor} !important;
            }
        }

        .nav-link.active {
            background-color: ${({theme:a})=>a.primaryColor} !important;
            color: #fff !important;
        }

        .tab-content {
            padding: 48px 0;

            h5.title {
                color: ${({theme:a})=>a.gray444};
                font-size: 1.5rem !important;
            }
            h5.subTitle {
                color: ${({theme:a})=>a.gray666};
                font-size: .8rem !important;
            }
        }

        .pdfDownloadsAsSelectBox {
            position: relative;
            float: right;
            border: 1px solid ${({theme:a})=>a.grayddd};
            padding: 10px 16px;
            cursor: pointer;
            border-radius: 4px;
            font-size: .9rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;

            &:hover .documents {
                display: block;
            }

            .documents {
                display: none;
                position: absolute;
                background: ${({theme:a})=>a.white};
                border: 1px solid ${({theme:a})=>a.verylightgray};
                box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15);
                padding: 16px 24px;
                width: 500px;
                right: 0;
                max-height: 320px;
                overflow: auto;

                span {
                    border-bottom: 1px solid ${({theme:a})=>a.verylightgray};
                    padding: 6px;
                    margin-bottom: 8px;
                    font-size: .8rem;
                    font-weight: 400;

                    &:hover {
                        background-color: ${({theme:a})=>a.verylightgray};
                    }

                    span {
                        border: 0;
                    }
                }
            }
        }

        .projectHomeImage {
            img {
                max-width: 500px;
            }
        }
    }


    .nav-tabs {
        border-top: 1px solid ${({theme:a})=>a.verylightgray};
        border-bottom: 0px !important;
    }

    .zoomImg {
        /* display: inline-block; */
        /* overflow: scroll; */
        border: 1px solid rgb(237, 237, 237);
        // padding: 15px 0;

         img {
            -webkit-transition: all 0.2s ease;
            -moz-transition: all 0.2s ease;
            -ms-transition: all 0.2s ease;
            -o-transition: all 0.2s ease;
            transition: all 0.2s ease;

            /* vertical-align: middle; */

            &:hover {
                -webkit-transform: scale(2.5);
                -moz-transform: scale(2.5);
                -o-transform: scale(2.5);
                -ms-transform: scale(2.5);
                transform: scale(2.5);
                /* transform: scale3d(1.1, 1.1, 1); */
            } 
        }
    }

    .galleryThumbs {
        h4 {
            font-size: 12px;
            color: ${({theme:a})=>a.gray444};

            span {
                color: ${({theme:a})=>a.clientSecondaryColor}
            }
        }

        img {
            margin: 10px 10px 10px 0 !important;
            height: 120px !important;
            width: 140px !important;
        }
    }

    .planThumbs {
        > div {
            width: 200px;
            height: 200px;
            border-radius: 4px;

            img {
                max-width: 100%;
                height: 100%;
                object-fit: cover;
                border-radius: 4px;
            }
        }
    }

`,Ie=()=>{var R,U;const a=de(),n=_(),[o,p]=s.useState((R=a==null?void 0:a.state)==null?void 0:R.selectedPorject),[h,x]=s.useState((U=a==null?void 0:a.state)==null?void 0:U.projectid),[t,g]=s.useState({}),[u,j]=s.useState([]),[f,I]=s.useState([]),[c,b]=s.useState([]),[v,y]=s.useState([]),[A,M]=s.useState([]),[m,T]=s.useState([]),[J,K]=s.useState(""),[B,Q]=s.useState(!1),[X,ee]=s.useState([]),[C,ae]=s.useState([]),[$,te]=s.useState([]),[w,se]=s.useState([]),[P,le]=s.useState([]),{isAdmin:ne,hasPermission:oe}=me();s.useEffect(()=>{z("projectid"),V("projectid",h),O(h)},[h]),s.useEffect(()=>{const d=document.getElementById("projectLink");d&&d.classList.add("active")});const O=async d=>{try{const i=await G.get(`/project/getSelectedClientProject/${d}/`);if((i==null?void 0:i.status)===200){const r=i.data,l=r.project[0];K(l==null?void 0:l.projectTitle),x(l==null?void 0:l.id),I(l),g(r.amenitie[0]),S(r,"images"),S(r,"pdfs"),S(r,"price"),S(r,"plan"),S(r,"avl"),S(r,"thumbnail"),b(r==null?void 0:r.specificationData)}}catch{console.log("unable to access ulr because of server is down")}},S=(d,i)=>{const r=d.imageData;if(i==="images"){const l=k(r,"images"),N=[{...d.project[0],imgs:l}];Q(l.length>0),j(N)}if(i==="pdfs"){const l=k(r,"PDF");y(l)}if(i==="plan"){const l=k(r,"Plans"),N=E(l);T(N);const F=D(l);M(F)}if(i==="price"){const l=k(r,"price"),N=E(l);te(N);const F=D(l);ae(F)}if(i==="avl"){const l=k(r,"availability"),N=E(l);le(N);const F=D(l);se(F)}if(i==="thumbnail"){const l=k(r,"thumbnail"),N=E(l);ee(N)}},k=(d,i)=>d.filter(r=>r.category===i),E=d=>d.filter(i=>i.contentType===".jpg"||i.contentType===".jpeg"||i.contentType===".png"),D=d=>d.filter(i=>i.contentType===".pdf");return e.jsx(ye,{children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row p-0 pt-4 projectTabs",children:e.jsxs("div",{className:"col-md-12",children:[e.jsx("div",{className:"d-flex justify-content-end",children:e.jsx(q,{type:"",cssClass:"btn btn-primary",label:"Go To All Projects",handlerChange:()=>{n("/projects")}})}),e.jsxs("div",{className:"d-flex justify-content-between align-items-center mt-3 mb-3",children:[e.jsx("div",{className:"w-50",children:e.jsx(H,{title:f.projectCategoryName,subTitle:J,cssClass:"fs-6 breadCrumb"})}),e.jsxs("div",{className:"d-flex justify-content-end align-items-center gap-2 w-50",children:[e.jsxs("select",{className:"form-select","aria-label":"Default select example",id:"projectStatus",value:h,onChange:d=>O(d.target.value),children:[e.jsx("option",{value:"select",children:"Select"}),(o==null?void 0:o.length)>0?o==null?void 0:o.map(d=>e.jsx("option",{value:d.id,children:d.projectTitle},d.id)):""]}),ne&&oe&&e.jsx(q,{type:"",cssClass:"btn btn-outline",label:"Edit",handlerChange:()=>{n(`/editproject/${h}`)}})]})]}),e.jsxs("div",{className:"col-md-12 mb-4",children:[e.jsx("nav",{children:e.jsxs("div",{className:"nav nav-tabs",id:"nav-tab",role:"tablist",children:[e.jsx("button",{className:"nav-link active",id:"nav-home-tab","data-bs-toggle":"tab","data-bs-target":"#nav-home",type:"button",role:"tab","aria-controls":"nav-home","aria-selected":"true",children:"HOME"}),B&&e.jsx("button",{className:"nav-link",id:"nav-gallery-tab","data-bs-toggle":"tab","data-bs-target":"#nav-gallery",type:"button",role:"tab","aria-controls":"nav-gallery","aria-selected":"false",children:"GALLERY"}),(c==null?void 0:c.length)>0&&e.jsx("button",{className:"nav-link",id:"nav-specifications-tab","data-bs-toggle":"tab","data-bs-target":"#nav-specifications",type:"button",role:"tab","aria-controls":"nav-specifications","aria-selected":"false",children:"SPECIFICATIONS"}),(P==null?void 0:P.length)>0||(w==null?void 0:w.length)>0&&e.jsx("button",{className:"nav-link",id:"nav-availability-tab","data-bs-toggle":"tab","data-bs-target":"#nav-availability",type:"button",role:"tab","aria-controls":"nav-availability","aria-selected":"false",children:"AVAILABILITY"}),(C==null?void 0:C.length)>0||$.length>0&&e.jsx("button",{className:"nav-link",id:"nav-cost-tab","data-bs-toggle":"tab","data-bs-target":"#nav-cost",type:"button",role:"tab","aria-controls":"nav-cost","aria-selected":"false",children:"COST"}),(m==null?void 0:m.length)>0&&e.jsx("button",{className:"nav-link",id:"nav-plan-tab","data-bs-toggle":"tab","data-bs-target":"#nav-plan",type:"button",role:"tab","aria-controls":"nav-plan","aria-selected":"false",children:"PLAN"}),(t==null?void 0:t.googleMap)&&e.jsx("button",{className:"nav-link",id:"nav-location-tab","data-bs-toggle":"tab","data-bs-target":"#nav-location",type:"button",role:"tab","aria-controls":"nav-location","aria-selected":"false",children:"LOCATION"}),((t==null?void 0:t.amenitie)||(t==null?void 0:t.feature))&&e.jsx("button",{className:"nav-link",id:"nav-amenities-tab","data-bs-toggle":"tab","data-bs-target":"#nav-amenities",type:"button",role:"tab","aria-controls":"nav-amenities","aria-selected":"false",children:"AMENITIES"})]})}),e.jsxs("div",{className:"tab-content",id:"nav-tabContent",children:[e.jsx("div",{className:"tab-pane fade show active",id:"nav-home",role:"tabpanel","aria-labelledby":"nav-home-tab",children:e.jsx(fe,{project:f,thumbImgs:X,pdfs:v})}),B?e.jsx("div",{className:"tab-pane fade",id:"nav-gallery",role:"tabpanel","aria-labelledby":"nav-gallery-tab",children:e.jsx(he,{projectImages:u,type:"projectgallery"})}):"",(c==null?void 0:c.length)>0?e.jsx("div",{className:"tab-pane fade",id:"nav-specifications",role:"tabpanel","aria-labelledby":"nav-specifications-tab",children:e.jsx(ve,{specifications:c})}):"",(P==null?void 0:P.length)>0||(w==null?void 0:w.length)>0?e.jsx("div",{className:"tab-pane fade",id:"nav-availability",role:"tabpanel","aria-labelledby":"nav-availability-tab",children:e.jsx(Z,{images:P,pdfs:w})}):"",(C==null?void 0:C.length)>0||$.length>0?e.jsx("div",{className:"tab-pane fade",id:"nav-cost",role:"tabpanel","aria-labelledby":"nav-cost-tab",children:e.jsx(Z,{images:$,pdfs:C})}):"",(m==null?void 0:m.length)>0||A.length>0?e.jsx("div",{className:"tab-pane fade",id:"nav-plan",role:"tabpanel","aria-labelledby":"nav-plan-tab",children:e.jsx(Z,{images:m,pdfs:A})}):"",t!=null&&t.googleMap?e.jsx("div",{className:"tab-pane fade",id:"nav-location",role:"tabpanel","aria-labelledby":"nav-location-tab",children:e.jsx(Ne,{amenities:t})}):"",t!=null&&t.amenitie||t!=null&&t.feature?e.jsx("div",{className:"tab-pane fade",id:"nav-amenities",role:"tabpanel","aria-labelledby":"nav-amenities-tab",children:e.jsx(je,{amenities:t})}):""]})]})]})})})})};export{Ie as default};
