import{n as ee,e as V,r as l,a as ae,z as te,h as se,Q as re,j as e,U,E as w,l as ne,V as B,m as ie,X as oe,Y as le,L as u,T as M,aD as ce,M as de,b as me,a1 as ue,a2 as be,o as xe,p as fe,at as pe,aa as he,ab as ge,d as je,K as Se,a6 as _e,v as L,y as ye}from"./index-DrMxwgAs.js";import{B as ve}from"./index-DpfQMTHo.js";import{N as Ne}from"./index-ByNTAwhR.js";import{D as we}from"./DeleteDialog-BPphzh6L.js";import{S as Te}from"./index-DSjIgb-e.js";import{C as De}from"./CustomPagination-B7rpvrGc.js";import{D as Ie,C as ke,P as Ce}from"./dnd.esm-hB_vzQGM.js";import"./Styled-PageBanner-BsuMNpbu.js";const Pe=ee.div`
  background-color: ${({theme:a})=>a.transparent};

  .editIcon {
    top: 10px;
  }

  .title {
    color: ${({theme:a})=>a.teamTitleColor};
    font-weight: 500;
    font-size: 1.1rem;
  }


  // a {
  //   color: ${({theme:a})=>a.teamLinkColor};
  // }

  // .social {
  // border-top: 1px solid ${({theme:a})=>a.graye6};
  // }

  .social i {
    color: ${({theme:a})=>a.secondaryColor};

    font-size: 1.6rem;
    margin: 7px;
  }

  img {
    object-fit: contain;
    object-position: top;
    height: auto;
    max-height: 300px;
    width: 100%;
  }

  .aboutMe {
  }
  
  .ql-editor {
    padding: 0
  }

  .memberCard {
    background-color: ${({theme:a})=>a.white};
    // border:1px solid ${({theme:a})=>a.secondaryColor};
    border-radius: 5px;
    margin: 15px 0;
    overflow: hidden;

    .memberDetails {
      color: ${({theme:a})=>a.teamTextColor};

      small {
        font-size: 0.7rem;
        text-transform: uppercase;
        color: ${({theme:a})=>a.clientColor};
      }

      .strengths {
  //       display: -webkit-box;
  // -webkit-line-clamp: 4;
  // -webkit-box-orient: vertical;  
  // overflow: hidden;

  @media(max-width: 480px) {
    -webkit-line-clamp: none;
  }
        // p:before {
        //   content: "⬦  ";
        //   font-size: 16px;
        // }
        // p {
        //   margin-left: 10px;
        //   margin-bottom: 0px;
        // }
      }
    }
  }
`,Me=()=>{var k,C,P,$,R,E,A,F;const a={banner:!1,briefIntro:!1,addSection:!1,editSection:!1},d="teams",{isAdmin:o,hasPermission:m}=V(),[i,_]=l.useState(a),[x,q]=l.useState(!1),[p,h]=l.useState([]),[g,y]=l.useState({}),[j,z]=l.useState({}),[K,Q]=l.useState(!1),[f,J]=l.useState(""),[X,T]=l.useState(1),b=(t,n,r)=>{_(c=>({...c,[t]:n})),q(!x),r!=null&&r.id?y(r):y({}),document.body.style.overflow="hidden"},v=t=>{var n;if(((n=t==null?void 0:t.results)==null?void 0:n.length)>0){const r=xe(t.results[0]),c=fe(t.results,r);h(c),z(pe(t)),T(1)}else h([])};l.useEffect(()=>{const t=async()=>{try{const n=await me.get("/ourteam/clentViewOurTeamDetails/");(n==null?void 0:n.status)===200&&v(n.data)}catch{console.log("unable to access ulr because of server is down")}};(!i.addSection||!i.editSection)&&!f&&t()},[i.addSection,i.editSection]);const Y=t=>{const n=t.id,r=t.team_member_name,c=async()=>{if((await L.delete(`/ourteam/UpdateOurteamDetail/${n}/`)).status===204){const O=p.filter(H=>H.id!==n);h(O),ye.success(`${r} is deleted`)}};_e.confirmAlert({customUI:({onClose:S})=>e.jsx(we,{onClose:S,callback:c,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:r})," Service?"]})})})};l.useEffect(()=>{ae()},[]);const G=async t=>{const{source:n,destination:r}=t;if(!r)return!0;const c=he(p,n.index,r.index),S=ge(c,"team_member_position");(await W(S)).length>0&&h(c)},W=async t=>{var n;try{let r=await L.put("/ourteam/updateTeamindex/",t);if((n=r==null?void 0:r.data)!=null&&n.team)return r.data.team}catch{console.log("unable to save clinet position")}},[s,Z]=l.useState([]),D=te(),{error:Re,showHideList:N}=se(t=>t.showHide);l.useEffect(()=>{N.length>0&&Z(re(N))},[N]);const I=async(t,n)=>{if(t)D(ue(t));else{const r={componentName:n.toLowerCase(),pageType:d};D(be(r))}};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:(k=s==null?void 0:s.teamsbanner)!=null&&k.visibility&&o&&m?"border border-info mb-2":"",children:[o&&m&&e.jsx(U,{showhideStatus:(C=s==null?void 0:s.teamsbanner)==null?void 0:C.visibility,title:"Banner",componentName:"teamsbanner",showHideHandler:I,id:(P=s==null?void 0:s.teamsbanner)==null?void 0:P.id}),(($=s==null?void 0:s.teamsbanner)==null?void 0:$.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[o&&m&&e.jsx(w,{editHandler:()=>b("banner",!0)}),e.jsx(ve,{getBannerAPIURL:`banner/clientBannerIntro/${d}-banner/`,bannerState:i.banner})]}),i.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ne,{editHandler:b,componentType:"banner",popupTitle:"Team Banner",pageType:`${d}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:ie(`${d}-banner`),dimensions:B("banner")})})]})]}),e.jsxs("div",{className:(R=s==null?void 0:s.teambriefintro)!=null&&R.visibility&&o&&m?"border border-info mb-2":"",children:[o&&m&&e.jsx(U,{showhideStatus:(E=s==null?void 0:s.teambriefintro)==null?void 0:E.visibility,title:"A Brief Introduction Component",componentName:"teambriefintro",showHideHandler:I,id:(A=s==null?void 0:s.teambriefintro)==null?void 0:A.id}),((F=s==null?void 0:s.teambriefintro)==null?void 0:F.visibility)&&e.jsxs("div",{children:[o&&m&&e.jsx(w,{editHandler:()=>b("briefIntro",!0)}),e.jsx(oe,{introState:i.briefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center",linkLabel:"Read More",moreLink:"",showLink:!1,introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center",detailsContainerCss:"col-md-10 offset-md-1",anchorContainer:"d-flex justify-content-start align-items-start mt-4",anchersvgColor:"#17427C",pageType:d}),i.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(le,{editHandler:b,componentType:"briefIntro",popupTitle:"Team Brief",pageType:d})})]})]}),e.jsxs("div",{className:"container",children:[e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-12 mt-4",children:o&&m&&e.jsx("div",{className:"text-end mb-4",children:e.jsxs(u,{to:"#",className:"btn btn-primary",onClick:()=>b("addSection",!0),children:["Add team",e.jsx("i",{className:"fa fa-plus ms-2","aria-hidden":"true"})]})})})}),e.jsxs("div",{className:"row mb-0 py-2 py-md-4",children:[e.jsx("div",{className:"col-md-6 fs-3 mt-4 mt-md-0",children:e.jsx(M,{title:"Our Team",cssClass:"fs-1 pageTitle"})}),e.jsx("div",{className:"col-md-6 mb-4",children:e.jsx(Te,{setObject:v,clientSearchURL:"/ourteam/OurteamSearchAPIView/",adminSearchURL:"/ourteam/createteam/",clientDefaultURL:"/ourteam/clentViewOurTeamDetails/",searchfiledDeatails:"Name",setPageloadResults:Q,setSearchquery:J,searchQuery:f,addStateChanges:i.addSection,editStateChanges:!i.editSection})})]}),i.editSection||i.addSection?e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(Ne,{editHandler:b,category:"team",popupTitle:"Team",editCarousel:g,setEditCarousel:y,componentType:`${i.editSection?"editSection":"addSection"}`,getImageListURL:"ourteam/createteam/",deleteImageURL:"ourteam/UpdateOurteamDetail/",imagePostURL:"ourteam/createteam/",imageUpdateURL:"ourteam/UpdateOurteamDetail/",imageLabel:"Add Profile Image",showDescription:!1,showExtraFormFields:ce(g==null?void 0:g.team_member_position),dimensions:B("teams")})}):"",e.jsx(Pe,{children:e.jsx("div",{className:`${o?"":"teamFrontend"}`,children:e.jsx(Ie,{onDragEnd:G,children:e.jsx(ke,{droppableId:"teamList",id:"teamList",children:(t,n)=>e.jsxs("div",{className:"row",ref:t.innerRef,...t.droppableProps,children:[p.length>0?p.map((r,c)=>e.jsx($e,{item:r,index:c,editHandler:b,deleteAboutSection:Y},c)):e.jsx("p",{className:"text-center text-muted py-5",children:"Please add page contents..."}),t.placeholder]})})})})}),e.jsx("div",{className:"row my-5",children:(j==null?void 0:j.total_count)&&e.jsx(De,{paginationData:j,paginationURL:o?"/ourteam/createteam/":"/clieourteamnt/clentViewOurTeamDetails/",paginationSearchURL:f?`/ourteam/OurteamSearchAPIView/${f}/`:o?"/ourteam/createteam/":"/ourteam/clentViewOurTeamDetails/",searchQuery:f,setCurrentPage:T,currentPage:X,setResponseData:v,pageLoadResult:K})})]}),x&&e.jsx(de,{})]})},$e=({item:a,index:d,deleteAboutSection:o,editHandler:m})=>{const{isAdmin:i,hasPermission:_}=V();return e.jsx(Ce,{isDragDisabled:!i,draggableId:a.id,index:d,id:a.id,children:x=>e.jsx("div",{className:"col-md-6 col-lg-4 px-4 px-md-3",ref:x.innerRef,...x.draggableProps,...x.dragHandleProps,children:e.jsxs("div",{className:`mx-md-1 mx-lg-1 memberCard border shadow-sm ${i?"border border-warning position-relative":""} ${d%2===0?"normalCSS":"flipCSS"}`,children:[i&&_&&e.jsxs(e.Fragment,{children:[e.jsx(w,{editHandler:()=>m("editSection",!0,a)}),e.jsx(u,{className:"deleteSection",onClick:()=>o(a),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsx("div",{className:"text-center p-3",children:e.jsx("img",{src:je(a.path),className:"rounded rounded-1 mt-2 ",alt:""})}),e.jsxs("div",{className:" text-start py-2 p-4 memberDetails",children:[a.team_member_designation&&e.jsx("small",{className:"mb-1 fw-bold",children:a.team_member_designation}),a.team_member_name&&e.jsx(M,{title:a.team_member_name,cssClass:"fs-4 title "}),a.team_member_about_us&&e.jsx(Se,{data:a.team_member_about_us,className:"strengths"}),a.team_member_email&&e.jsx("div",{className:"mt-3",children:e.jsx("a",{href:`mailto:${a.team_member_email}`,children:a.team_member_email})}),a.team_member_phone_number&&e.jsx("p",{children:a.team_member_phone_number}),e.jsxs("div",{className:"social",children:[a.facebook_url&&e.jsx(u,{to:a.facebook_url,target:"_blank",children:e.jsx("i",{className:"fa fa-facebook-square","aria-hidden":"true"})}),a.twitter_url&&e.jsx(u,{to:a.twitter_url,target:"_blank",children:e.jsx("i",{className:"fa fa-twitter-square","aria-hidden":"true"})}),a.youtube_url&&e.jsx(u,{to:a.youtube_url,target:"_blank",children:e.jsx("i",{className:"fa fa-youtube-play","aria-hidden":"true"})}),a.linkedIn_url&&e.jsx(u,{to:a.linkedIn_url,target:"_blank",children:e.jsx("i",{className:"fa fa-linkedin-square","aria-hidden":"true"})}),a.instagram_url&&e.jsx(u,{to:a.instagram_url,target:"_blank",children:e.jsx("i",{className:"fa fa-instagram","aria-hidden":"true"})}),a.vimeo_url&&e.jsx(u,{to:a.vimeo_url,target:"_blank",children:e.jsx("i",{className:"fa fa-vimeo","aria-hidden":"true"})}),a.pinterest_url&&e.jsx(u,{to:a.pinterest_url,target:"_blank",children:e.jsx("i",{className:"fa fa-pinterest","aria-hidden":"true"})})]})]})]},a.id)})},a.id)};export{Me as default};
