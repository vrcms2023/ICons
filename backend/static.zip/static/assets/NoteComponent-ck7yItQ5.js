import{j as e}from"./index-DrMxwgAs.js";const s=({note:t})=>e.jsx("div",{className:"p-1 fs-5 text-primary text-center mb-2 rounded",children:e.jsxs("small",{children:["Note : ",t]})});export{s as N};
