import{u as Gr,j as e,I as de,f as ve,g as di,b as ye,y as Le,r as A,B as Qr,M as Ue,s as fi,c as Xr,d as Re,T as he,L as pe,e as Yr,h as Se,i as vi,k as hi,E as fe,l as $r,m as Jr,n as xe,o as ei,p as Ie,A as He,q as pi,t as mi,R as bi,v as Cr,w as gi,x as yi,z as ti,C as xi,D as Si,F as ji,S as ri,G as Ne,H as wi,J as Ci,K as Oi,O as Ni,a as ki,P as Ti,Q as Pi,U as ae,V as ge,W as Or,X as Pe,Y as ze,Z as Ke,_ as Mi,$ as _i,a0 as Ei,a1 as Li,a2 as Ii}from"./index-DrMxwgAs.js";import{C as Nr}from"./Carousel-DZaUvW1W.js";import{A as Be}from"./ImgTitleIntoForm-List-B7L5zYGw.js";import{A as Ri,a as Ve}from"./Styled-ABriefAbout-XRnMqIYa.js";import{H as Di}from"./HomeNews-B9HfTt9w.js";import{B as Ai}from"./index-DpfQMTHo.js";import kr from"./HomeServices-CymlGUnX.js";import{D as zi}from"./DynamicCarousel-BV6-0HJX.js";import{I as Bi}from"./Styled-ImageGallery-DkV5BKCi.js";import{P as Vi}from"./Product-DUh5q4GC.js";import"./DeleteDialog-BPphzh6L.js";import"./dnd.esm-hB_vzQGM.js";import"./NoteComponent-ck7yItQ5.js";import"./ContactForm-DpKhs2Pk.js";import"./index-ByNTAwhR.js";import"./SkeltonNews-DsHR9DP8.js";import"./Styled-PageBanner-BsuMNpbu.js";const Hi=[{label:"Select Country",value:""},{label:"Afghanistan",value:"Afghanistan"},{label:"Albania",value:"Albania"},{label:"Algeria",value:"Algeria"},{label:"American Samoa",value:"American Samoa"},{label:"Andorra",value:"Andorra"},{label:"Angola",value:"Angola"},{label:"Anguilla",value:"Anguilla"},{label:"Antarctica",value:"Antarctica"},{label:"Antigua and Barbuda",value:"Antigua and Barbuda"},{label:"Argentina",value:"Argentina"},{label:"Armenia",value:"Armenia"},{label:"Aruba",value:"Aruba"},{label:"Australia",value:"Australia"},{label:"Austria",value:"Austria"},{label:"Azerbaijan",value:"Azerbaijan"},{label:"Bahamas",value:"Bahamas"},{label:"Bahrain",value:"Bahrain"},{label:"Bangladesh",value:"Bangladesh"},{label:"Barbados",value:"Barbados"},{label:"Belarus",value:"Belarus"},{label:"Belgium",value:"Belgium"},{label:"Belize",value:"Belize"},{label:"Benin",value:"Benin"},{label:"Bermuda",value:"Bermuda"},{label:"Bhutan",value:"Bhutan"},{label:"Bolivia",value:"Bolivia"},{label:"Bosnia and Herzegovina",value:"Bosnia and Herzegovina"},{label:"Botswana",value:"Botswana"},{label:"Bouvet Island",value:"Bouvet Island"},{label:"Brazil",value:"Brazil"},{label:"British Indian Ocean Territory",value:"British Indian Ocean Territory"},{label:"Brunei Darussalam",value:"Brunei Darussalam"},{label:"Bulgaria",value:"Bulgaria"},{label:"Burkina Faso",value:"Burkina Faso"},{label:"Burundi",value:"Burundi"},{label:"Cambodia",value:"Cambodia"},{label:"Cameroon",value:"Cameroon"},{label:"Canada",value:"Canada"},{label:"Cape Verde",value:"Cape Verde"},{label:"Cayman Islands",value:"Cayman Islands"},{label:"Central African Republic",value:"Central African Republic"},{label:"Chad",value:"Chad"},{label:"Chile",value:"Chile"},{label:"China",value:"China"},{label:"Christmas Island",value:"Christmas Island"},{label:"Cocos (Keeling Islands)",value:"Cocos (Keeling Islands)"},{label:"Colombia",value:"Colombia"},{label:"Comoros",value:"Comoros"},{label:"Congo",value:"Congo"},{label:"Cook Islands",value:"Cook Islands"},{label:"Costa Rica",value:"Costa Rica"},{label:"Cote D'Ivoire (Ivory Coast)",value:"Cote D'Ivoire (Ivory Coast)"},{label:"Croatia",value:"Croatia"},{label:"Cuba",value:"Cuba"},{label:"Cyprus",value:"Cyprus"},{label:"Czech Republic",value:"Czech Republic"},{label:"Denmark",value:"Denmark"},{label:"Djibouti",value:"Djibouti"},{label:"Dominica",value:"Dominica"},{label:"Dominican Republic",value:"Dominican Republic"},{label:"East Timor",value:"East Timor"},{label:"Ecuador",value:"Ecuador"},{label:"Egypt",value:"Egypt"},{label:"El Salvador",value:"El Salvador"},{label:"Equatorial Guinea",value:"Equatorial Guinea"},{label:"Eritrea",value:"Eritrea"},{label:"Estonia",value:"Estonia"},{label:"Ethiopia",value:"Ethiopia"},{label:"Falkland Islands (Malvinas)",value:"Falkland Islands (Malvinas)"},{label:"Faroe Islands",value:"Faroe Islands"},{label:"Fiji",value:"Fiji"},{label:"Finland",value:"Finland"},{label:"France, Metropolitan",value:"France, Metropolitan"},{label:"France",value:"France"},{label:"French Guiana",value:"French Guiana"},{label:"French Polynesia",value:"French Polynesia"},{label:"French Southern Territories",value:"French Southern Territories"},{label:"Gabon",value:"Gabon"},{label:"Gambia",value:"Gambia"},{label:"Georgia",value:"Georgia"},{label:"Germany",value:"Germany"},{label:"Ghana",value:"Ghana"},{label:"Gibraltar",value:"Gibraltar"},{label:"Greece",value:"Greece"},{label:"Greenland",value:"Greenland"},{label:"Grenada",value:"Grenada"},{label:"Guadeloupe",value:"Guadeloupe"},{label:"Guam",value:"Guam"},{label:"Guatemala",value:"Guatemala"},{label:"Guinea-Bissau",value:"Guinea-Bissau"},{label:"Guinea",value:"Guinea"},{label:"Guyana",value:"Guyana"},{label:"Haiti",value:"Haiti"},{label:"Heard and McDonald Islands",value:"Heard and McDonald Islands"},{label:"Honduras",value:"Honduras"},{label:"Hong Kong",value:"Hong Kong"},{label:"Hungary",value:"Hungary"},{label:"Iceland",value:"Iceland"},{label:"India",value:"India"},{label:"Indonesia",value:"Indonesia"},{label:"Iran",value:"Iran"},{label:"Iraq",value:"Iraq"},{label:"Ireland",value:"Ireland"},{label:"Israel",value:"Israel"},{label:"Italy",value:"Italy"},{label:"Jamaica",value:"Jamaica"},{label:"Japan",value:"Japan"},{label:"Jordan",value:"Jordan"},{label:"Kazakhstan",value:"Kazakhstan"},{label:"Kenya",value:"Kenya"},{label:"Kiribati",value:"Kiribati"},{label:"Korea (North)",value:"Korea (North)"},{label:"Korea (South)",value:"Korea (South)"},{label:"Kuwait",value:"Kuwait"},{label:"Kyrgyzstan",value:"Kyrgyzstan"},{label:"Laos",value:"Laos"},{label:"Latvia",value:"Latvia"},{label:"Lebanon",value:"Lebanon"},{label:"Lesotho",value:"Lesotho"},{label:"Liberia",value:"Liberia"},{label:"Libya",value:"Libya"},{label:"Liechtenstein",value:"Liechtenstein"},{label:"Lithuania",value:"Lithuania"},{label:"Luxembourg",value:"Luxembourg"},{label:"Macau",value:"Macau"},{label:"Macedonia",value:"Macedonia"},{label:"Madagascar",value:"Madagascar"},{label:"Malawi",value:"Malawi"},{label:"Malaysia",value:"Malaysia"},{label:"Maldives",value:"Maldives"},{label:"Mali",value:"Mali"},{label:"Malta",value:"Malta"},{label:"Marshall Islands",value:"Marshall Islands"},{label:"Martinique",value:"Martinique"},{label:"Mauritania",value:"Mauritania"},{label:"Mauritius",value:"Mauritius"},{label:"Mayotte",value:"Mayotte"},{label:"Mexico",value:"Mexico"},{label:"Micronesia",value:"Micronesia"},{label:"Moldova",value:"Moldova"},{label:"Monaco",value:"Monaco"},{label:"Mongolia",value:"Mongolia"},{label:"Montserrat",value:"Montserrat"},{label:"Morocco",value:"Morocco"},{label:"Mozambique",value:"Mozambique"},{label:"Myanmar",value:"Myanmar"},{label:"Namibia",value:"Namibia"},{label:"Nauru",value:"Nauru"},{label:"Nepal",value:"Nepal"},{label:"Netherlands Antilles",value:"Netherlands Antilles"},{label:"Netherlands",value:"Netherlands"},{label:"New Caledonia",value:"New Caledonia"},{label:"New Zealand",value:"New Zealand"},{label:"Nicaragua",value:"Nicaragua"},{label:"Nigeria",value:"Nigeria"},{label:"Niger",value:"Niger"},{label:"Niue",value:"Niue"},{label:"Norfolk Island",value:"Norfolk Island"},{label:"Northern Mariana Islands",value:"Northern Mariana Islands"},{label:"Norway",value:"Norway"},{label:"Oman",value:"Oman"},{label:"Pakistan",value:"Pakistan"},{label:"Palau",value:"Palau"},{label:"Panama",value:"Panama"},{label:"Papua New Guinea",value:"Papua New Guinea"},{label:"Paraguay",value:"Paraguay"},{label:"Peru",value:"Peru"},{label:"Philippines",value:"Philippines"},{label:"Pitcairn",value:"Pitcairn"},{label:"Poland",value:"Poland"},{label:"Portugal",value:"Portugal"},{label:"Puerto Rico",value:"Puerto Rico"},{label:"Qatar",value:"Qatar"},{label:"Reunion",value:"Reunion"},{label:"Romania",value:"Romania"},{label:"Russian Federation",value:"Russian Federation"},{label:"Rwanda",value:"Rwanda"},{label:"S. Georgia and S. Sandwich Isls.",value:"S. Georgia and S. Sandwich Isls."},{label:"Saint Kitts and Nevis",value:"Saint Kitts and Nevis"},{label:"Saint Lucia",value:"Saint Lucia"},{label:"Saint Vincent and The Grenadines",value:"Saint Vincent and The Grenadines"},{label:"Samoa",value:"Samoa"},{label:"San Marino",value:"San Marino"},{label:"Sao Tome and Principe",value:"Sao Tome and Principe"},{label:"Saudi Arabia",value:"Saudi Arabia"},{label:"Senegal",value:"Senegal"},{label:"Seychelles",value:"Seychelles"},{label:"Sierra Leone",value:"Sierra Leone"},{label:"Singapore",value:"Singapore"},{label:"Slovak Republic",value:"Slovak Republic"},{label:"Slovenia",value:"Slovenia"},{label:"Solomon Islands",value:"Solomon Islands"},{label:"Somalia",value:"Somalia"},{label:"South Africa",value:"South Africa"},{label:"Spain",value:"Spain"},{label:"Sri Lanka",value:"Sri Lanka"},{label:"St. Helena",value:"St. Helena"},{label:"St. Pierre and Miquelon",value:"St. Pierre and Miquelon"},{label:"Sudan",value:"Sudan"},{label:"Suriname",value:"Suriname"},{label:"Svalbard and Jan Mayen Islands",value:"Svalbard and Jan Mayen Islands"},{label:"Swaziland",value:"Swaziland"},{label:"Sweden",value:"Sweden"},{label:"Switzerland",value:"Switzerland"},{label:"Syria",value:"Syria"},{label:"Taiwan",value:"Taiwan"},{label:"Tajikistan",value:"Tajikistan"},{label:"Tanzania",value:"Tanzania"},{label:"Thailand",value:"Thailand"},{label:"Togo",value:"Togo"},{label:"Tokelau",value:"Tokelau"},{label:"Tonga",value:"Tonga"},{label:"Trinidad and Tobago",value:"Trinidad and Tobago"},{label:"Tunisia",value:"Tunisia"},{label:"Turkey",value:"Turkey"},{label:"Turkmenistan",value:"Turkmenistan"},{label:"Turks and Caicos Islands",value:"Turks and Caicos Islands"},{label:"Tuvalu",value:"Tuvalu"},{label:"US Minor Outlying Islands",value:"US Minor Outlying Islands"},{label:"Uganda",value:"Uganda"},{label:"Ukraine",value:"Ukraine"},{label:"United Arab Emirates",value:"United Arab Emirates"},{label:"United Kingdom",value:"United Kingdom"},{label:"USA",value:"USA"},{label:"Uruguay",value:"Uruguay"},{label:"Uzbekistan",value:"Uzbekistan"},{label:"Vanuatu",value:"Vanuatu"},{label:"Vatican City State",value:"Vatican City State"},{label:"Venezuela",value:"Venezuela"},{label:"Viet Nam",value:"Viet Nam"},{label:"Virgin Islands (British)",value:"Virgin Islands (British)"},{label:"Virgin Islands (US)",value:"Virgin Islands (US)"},{label:"Wallis and Futuna Islands",value:"Wallis and Futuna Islands"},{label:"Western Sahara",value:"Western Sahara"},{label:"Yemen",value:"Yemen"},{label:"Yugoslavia",value:"Yugoslavia"},{label:"Zaire",value:"Zaire"},{label:"Zambia",value:"Zambia"},{label:"Zimbabwe",value:"Zimbabwe"}],Fi=[{label:"Select Nature of Project",value:""},{label:"MEPF Service",value:"MEPF Service"},{label:"BIM Service",value:"BIM Service"},{label:"Structural Engineering",value:"Structural Engineering"},{label:"Fabrication shop drawing",value:"Fabrication shop drawing"},{label:"Auto CAD Drafting",value:"Auto CAD Drafting"},{label:"Architectural services",value:"Architectural services"},{label:"Facade Shop Drawing",value:"Facade Shop Drawing"},{label:"Interior design services",value:"Interior design services"},{label:"3D Modeling",value:"3D Modeling"},{label:"Precast Detailing",value:"Precast Detailing"},{label:"Door and Window Shop Drawing",value:"Door and Window Shop Drawing"},{label:"Window shop drawing",value:"Window shop drawing"},{label:"Rebar Detailing",value:"Rebar Detailing"},{label:"Other",value:"Other"}],qi=({closeModel:n,downloadPDF:o})=>{var j,O,z,Y,Z,X,_,B,D,V,J,G;const{register:d,reset:p,handleSubmit:f,clearErrors:b,formState:{errors:g}}=Gr({mode:"onBlur"}),C=s=>{b(s)},w=async s=>{console.log(s);try{(await ye.post("/contactus/raqform/",{...s})).status===201?(Le.success("Your request is submit succuessfully"),n(),o()):Le.error("unable to process your request")}catch{Le.error("unable to process your request")}};return e.jsx(e.Fragment,{children:e.jsx("div",{className:"col-md-12 d-flex justify-content-center align-items-center flex-column",children:e.jsx("form",{className:"my-2 contactForm",onSubmit:f(w),children:e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-6",children:e.jsx(de,{label:"Name *",fieldName:"name",register:d,validationObject:ve.name,error:(j=g==null?void 0:g.name)==null?void 0:j.message,onChange:()=>C("name")})}),e.jsx("div",{className:"col-6",children:e.jsx(de,{label:"Company",fieldName:"company",register:d,validationObject:ve.company,error:(O=g==null?void 0:g.company)==null?void 0:O.message,onChange:()=>C("company")})}),e.jsx("div",{className:"col-6",children:e.jsx(de,{label:"Email Address*",fieldName:"email",register:d,validationObject:ve.email,error:(z=g==null?void 0:g.email)==null?void 0:z.message,onChange:()=>C("email")})}),e.jsx("div",{className:"col-6",children:e.jsx(de,{label:"Phone*",fieldName:"phoneNumber",register:d,validationObject:ve.phoneNumber,error:(Y=g==null?void 0:g.phoneNumber)==null?void 0:Y.message,onChange:()=>C("phoneNumber")})}),e.jsx("div",{className:"col-6",children:e.jsx(de,{label:"City/Address",fieldName:"cityAddress",register:d,validationObject:ve.cityAddress,error:(Z=g==null?void 0:g.cityAddress)==null?void 0:Z.message,onChange:()=>C("cityAddress")})}),e.jsx("div",{className:"col-6",children:e.jsx(de,{label:"State/Province",fieldName:"stateProvince",register:d,validationObject:ve.stateProvince,error:(X=g==null?void 0:g.stateProvince)==null?void 0:X.message,onChange:()=>C("stateProvince")})}),e.jsx("div",{className:"col-6",children:e.jsx(de,{type:"dropdown",label:"Nature of Project",fieldName:"natureofProject",register:d,options:Fi,validationObject:ve.natureofProject,error:(_=g==null?void 0:g.natureofProject)==null?void 0:_.message,onChange:()=>C("natureofProject")})}),e.jsx("div",{className:"col-6",children:e.jsx(de,{type:"dropdown",label:"Country *",fieldName:"country",register:d,options:Hi,validationObject:ve.country,error:(B=g==null?void 0:g.country)==null?void 0:B.message,onChange:()=>C("country")})}),e.jsx("div",{className:"col-12",children:e.jsx(de,{type:"textarea",label:"Description of your project  *",fieldName:"description",register:d,options:di(20),validationObject:ve.description,error:(D=g==null?void 0:g.description)==null?void 0:D.message,onChange:()=>C("description")})}),e.jsx("div",{className:"col-4",children:e.jsx(de,{type:"hidden",label:"Teams",fieldName:"teams",register:d,validationObject:ve.teams,error:(V=g==null?void 0:g.teams)==null?void 0:V.message,onChange:()=>C("teams")})}),e.jsx("div",{className:"col-4",children:e.jsx(de,{type:"hidden",label:"Teams",fieldName:"hangout",register:d,validationObject:ve.hangout,error:(J=g==null?void 0:g.hangout)==null?void 0:J.message,onChange:()=>C("hangout")})}),e.jsx("div",{className:"col-4",children:e.jsx(de,{type:"hidden",label:"Teams",fieldName:"other",register:d,validationObject:ve.other,error:(G=g==null?void 0:g.other)==null?void 0:G.message,onChange:()=>C("other")})}),e.jsx("div",{className:"d-flex justify-content-center flex-wrap flex-column flex-sm-row align-items-center gap-1 mt-3",children:e.jsx("button",{className:"btn btn-primary mx-3",children:"DOWNLOAD"})})]})})})})},Ui=({closeModel:n,downloadPDF:o})=>e.jsx("div",{className:"modal d-block modal-lg",tabIndex:"-1",children:e.jsx("div",{className:"modal-dialog modal-dialog-centered",children:e.jsxs("div",{className:"modal-content",children:[e.jsxs("div",{className:"modal-header",children:[e.jsx("h5",{className:"modal-title text-dark fw-bold",children:"Request For Quotation"}),e.jsx("button",{type:"button",className:"btn-close","data-bs-dismiss":"modal","aria-label":"Close",onClick:n})]}),e.jsx("div",{className:"modal-body px-4 py-3",children:e.jsx(qi,{closeModel:n,downloadPDF:o})})]})})}),Wi=()=>{const[n,o]=A.useState([]),[d,p]=A.useState(!1),[f,b]=A.useState(""),[g,C]=A.useState(""),w=Xr(),[j,O]=A.useState(!1),z=async()=>{var B;try{const D=await ye.get("/contactus/clientBrochures/");if((D==null?void 0:D.status)===200){const V=fi((B=D==null?void 0:D.data)==null?void 0:B.brochures);o(V)}}catch{Le.error("Unable to load Brochures  details")}};A.useEffect(()=>{z()},[]),A.useEffect(()=>{const B=()=>{O(window.scrollY>200)};return window.addEventListener("scroll",B),()=>window.removeEventListener("scroll",B)},[]);const Y=()=>{const B=document.createElement("a");B.download=g,B.href=w+f,B.target="_blank",B.click()},Z=(B,D)=>{b(B),C(D),X()},X=()=>{p(!d)},_=()=>{p(!d)};return e.jsxs("div",{className:`floatingButton ${j?"scrolled":""}`,children:[n.length===1&&e.jsx(Qr,{label:"BROCHURE",cssClass:"btn btn-primary p-3 text-uppercase",icon:"fa-download",handlerChange:()=>{var B,D,V,J;return Z((B=n[0])==null?void 0:B.path,(D=n[0])!=null&&D.brochures_downloadName?(V=n[0])==null?void 0:V.brochures_downloadName:(J=n[0])==null?void 0:J.originalname)}}),n.length>1&&e.jsxs("div",{class:"dropdown",children:[e.jsx("button",{class:"btn btn-primary mb-1 dropdown-toggle",type:"button",id:"dropdownMenuButton1","data-bs-toggle":"dropdown","aria-expanded":"false",children:"BROCHURES"}),e.jsx("ul",{class:"dropdown-menu","aria-labelledby":"dropdownMenuButton1",children:n==null?void 0:n.map(B=>e.jsxs("li",{children:[e.jsx("i",{class:"fa fa-file-pdf-o cursor-pointer fs-4 me-2","aria-hidden":"true"}),e.jsx("a",{href:"#!",onClick:()=>Z(B.path,B.brochures_downloadName?B.brochures_downloadName:B.originalname),className:"mx-1 text-dark",children:B.originalname})]}))})]}),d&&e.jsx(Ui,{closeModel:_,downloadPDF:Y}),d&&e.jsx(Ue,{})]})},Zi=({testimonis:n})=>{const[o,d]=A.useState(0);A.useEffect(()=>{if((n==null?void 0:n.length)>1){const f=(n==null?void 0:n.length)-1;o<0&&d(f),o>f&&d(0)}},[o,n]),A.useEffect(()=>{if((n==null?void 0:n.length)>1){let f=setInterval(()=>{d(o+1)},5e3);return()=>{clearInterval(f)}}},[o,n]);const p=n==null?void 0:n.map((f,b)=>{let g="nextSlide";return b===o&&(g="activeSlide"),(b===o-1||o===0&&b===(n==null?void 0:n.length)-1)&&(g="lastSlide"),e.jsxs("div",{className:`${g} article position-absolute`,children:[f.path?e.jsx("img",{src:Re(f.path),className:"rounded-circle my-4 testimonialImg shadow-lg",alt:"User"}):e.jsx("i",{className:"fa fa-user","aria-hidden":"true"}),e.jsx(he,{title:f.testimonial_title,cssClass:"mb-2 px-3 fs-3 fw-bold text-md-center title"}),e.jsx("p",{className:"w-75 m-auto mt-3 mb-5 px-3 px-md-5 fs-6",children:f.testimonial_description}),e.jsxs("div",{className:"d-flex justify-content-center gap-5",children:[e.jsxs(pe,{to:"",onClick:()=>d(o+1),children:[" ",e.jsx("i",{className:"fa fa-chevron-left fs-3","aria-hidden":"true"})]}),e.jsxs(pe,{to:"",onClick:()=>d(o-1),children:[" ",e.jsx("i",{className:"fa fa-chevron-right fs-3","aria-hidden":"true"})]})]})]},f.id)});return e.jsx(e.Fragment,{children:p})},Tr="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAfcSURBVHgB7Vy/c9NIFH5xwgwd8V+AEmCGDlNedaajO+jocDquIvwFOB0d0F13TsdVkIoS03HVmZ4QpbsKm+5u8uu+L3lmVutdS7KllZzzN6ORdyVLu5/e27f79u2KLLHEEkv8f7EiNUIURes48Yh4Xl1d5W85OTmJ9ZYRjhgYSU1QGYFKVrvRaLTPzs7urKystOSCvCwY4T8D/Ofz6elpH+l+VaQGJZCkgbAOKv8LKt+WAoFn9nHsygWZsQRCEAJBXBuEPS+atCnoQTJ3wWNfSkapBM5I3CHuj3EegYRztYTURjxDwqjid7I+SKVyp0wiSyEQxEUg4fcMxB3ieIf7BjAUmVXv1q1bLZAbgZw2kjzSSKVE7pSh2oUTCO62ITHPxW8QBjj2UKFeURXiB8M7H+DnU7mw4E7gnV28ckcKRGEEpkkd8j/i6H758qUvJeLmzZu06ts0VK7rtN44Hhb18QohkG0dJOCtOKQuFHGOMkVappZ9DQTGOLaKaBvnJlBV9qXjEo3AMxSyJxXixo0b7DaxSYnsa1q+VzIHVmUOgLznIO+FnU+pQ+F+QuE+ScUYDoeDa9eu7aFMEZK3zWvIu49rMhqNPsqMmJlAJa/ruLTz9evXDgr1j9QEKMsIRP7RbDapcW3zGtvseUiciUBVW1vyqLK/HhwczKUSZQIk9kHWoRq6q+N8JfE7SMytMbnbQDUYH6xskncPKjuQBQDq0NI6JIye1qEvOZCLQLVsfHFkZC8UeWN4SGRd7ubp4jQkByDq7BZEZh5euLVo5BEsM62wlb3OvqzkQOY2UI3GIyt7B23eb7KgQJs3sA0LrXWe9jCTCqvqHljZPVjbLbkE2NjY+GCNoDKrciYV5kjCTLMnz8G5XBJwaCcX3u4xMqtyKoHqknpsvbAUz0ZVoDcbdUy0h5RI1j3tv6kE0p9nZQ1CDc9YgSyVKAL7+/s9+g/NPEfdJzCVQJW+tpkH1X0oAYB3v2Q3g8fm5mYuyzgrqFlmOosUTiUQD+hYL9gLpbogbttIdkKQyE60LYUox9Np//ESqP69RNuHacZgwzS7IhKIRFsKgbbOIDrhJRBkta0HxyF9evTX4RRb2aWTqEM5c2BwPpPou99LINq6hPRBGl9LQLCp4BBRKiAR2DMTPu824SSQIuswHu8kMKoikfM1ZlqNiVONfRLYNhOcR6iq31cFiVrXQyu77brXSSDDLcw0PcxSISqSxITG2Zz8yHdlMlbFTGv8SaUITSLnqs00OIlc9zU8f7ZnsmKpAUKSyIl+Mw1OnJP3E94YDQAamnnwutQtDM7l2CUK9RDho5yZaXy8ph0FNiGBV65cicw0DYjUDAEl0TYkE5Z4gsCjo6PETfjS36WGCEEihCfhA11bW4vse9YkANQxsC3hQBKlaIfv8fFxugRiCBeZafsr5IXO4oUkb4xOAa6whAqPQ45N5JpUWjRA5aRsTBAI852wMpDApswBHZwHHUcTDPctwPlx3Uxo4GcCrk+UNNONRtbAby/QFlGFC1djX3eG5GG2sCMB4FLhWJKFuS41RAjyIHEbZhpGZGIlgItA+6ZIaoaAkmcLT2zfMEGg9rQTJLLAUhOEIo9x2FbWKHasRfE5ExKjD9s7XRVCtnkYUERmmot6XPf5nAmJm1HAllSM0AbDdl/5hrROAh3uK69LOwSqsLZ49s9m2ufS83Wk7ZujqtrBKsjTGUlb6/que50EsrF0zI92JDCq6ufpmpMfoEc+9ixm9A7l8KfMM1NloOJOcmIyHaOznu/GadOaPTNNkQ4Vp6LvmwjmDEGe1jGysvu++70EutQ4S7BNUbDboFDDM0cde9NmJKd6Y2YJtikQr41yBCGPcdP2fDiakd1p/0md67CjNymVqMw9CQCue+M5VEgJ6vqXKfk0Hvv7++1p/0mNkV5fXz80o7Q0hviQ8cVSMr59+xbzkADgkjCcnph5kL6ttPdnmm3zxBBvxDXa/GEeeCx+phm+TB5pjZSyY4jfyiWBLpaMzLysMeCZljlwrVmz2fwXP++P81SV51qoVwdw+Qbq8sTK5vKNTMFUuSbMHarML9WBKu/KAgLkPYb09cw8Og1A3t2sz8g1qeRQZYr/K5p/WTDoUq9ExK0uxM4VA56LQJ3Mtl/AUJAPi0Sib7Eh/J5becP4ci93RZsXoz1ktMJ9I/sqVPsR2sS/cf2z1Biqtm9kMkzjGfp8byQnZlovPBwOPzkWL5PEB3U2LLrej2p71brEReIvZAbMvGKdi5d9K8CR3wKRf9J6Sw3AiDOU6b3HJUfyujIj5tozQUm01Zng3gQPMIr5HmLEMg0cYeCjvsdx23H52aySN0YhcX8a/8KIqMi+VvQ+LXnKNGXbqRHK+7CIMXZhgZPqBn/rcIWfI8Q+VlqOacSdOwjgIO3UauMdE5ubm12cvH5D9rW45oTLJorc+gmnxzRivg8oF/1XtneFrrYqnEBCpbFrLxWzoZsoftQZrzjr1gF8PueqdbqVUw3RtPuLlrrEs6VE6D5WXXuKMAUcDcT8MY6GGkfI6+Y5UdYHhdh2qlQCxyCRlIA0iSwIIyXuVQhHbBACxxirHn52ckplKkganvlOt9UL1v8MSqAJdm61HaPVbOninqyxiPSSD9Qg9XXzxsu/CW0aSCqXWehWn+bqIKrl6Pj4OBZPlNQSSyyxxBLh8R88cXSgocvBFQAAAABJRU5ErkJggg==",Ki=({title:n,cssClass:o,linkClass:d,moreLink:p,dimensions:f})=>{const b={homecareers:!1},g="homePageCareer",{isAdmin:C,hasPermission:w}=Yr(),[j,O]=A.useState(b),[z,Y]=A.useState(!1),[Z,X]=A.useState([]),{serviceMenu:_}=Se(D=>D.serviceMenu),B=(D,V)=>{O(J=>({...J,[D]:V})),Y(!z),document.body.style.overflow="hidden"};return A.useEffect(()=>{const D=async()=>{try{const V=await ye.get(`banner/clientBannerIntro/${g}/`);(V==null?void 0:V.status)===200&&X(V.data.imageModel)}catch{console.log("unable to access ulr because of server is down")}};j.homecareers||D()},[j.homecareers]),e.jsxs("div",{className:"row h-100",children:[e.jsx("div",{className:"d-none col-lg-6 p-0 ABriefImg d-md-flex justify-content-center align-items-center",children:e.jsxs("div",{className:"bg-white text-black m-3 ms-lg-5 p-4 py-5",children:[e.jsx("p",{children:e.jsxs("svg",{width:"246",height:"43",viewBox:"0 0 246 43",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{d:"M43.8336 15.4223L42.6937 11.9186C42.6193 11.6897 42.4059 11.5348 42.1648 11.5348H30.2991L26.6727 0.383794C26.5983 0.154886 26.3849 0 26.1438 0H22.4555H18.7684C18.5273 0 18.3138 0.154886 18.2394 0.383794L14.5726 11.6563H2.83525C2.59415 11.6563 2.38075 11.8112 2.30635 12.0401L1.16705 15.5438L0.0272439 19.0475C-0.0471562 19.2764 0.0342938 19.5271 0.229244 19.6686L9.82846 26.6355L6.2015 37.7864C6.1271 38.0153 6.20855 38.2659 6.4035 38.4075L9.38691 40.5727C9.38746 40.5731 9.38816 40.5732 9.38871 40.5736L12.3704 42.7379C12.4681 42.8087 12.5827 42.8439 12.6972 42.8439C12.8118 42.8439 12.9264 42.8087 13.0241 42.7379L22.6234 35.7712L32.1187 42.663C32.2164 42.7338 32.331 42.7691 32.4456 42.7691C32.5602 42.7691 32.6747 42.7338 32.7725 42.663L35.7564 40.4973L38.7399 38.3321C38.9348 38.1905 39.0163 37.9399 38.9419 37.711L35.2751 26.4387L44.7708 19.5466C44.9657 19.405 45.0472 19.1544 44.9728 18.9255L43.8336 15.4223ZM41.7608 12.6458L42.6508 15.3819L39.662 17.5509L33.774 21.8238L33.5847 21.242L32.9959 19.4313L37.6642 16.0434C37.8592 15.9018 37.9406 15.6512 37.8662 15.4223C37.7918 15.1934 37.5784 15.0385 37.3373 15.0385L22.1462 15.038L22.9243 12.6458H26.2074H29.895H41.7608ZM19.6719 19.0475C19.6717 19.0484 19.672 19.0493 19.6717 19.0502L18.4762 22.7262L16.3345 21.172L20.6119 8.02186L21.9353 12.0903L21.7704 12.5972L20.8514 15.4218L19.6719 19.0475ZM24.4343 19.7747L25.6178 23.4127L22.5199 25.6611L19.422 23.413L20.6054 19.7748L24.4343 19.7747ZM21.5738 26.3477L19.4324 27.9019L8.2346 19.7747H12.5164L21.5738 26.3477ZM19.7594 29.038L22.847 26.7973C22.8475 26.797 22.8478 26.7965 22.8483 26.7961L25.9792 24.5239L26.797 27.0387L25.2221 28.1817L15.5994 35.1653L16.9223 31.097L19.7594 29.038ZM25.6035 19.7747H28.2506L32.5276 32.9252L29.0638 30.4104L28.7182 29.3485L25.6035 19.7747ZM28.6547 18.6635H24.8383C24.8375 18.6635 24.8368 18.6637 24.8361 18.6637H20.9668L21.7848 16.1489L35.6256 16.1494L32.1608 18.6637H28.6564C28.6558 18.6638 28.6553 18.6635 28.6547 18.6635ZM25.7397 1.11097L29.1299 11.5348H26.6114L23.2209 1.11097H25.7397ZM15.5058 12.3834C15.5059 12.3831 15.5057 12.3828 15.5058 12.3824L19.1723 1.11097H22.0514L25.4418 11.5348H22.9241L21.1408 6.05274C21.0664 5.82384 20.853 5.66895 20.6118 5.66895C20.3707 5.66895 20.1573 5.82384 20.0829 6.05274L15.3883 20.4852L13.351 19.0069L14.3659 15.8872L15.5058 12.3834ZM3.23925 12.7673H14.2112L13.4328 15.1601H2.4611L3.23925 12.7673ZM1.20995 19.0071L2.1 16.271H13.0715L12.2931 18.6637H6.523C6.2819 18.6637 6.06845 18.8186 5.99405 19.0475C5.91965 19.2764 6.00115 19.5271 6.1961 19.6686L18.4863 28.5885L16.4489 30.0671L16.4473 30.066L13.7931 28.1391L10.8091 25.9739C10.809 25.9739 10.8092 25.9739 10.8091 25.9739L1.20995 19.0071ZM7.3842 37.746L10.7744 27.322L12.8122 28.801L9.42166 39.2245L7.3842 37.746ZM22.2964 34.635C22.296 34.6353 22.2958 34.6356 22.2955 34.6359L12.6972 41.6018L10.3682 39.9112L12.8679 32.2251L13.7584 29.4877L14.8021 30.2451L15.7952 30.9661L14.0125 36.4482C13.9381 36.6771 14.0195 36.9277 14.2145 37.0693C14.41 37.2109 14.6728 37.2109 14.8683 37.0693L27.1587 28.1495L27.9369 30.5416L26.748 31.4045L25.2811 32.4688C25.2807 32.4691 25.2802 32.4692 25.2798 32.4695L22.2964 34.635ZM32.4456 41.5269L23.5695 35.0846L25.6068 33.606L34.4835 40.048L32.4456 41.5269ZM37.7592 37.6706L35.4297 39.3614L26.5531 32.9192L28.1855 31.7345L28.5907 31.4405L33.2586 34.829C33.4541 34.9705 33.7169 34.9705 33.9124 34.829C34.1073 34.6874 34.1888 34.4368 34.1144 34.2079L29.4203 19.7748H31.9379L37.7592 37.6706ZM34.9137 25.3275L34.1355 22.9348L37.1243 20.7658L43.0124 16.4928L43.79 18.8851L34.9137 25.3275Z",fill:"black"}),e.jsx("path",{d:"M77.1197 21.9309C77.0029 19.307 75.3394 17.6744 72.9462 15.6919H68.9186V21.9309H66V3.30115H68.0138H68.9186H73.9968C74.814 3.30115 75.5729 3.44693 76.3317 3.70932C77.0613 4.00086 77.7618 4.43818 78.3163 4.96296C79.5713 6.12915 80.2717 7.73265 80.2717 9.48193C80.2717 11.2604 79.5713 12.8639 78.3163 14.0009C77.8493 14.4674 77.2948 14.8172 76.7111 15.1088C77.2072 15.6044 77.6742 16.1 78.112 16.6831C79.3378 18.2575 79.9507 19.9484 80.0382 21.8143V21.9309H77.1197ZM68.9186 12.7764H73.9968C75.6312 12.7764 77.3532 11.6102 77.3532 9.48193C77.3532 7.35364 75.6312 6.21661 73.9968 6.21661H68.9186V12.7764ZM86.1088 21.9309H83.1903V3.30115H86.1088V21.9309ZM97.6955 22.1933C94.8937 22.1933 91.3038 21.4062 90.1364 20.9688L91.1579 18.2283C92.2378 18.6365 96.7615 19.5694 98.8921 19.1904C99.6217 19.0738 100.205 18.4032 100.322 17.6452C100.439 16.654 99.7093 15.6919 98.2792 15.0213C97.4036 14.6131 95.7692 13.9134 94.4559 13.3595C93.6971 13.0388 93.0258 12.7472 92.6172 12.5723C91.5665 12.1058 90.691 11.377 90.1072 10.5315C89.5527 9.68601 89.2609 8.72391 89.29 7.73265C89.3192 6.79971 89.6111 5.92507 90.1656 5.16705C90.7201 4.37987 91.5081 3.79678 92.4421 3.44693C93.6971 2.9513 95.5066 2.9513 97.8122 3.35946C99.5634 3.70932 101.139 4.20495 101.811 4.43818L100.789 7.17872C100.264 6.97463 98.8337 6.53731 97.2577 6.24577C94.8645 5.77929 93.8138 6.04169 93.4928 6.1583C92.7048 6.44985 92.2378 7.0621 92.2086 7.82012C92.1794 8.6656 92.7923 9.45278 93.8138 9.91925C94.1932 10.065 94.8645 10.3566 95.6233 10.6773C96.9367 11.2604 98.6002 11.9601 99.5342 12.3974C100.877 13.0388 101.869 13.8551 102.511 14.8755C103.124 15.8668 103.357 16.9455 103.212 18.0534C102.949 20.0651 101.373 21.6977 99.4174 22.0476C98.8921 22.135 98.3084 22.1933 97.6955 22.1933ZM117.483 3.30115H120.402V21.9309H117.483V13.447H109.37V21.9309H106.451V3.30115H109.37V10.5315H117.483V3.30115ZM140.715 22.1933C137.913 22.1933 134.323 21.4062 133.156 20.9688L134.177 18.2283C135.257 18.6365 139.781 19.5694 141.912 19.1904C142.641 19.0738 143.225 18.4032 143.342 17.6452C143.458 16.654 142.729 15.6919 141.299 15.0213C140.423 14.6131 138.789 13.9134 137.475 13.3595C136.717 13.0388 136.045 12.7472 135.637 12.5723C134.586 12.1058 133.71 11.377 133.127 10.5315C132.572 9.68601 132.28 8.72391 132.309 7.73265C132.339 6.79971 132.631 5.92507 133.185 5.16705C133.74 4.37987 134.528 3.79678 135.462 3.44693C136.717 2.9513 138.526 2.9513 140.832 3.35946C142.583 3.70932 144.159 4.20495 144.83 4.43818L143.809 7.17872C143.283 6.97463 141.853 6.53731 140.277 6.24577C137.884 5.77929 136.833 6.04169 136.512 6.1583C135.724 6.44985 135.257 7.0621 135.228 7.82012C135.199 8.6656 135.812 9.45278 136.833 9.91925C137.213 10.065 137.884 10.3566 138.643 10.6773C139.956 11.2604 141.62 11.9601 142.554 12.3974C143.896 13.0388 144.888 13.8551 145.531 14.8755C146.143 15.8668 146.377 16.9455 146.231 18.0534C145.968 20.0651 144.392 21.6977 142.437 22.0476C141.912 22.135 141.328 22.1933 140.715 22.1933ZM162.808 3.272V3.30115C162.867 4.90466 162.575 6.59562 161.991 8.25744C160.853 11.5228 158.781 14.1467 157.059 15.9251V21.9309H154.14V15.9251C152.389 14.1467 150.317 11.5228 149.179 8.25744C148.595 6.59562 148.303 4.90466 148.362 3.30115V3.272H151.251C151.105 7.44111 153.732 11.1146 155.6 13.1846C157.438 11.1146 160.065 7.44111 159.919 3.272H162.808ZM173.286 22.1933C170.484 22.1933 166.894 21.4062 165.727 20.9688L166.748 18.2283C167.828 18.6365 172.352 19.5694 174.483 19.1904C175.212 19.0738 175.796 18.4032 175.913 17.6452C176.029 16.654 175.3 15.6919 173.87 15.0213C172.994 14.6131 171.36 13.9134 170.046 13.3595C169.288 13.0388 168.616 12.7472 168.208 12.5723C167.157 12.1058 166.281 11.377 165.698 10.5315C165.143 9.68601 164.851 8.72391 164.881 7.73265C164.91 6.79971 165.202 5.92507 165.756 5.16705C166.311 4.37987 167.099 3.79678 168.033 3.44693C169.288 2.9513 171.097 2.9513 173.403 3.35946C175.154 3.70932 176.73 4.20495 177.401 4.43818L176.38 7.17872C175.854 6.97463 174.424 6.53731 172.848 6.24577C170.455 5.77929 169.404 6.04169 169.083 6.1583C168.295 6.44985 167.828 7.0621 167.799 7.82012C167.77 8.6656 168.383 9.45278 169.404 9.91925C169.784 10.065 170.455 10.3566 171.214 10.6773C172.527 11.2604 174.191 11.9601 175.125 12.3974C176.467 13.0388 177.459 13.8551 178.102 14.8755C178.714 15.8668 178.948 16.9455 178.802 18.0534C178.539 20.0651 176.963 21.6977 175.008 22.0476C174.483 22.135 173.899 22.1933 173.286 22.1933ZM192.957 3.272V6.18746H188.404V21.9309H185.486V6.18746H180.962V3.272H192.957ZM198.94 18.9863H206.849V21.9018H196.021V3.272H206.178V6.18746H198.94V10.5023H205.653V13.4178H198.94V18.9863ZM212.103 21.9309H209.155L211.081 3.272H215.868L219.457 17.6452L223.047 3.272H227.834L229.76 21.9309H226.812L225.236 6.44985L221.15 21.9309H217.765L213.708 6.44985L212.103 21.9309ZM240.442 22.1933C237.64 22.1933 234.05 21.4062 232.883 20.9688L233.904 18.2283C234.984 18.6365 239.508 19.5694 241.638 19.1904C242.368 19.0738 242.952 18.4032 243.069 17.6452C243.185 16.654 242.456 15.6919 241.026 15.0213C240.15 14.6131 238.516 13.9134 237.202 13.3595C236.443 13.0388 235.772 12.7472 235.364 12.5723C234.313 12.1058 233.437 11.377 232.854 10.5315C232.299 9.68601 232.007 8.72391 232.036 7.73265C232.066 6.79971 232.357 5.92507 232.912 5.16705C233.467 4.37987 234.255 3.79678 235.188 3.44693C236.443 2.9513 238.253 2.9513 240.559 3.35946C242.31 3.70932 243.886 4.20495 244.557 4.43818L243.536 7.17872C243.01 6.97463 241.58 6.53731 240.004 6.24577C237.611 5.77929 236.56 6.04169 236.239 6.1583C235.451 6.44985 234.984 7.0621 234.955 7.82012C234.926 8.6656 235.539 9.45278 236.56 9.91925C236.94 10.065 237.611 10.3566 238.37 10.6773C239.683 11.2604 241.347 11.9601 242.281 12.3974C243.623 13.0388 244.615 13.8551 245.257 14.8755C245.87 15.8668 246.104 16.9455 245.958 18.0534C245.695 20.0651 244.119 21.6977 242.164 22.0476C241.638 22.135 241.055 22.1933 240.442 22.1933Z",fill:"black"}),e.jsx("path",{d:"M72.2581 30.2673V31.2866H69.6732V38.2855H68.5849V31.2866H66V30.2673H72.2581ZM76.5572 30.2673V33.5969H80.7179V30.2673H81.8063V38.2855H80.7179V34.6162H76.5572V38.2855H75.4688V30.2673H76.5572ZM87.0123 30.2673V38.2855H85.9239V30.2673H87.0123ZM92.5584 30.2673L96.9799 36.8586H97.0026V30.2673H98.0909V38.2855H96.7078L92.241 31.6943H92.2183V38.2855H91.1299V30.2673H92.5584ZM103.297 30.2673V33.7328H103.388L106.936 30.2673H108.455L104.578 33.9707L108.716 38.2855H107.129L103.388 34.2764H103.297V38.2855H102.209V30.2673H103.297ZM122.167 30.2673V31.2866H119.582V38.2855H118.493V31.2866H115.908V30.2673H122.167ZM130.558 30.2673V31.2866H126.466V33.6762H130.275V34.6955H126.466V37.2663H130.762V38.2855H125.377V30.2673H130.558ZM138.043 30.0635C138.61 30.0635 139.141 30.1692 139.636 30.3806C140.131 30.592 140.537 30.9015 140.855 31.3092L139.948 32.0001C139.456 31.3885 138.81 31.0827 138.009 31.0827C137.14 31.0827 136.424 31.3923 135.861 32.0114C135.298 32.6305 135.016 33.4081 135.016 34.3444C135.016 35.2504 135.294 35.9979 135.849 36.5868C136.405 37.1757 137.125 37.4701 138.009 37.4701C138.893 37.4701 139.593 37.1115 140.106 36.3942L141.025 37.0851C140.707 37.5079 140.284 37.8476 139.755 38.1043C139.226 38.361 138.636 38.4894 137.986 38.4894C137.215 38.4894 136.516 38.3025 135.889 37.9288C135.262 37.5551 134.767 37.0416 134.404 36.3886C134.041 35.7355 133.86 35.0503 133.86 34.3331C133.86 33.0949 134.249 32.0737 135.027 31.2696C135.806 30.4655 136.811 30.0635 138.043 30.0635ZM145.483 30.2673V33.5969H149.643V30.2673H150.732V38.2855H149.643V34.6162H145.483V38.2855H144.394V30.2673H145.483ZM156.244 36.9945L155.291 39.7805H154.362L155.144 36.9945H156.244ZM168.946 30.0635C169.513 30.0635 170.044 30.1692 170.539 30.3806C171.034 30.592 171.44 30.9015 171.757 31.3092L170.851 32.0001C170.359 31.3885 169.713 31.0827 168.912 31.0827C168.043 31.0827 167.327 31.3923 166.763 32.0114C166.2 32.6305 165.919 33.4081 165.919 34.3444C165.919 35.2504 166.197 35.9979 166.752 36.5868C167.308 37.1757 168.028 37.4701 168.912 37.4701C169.796 37.4701 170.495 37.1115 171.009 36.3942L171.928 37.0851C171.61 37.5079 171.187 37.8476 170.658 38.1043C170.129 38.361 169.539 38.4894 168.889 38.4894C168.118 38.4894 167.419 38.3025 166.792 37.9288C166.165 37.5551 165.669 37.0416 165.307 36.3886C164.944 35.7355 164.762 35.0503 164.762 34.3331C164.762 33.0949 165.152 32.0737 165.93 31.2696C166.709 30.4655 167.714 30.0635 168.946 30.0635ZM176.385 30.2673V33.5969H180.546V30.2673H181.634V38.2855H180.546V34.6162H176.385V38.2855H175.297V30.2673H176.385ZM189.437 30.0635C190.631 30.0635 191.627 30.4599 192.424 31.2526C193.221 32.0454 193.62 33.0533 193.62 34.2764C193.62 35.0541 193.442 35.7657 193.087 36.4112C192.732 37.0568 192.231 37.5645 191.585 37.9345C190.939 38.3045 190.223 38.4894 189.437 38.4894C188.658 38.4894 187.948 38.3063 187.305 37.9401C186.663 37.574 186.16 37.0681 185.797 36.4226C185.435 35.777 185.253 35.0616 185.253 34.2764C185.253 33.0836 185.644 32.0831 186.427 31.2753C187.209 30.4675 188.212 30.0635 189.437 30.0635ZM186.41 34.2764C186.41 35.1825 186.693 35.9412 187.26 36.5528C187.827 37.1644 188.552 37.4701 189.437 37.4701C190.306 37.4701 191.028 37.1681 191.602 36.5641C192.177 35.9601 192.464 35.1975 192.464 34.2764C192.464 33.3629 192.18 32.6022 191.613 31.9944C191.047 31.3866 190.317 31.0828 189.425 31.0828C188.564 31.0828 187.846 31.3848 187.271 31.9888C186.697 32.5928 186.41 33.3554 186.41 34.2764ZM200.923 30.0635C202.118 30.0635 203.113 30.4599 203.911 31.2526C204.708 32.0454 205.107 33.0533 205.107 34.2764C205.107 35.0541 204.929 35.7657 204.574 36.4112C204.219 37.0568 203.718 37.5645 203.072 37.9345C202.426 38.3045 201.709 38.4894 200.923 38.4894C200.145 38.4894 199.435 38.3063 198.792 37.9401C198.15 37.574 197.647 37.0681 197.284 36.4226C196.921 35.777 196.74 35.0616 196.74 34.2764C196.74 33.0836 197.131 32.0831 197.913 31.2753C198.696 30.4675 199.699 30.0635 200.923 30.0635ZM197.896 34.2764C197.896 35.1825 198.18 35.9412 198.747 36.5528C199.314 37.1644 200.039 37.4701 200.923 37.4701C201.793 37.4701 202.514 37.1681 203.089 36.5641C203.663 35.9601 203.95 35.1975 203.95 34.2764C203.95 33.3629 203.667 32.6022 203.1 31.9944C202.533 31.3866 201.804 31.0828 200.912 31.0828C200.051 31.0828 199.333 31.3848 198.758 31.9888C198.184 32.5928 197.896 33.3554 197.896 34.2764ZM211.027 30.0635C212.07 30.0635 212.841 30.3693 213.34 30.9809L212.456 31.785C212.32 31.5736 212.127 31.4037 211.877 31.2753C211.628 31.147 211.341 31.0828 211.016 31.0828C210.547 31.0828 210.171 31.198 209.888 31.4282C209.604 31.6585 209.463 31.9548 209.463 32.3172C209.463 32.9213 209.863 33.344 210.664 33.5857L211.673 33.9141C212.24 34.0953 212.673 34.3482 212.971 34.6729C213.27 34.9975 213.419 35.443 213.419 36.0092C213.419 36.7492 213.157 37.3475 212.631 37.8043C212.106 38.261 211.439 38.4895 210.63 38.4895C209.474 38.4895 208.62 38.1195 208.068 37.3796L208.964 36.6095C209.138 36.8813 209.376 37.0927 209.678 37.2437C209.98 37.3947 210.309 37.4702 210.664 37.4702C211.11 37.4702 211.488 37.3418 211.798 37.0851C212.108 36.8284 212.263 36.5113 212.263 36.1338C212.263 35.8545 212.168 35.6204 211.979 35.4317C211.79 35.2429 211.45 35.073 210.959 34.922L210.245 34.6842C209.527 34.4426 209.024 34.1349 208.737 33.7612C208.45 33.3875 208.306 32.9062 208.306 32.3172C208.306 31.6906 208.559 31.1583 209.066 30.7204C209.572 30.2825 210.226 30.0635 211.027 30.0635ZM222.265 30.2673V31.2866H218.172V33.6762H221.981V34.6955H218.172V37.2663H222.469V38.2855H217.083V30.2673H222.265ZM232.212 30.2673V35.2164C232.212 35.8733 232.395 36.4132 232.762 36.8359C233.128 37.2587 233.618 37.4701 234.23 37.4701C234.842 37.4701 235.331 37.2587 235.698 36.8359C236.064 36.4131 236.248 35.8733 236.248 35.2164V30.2673H237.336V35.3976C237.336 35.9488 237.206 36.4641 236.945 36.9435C236.684 37.423 236.314 37.8004 235.834 38.076C235.354 38.3516 234.819 38.4894 234.23 38.4894C233.323 38.4894 232.578 38.1931 231.996 37.6004C231.414 37.0077 231.123 36.2734 231.123 35.3976V30.2673H232.212ZM243.608 30.0635C244.651 30.0635 245.422 30.3693 245.921 30.9809L245.036 31.785C244.9 31.5736 244.708 31.4037 244.458 31.2753C244.209 31.147 243.922 31.0828 243.597 31.0828C243.128 31.0828 242.752 31.198 242.468 31.4282C242.185 31.6585 242.043 31.9548 242.043 32.3172C242.043 32.9213 242.444 33.344 243.245 33.5857L244.254 33.9141C244.821 34.0953 245.254 34.3482 245.552 34.6729C245.851 34.9975 246 35.443 246 36.0092C246 36.7492 245.737 37.3475 245.212 37.8043C244.687 38.261 244.02 38.4895 243.211 38.4895C242.055 38.4895 241.201 38.1195 240.649 37.3796L241.544 36.6095C241.718 36.8813 241.956 37.0927 242.259 37.2437C242.561 37.3947 242.89 37.4702 243.245 37.4702C243.691 37.4702 244.069 37.3418 244.379 37.0851C244.689 36.8284 244.844 36.5113 244.844 36.1338C244.844 35.8545 244.749 35.6204 244.56 35.4317C244.371 35.2429 244.031 35.073 243.54 34.922L242.826 34.6842C242.108 34.4426 241.605 34.1349 241.318 33.7612C241.031 33.3875 240.887 32.9062 240.887 32.3172C240.887 31.6906 241.14 31.1583 241.647 30.7204C242.153 30.2825 242.807 30.0635 243.608 30.0635Z",fill:"black"})]})}),e.jsx("ul",{className:"mt-5 list-unstyled servicesList",children:_.length>0?_.slice(0,3).map((D,V)=>e.jsxs("li",{children:[e.jsx("img",{src:Tr,alt:""}),e.jsx(pe,{to:`/${vi(D.services_page_title)}/`,onClick:()=>{hi(D)},children:D.services_page_title})]},V)):""})]})}),e.jsxs("div",{className:"col-12 col-lg-6 p-4 d-flex justify-content-center align-items-start flex-column position-relative briefServices",children:[C&&w&&e.jsx(fe,{editHandler:()=>B("homecareers",!0)}),e.jsxs("div",{className:"d-flex align-items-center mb-5",children:[e.jsx("i",{className:"fa fa-angle-left text-muted fs-1 me-2","aria-hidden":"true"}),e.jsx(he,{title:"OUR WORK LOCATIONS",cssClass:"fs-4 fw-medium"})]}),Z?e.jsx(he,{title:Z.banner_title,cssClass:o}):"",e.jsx("p",{className:"lh-lg mt-md-3",children:Z!=null&&Z.banner_descripiton?Z.banner_descripiton:"upload Description"}),e.jsx("div",{children:e.jsx(pe,{to:"/about",children:e.jsx("img",{src:Tr,alt:"circlearrow"})})})]}),j.homecareers?e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx($r,{editHandler:B,componentType:"homecareers",popupTitle:"Home Careers Banner",pageType:g,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:Jr(g),dimensions:f})}):"",z&&e.jsx(Ue,{})]})},Gi=xe.div`

.serviceOffered  {
    img {
        border-radius: 50px;
        height: 350px;
        width: 300px;
        object-fit:cover;
        border: 3px solid ${({theme:n})=>n.gray};
        filter: gray; /* IE6-9 */
        -webkit-filter: grayscale(1); /* Google Chrome, Safari 6+ & Opera 15+ */
        filter: grayscale(1); /* Microsoft Edge and Firefox 35+ */
        object-fit: cover;
        cursor: pointer;
        transition: .9s ease;

        &:hover {
            -webkit-filter: grayscale(0);
            filter: none;
            border: 3px solid ${({theme:n})=>n.black};

            + h4 {
                letter-spacing: 5px;
            }
        }

        + h4 {
           
            letter-spacing: 0px;
            transition: all .4s ease-in;
        }
        
    }
}

@media (max-width: 768px) {
    .serviceOffered  {
        img {
            height: 250px;
            width: 200px;
        }
    }
}

.serviceOffered  + .dcarousel {
    width: 90vw;
    height: 90vh;
    top: 5vh !important;
}

.serviceOffered  + .dcarousel .carousel-item img {
    object-fit: cover;
    width: 90vw !important;
    height: 90vh !important;
    margin: 0 auto;
}
  
`,Qi=({getBannerAPIURL:n,componentEdit:o})=>{const[d,p]=A.useState([]),[f,b]=A.useState(!1),[g,C]=A.useState(null);A.useEffect(()=>{const O=async()=>{try{const z=await ye.get(n);if((z==null?void 0:z.status)===200){let Y=Object.keys(z.data);const Z=ei(z.data[Y][0]),X=Ie(z.data[Y],Z);p(X)}}catch{console.log("unable to access ulr because of server is down")}};o.serviceOffered||O()},[o.serviceOffered,n]);const w=O=>{const z=d.find(Y=>Y.id===O);b(!f),C(z)},j=()=>{b(!f)};return e.jsxs(Gi,{children:[e.jsx("div",{className:"row serviceOffered",children:e.jsx("div",{className:"col-md-10 offset-md-1",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:d.length>0&&(d==null?void 0:d.map((O,z)=>e.jsxs("div",{className:"col-sm-6 col-md-4 mb-4 text-center",children:[e.jsx("img",{src:Re(O.path),alt:O.alternitivetext,onClick:()=>w(O.id),className:"img-fluid"}),e.jsx("h4",{className:"my-3 text-uppercase",children:O.carouse_title})]},O.id)))})})})}),f&&e.jsx(zi,{obj:g,all:d,closeCarousel:j}),f&&e.jsx(Ue,{closeModel:j})]})},Xi=xe.div`
    .fatures {
        padding: 80px 0;
        margin-top: 20px;
        margin-bottom: 50px;
        background-color: ${({theme:n})=>n.primaryColor};
        color: ${({theme:n})=>n.white};
        display: flex;
        flex-direction: column;
        justify-content-center;
        align-items: center;

        a {
            color: ${({theme:n})=>n.white};
            svg {
                stroke: ${({theme:n})=>n.white};
            }

        }

        .box1, .box2 {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            gap: 1rem;
            padding: 0;
        }

        .title {
            font-size: 3rem;
        }

        .box1 img, .box2 img {
            width: 30%;
        }

        .box1 {
            background-color: ${({theme:n})=>n.teritoryColor};
            
        }
        .box2 {
            background-color: ${({theme:n})=>n.secondaryColor};
        }
        .decImg {
            width: 100%;
            object-fit: cover;
            object-position: center;
        }

        @media (max-width: 991px) {
            .decImg {
                height: 200px;
                
            }
            .box1, .box2 {
                padding: 25px
            }
        }
}
`,Yi="/static/assets/features-img-C8A51Jr8.jpg",$i="/static/assets/features-img1-B_1zXtm0.jpg",Ji="data:image/svg+xml,%3csvg%20width='125'%20height='98'%20viewBox='0%200%20125%2098'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M95.3168%2036.4818H65.6293V47.0908C65.6293%2054.6118%2059.3208%2060.7309%2051.5669%2060.7309C43.813%2060.7309%2037.5044%2054.6118%2037.5044%2047.0908V24.0542L24.8286%2031.4426C21.0591%2033.6212%2018.7544%2037.5806%2018.7544%2041.8242V50.785L3.12945%2059.5374C0.141173%2061.2046%20-0.893981%2064.9177%200.844297%2067.8162L16.4693%2094.0734C18.188%2096.972%2022.0161%2097.9571%2025.0044%2096.29L45.1997%2084.98H71.8793C78.7738%2084.98%2084.3793%2079.5429%2084.3793%2072.8555H87.5043C90.9613%2072.8555%2093.7543%2070.1464%2093.7543%2066.7932V54.6687H95.3168C97.9144%2054.6687%20100.004%2052.6416%20100.004%2050.122V41.0286C100.004%2038.5089%2097.9144%2036.4818%2095.3168%2036.4818ZM124.164%2029.3966L108.539%203.13934C106.821%200.240819%20102.993%20-0.744301%20100.004%200.922825L79.809%2012.2328H59.8481C57.5043%2012.2328%2055.2192%2012.8769%2053.227%2014.0704L46.6841%2018.0298C44.8481%2019.1286%2043.7544%2021.0799%2043.7544%2023.1638V47.0908C43.7544%2051.2776%2047.2505%2054.6687%2051.5669%2054.6687C55.8833%2054.6687%2059.3793%2051.2776%2059.3793%2047.0908V30.4196H95.3168C101.352%2030.4196%20106.254%2035.1747%20106.254%2041.0286V46.4278L121.879%2037.6754C124.868%2035.9893%20125.883%2032.2951%20124.164%2029.3966Z'%20fill='white'/%3e%3c/svg%3e",en="data:image/svg+xml,%3csvg%20width='100'%20height='98'%20viewBox='0%200%20100%2098'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M45.039%2046.1508C44.8843%2039.0425%2043.3309%2032.0284%2040.4623%2025.4854C22.1554%2033.775%208.70752%2049.4158%204.11064%2067.8719C6.80083%2073.8489%2010.7021%2079.2409%2015.5827%2083.7277C20.224%2068.0776%2030.7303%2054.6749%2045.039%2046.1508ZM37.5993%2019.8743C34.5329%2014.6935%2030.6252%2010.0261%2026.0265%206.05174C7.67928%2015.7881%20-3.16776%2035.9452%200.824273%2057.3144C7.5583%2041.0675%2020.6635%2027.5969%2037.5993%2019.8743ZM75.4228%2052.1529C77.1567%2032.641%2069.9186%2013.5398%2055.7651%200.460161C52.8013%200.127794%2045.3616%20-0.615142%2035.8251%202.12199C47.493%2013.8464%2054.2172%2029.3785%2054.6764%2045.6659C61.1017%2049.0921%2068.1438%2051.294%2075.4228%2052.1529ZM50.2811%2054.0102C44.0101%2057.7023%2038.5222%2062.5196%2034.1114%2068.2042C50.644%2079.4069%2071.3098%2082.887%2090.0603%2077.5496C94.0935%2072.3094%2096.988%2066.3299%2098.5685%2059.9733C93.2369%2061.2906%2087.7596%2061.9734%2082.2576%2062.0066C71.2493%2061.987%2060.3015%2059.2499%2050.2811%2054.0102ZM30.4621%2073.5025C27.3975%2078.5858%2025.2805%2084.1383%2023.9901%2089.9645C32.9338%2095.2875%2043.3826%2097.7357%2053.8459%2096.9598C64.3093%2096.1839%2074.2527%2092.2236%2082.2576%2085.6437C59.495%2088.7914%2041.2688%2080.7951%2030.4621%2073.5025ZM66.8137%203.00179C77.9632%2016.7657%2083.4472%2034.5179%2081.8544%2052.583C87.9966%2052.5956%2094.1016%2051.6584%2099.9395%2049.8068C99.9395%2049.4158%20100%2049.0247%20100%2048.6337C100%2027.5578%2086.1489%209.70776%2066.8137%203.00179Z'%20fill='white'/%3e%3c/svg%3e",tn="data:image/svg+xml,%3csvg%20width='100'%20height='98'%20viewBox='0%200%20100%2098'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M97.8754%2075.6416L75.0056%2053.4615C70.4941%2049.0861%2063.7562%2048.2337%2058.3268%2050.8286L37.5077%2030.6374V18.8749L12.5091%200.691406L0.00976493%2012.8137L18.7587%2037.0584H30.887L51.7061%2057.2497C49.05%2062.5153%2049.9093%2069.05%2054.4208%2073.4254L77.2906%2095.6055C80.142%2098.3709%2084.7511%2098.3709%2087.583%2095.6055L97.8754%2085.6235C100.707%2082.8581%20100.707%2078.388%2097.8754%2075.6416ZM64.7913%2043.309C70.3184%2043.309%2075.5134%2045.3925%2079.4194%2049.1808L83.2083%2052.8553C86.294%2051.5484%2089.2235%2049.7301%2091.7625%2047.2677C99.0082%2040.2405%20101.469%2030.3533%2099.1644%2021.3751C98.7347%2019.6704%2096.5278%2019.0833%2095.2388%2020.3334L80.7084%2034.4256L67.4474%2032.2853L65.2405%2019.4242L79.7709%205.33199C81.0599%204.08187%2080.435%201.94152%2078.6577%201.50588C69.4004%20-0.710239%2059.2057%201.67635%2051.9795%208.68457C46.4134%2014.0828%2043.7964%2021.2047%2043.9331%2028.3076L59.9674%2043.8583C61.5493%2043.4984%2063.1898%2043.309%2064.7913%2043.309ZM44.4995%2058.8408L33.4259%2048.1011L3.66191%2076.9864C-1.22064%2081.7217%20-1.22064%2089.3928%203.66191%2094.1281C8.54445%2098.8634%2016.4542%2098.8634%2021.3367%2094.1281L45.476%2070.7169C43.9917%2066.9476%2043.5425%2062.8373%2044.4995%2058.8408ZM12.5091%2090.0937C9.93109%2090.0937%207.82183%2088.048%207.82183%2085.5478C7.82183%2083.0286%209.91156%2081.0019%2012.5091%2081.0019C15.1066%2081.0019%2017.1963%2083.0286%2017.1963%2085.5478C17.1963%2088.048%2015.1066%2090.0937%2012.5091%2090.0937Z'%20fill='white'/%3e%3c/svg%3e",rn="data:image/svg+xml,%3csvg%20width='133'%20height='98'%20viewBox='0%200%20133%2098'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M45.1727%2095.7747L1.94766%2053.5048C-0.64922%2050.9653%20-0.64922%2046.8478%201.94766%2044.3081L11.352%2035.1113C13.9488%2032.5716%2018.1596%2032.5716%2020.7565%2035.1113L49.875%2063.5861L112.243%202.59603C114.84%200.0565321%20119.051%200.0565321%20121.648%202.59603L131.052%2011.7928C133.649%2014.3323%20133.649%2018.4498%20131.052%2020.9895L54.5773%2095.775C51.9801%2098.3145%2047.7696%2098.3145%2045.1727%2095.7747Z'%20fill='white'/%3e%3c/svg%3e",nn=()=>e.jsx(Xi,{className:"row",children:e.jsxs("div",{className:"col-md-12 fatures",children:[e.jsxs("div",{className:"container mb-5",children:[e.jsx("h1",{className:"text-center fw-bold title",children:"Our Features"}),e.jsx("p",{className:"text-center mt-3 mb-5",children:"When a consultant takes a new project, they typically start by doing an in-depth analysis of their client's business goals and objectives."}),e.jsxs("div",{className:"row",children:[e.jsxs("div",{className:"col-6 col-md-3 box1",children:[e.jsx("img",{src:Ji,alt:"",className:"img-fluid"}),e.jsx("p",{children:"We Help Set Priorities Correctly"})]}),e.jsxs("div",{className:"col-6 col-md-3 box2",children:[e.jsx("img",{src:en,alt:"",className:"img-fluid"}),e.jsx("p",{children:"We Help Set Priorities Correctly"})]}),e.jsx("div",{className:"col-md-6 p-0",children:e.jsx("img",{src:$i,alt:"",className:"decImg img-fluid"})})]}),e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6 p-0",children:e.jsx("img",{src:Yi,alt:"",className:"decImg img-fluid"})}),e.jsxs("div",{className:"col-6 col-md-3 box1",children:[e.jsx("img",{src:tn,alt:"",className:"img-fluid"}),e.jsx("p",{children:"We Help Set Priorities Correctly"})]}),e.jsxs("div",{className:"col-6 col-md-3 box2",children:[e.jsx("img",{src:rn,alt:"",className:"img-fluid"}),e.jsx("p",{children:"We Help Set Priorities Correctly"})]})]})]}),e.jsx(He,{AncherLabel:"Know More About",Ancherpath:"/about",AncherClass:"btn btn-outline d-flex justify-content-center align-items-center gap-3",AnchersvgColor:"#ffffff"})]})}),an="/static/assets/background-styling-image-B-2oeKht.png",ln=xe.div`
  // background-color: ${({theme:n})=>n.white};
  background-image: url(${an});
  background-position: center;
  padding: 64px 0;


.clients-image-slider{
    display: flex;
    // place-it 
    position: relative;
    overflow: hidden;

    height: 100%;  
    width: 100%;
    justify-content: flex-end;

      &::before,
      &::after {
        background: linear-gradient(to right, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%);
        content: '';
        height: 100%;
        width: 15%;
        z-index: 2;
        position: absolute;
      }
    
      &::before {
        left: 0;
        top: 0;
      }
    
      &::after {
        right: 0;
        top: 0;
        background: linear-gradient(to left, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%);
      }


    .image-slider-track{
      display: flex;
      animation: play 40s linear infinite;
  
      &::hover{
        -webkit-animation-play-state: paused;
        -moz-animation-play-state: paused;
        -o-animation-play-state: paused;
        animation-play-state: paused;
      }
      
      .slide{
        // height: 150px;
        width: 200px;
        display: flex;
        place-items: center;
        padding: 15px;
        perspective: 100px;
        margin-right: 70px;

        &:hover .clientPopOver {
          bottom: 0;
          left: 0;
          right: 0;
          // height: 100%;
        }

        .clientPopOver {
          // top: 0px;
          // z-index: 999;
          // opacity: .8;
          // transition: .5s ease;

          position: absolute;
          bottom: 100%;
          left: 0;
          right: 0;
          background-color: #008CBA;
          overflow: hidden;
          width: 100%;
          // height:0;
          transition: .5s ease;
          opacity: .85;
          
          p {
            margin: 0px 0 5px;
            padding: 0;
            transition: .5s ease;
            justify-content: center;
          align-items: center;
          }
        }

        img{
          height: 100%;
          width:100%;
        }
    }
  }
}

@keyframes play{
    0%{
        transform: translateX(100%);
    }

    100%{
        transform: translateX(-120%);
    }
}

.slider-container {
  .slick-slider {
    overflow: hidden !important;
  }

  .slick-track {
    overflow: hidden !important;
  }
}

.slick-initialized .slick-slide {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 200px !important;
  min-height: 120px;
  padding: 16px;
  border: 1px solid #ededed;
  background: white;
  margin: 0 12px;
  cursor: pointer;
  
  div { 
    img {
      margin: 0 auto;
      width: 100%;
      height: 100% !important;
    }
  }
}

.ql-editor {
  padding: 10px !imporrant;
  text-align: center;
  max-width: 240px;

  p {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  }
}

    
 
  

`,on="/static/assets/carousel1-BjDUQ-HC.jpg",sn="/static/assets/carousel2-oBE5xWYj.jpg",cn="/static/assets/carousel3-BiZNlBHH.jpg",un=xe.div`
    // padding: 50px 0;

    .hiligntsContainer {
        bottom: -75px;
        box-shadow: 0px 4px 16px rgba(0, 0, 0, .25);     
    }
    .col-sm-4 {
        &:nth-child(1) {
            background: ${({theme:n})=>n.white};
        }

        &:nth-child(2) {
            background: ${({theme:n})=>n.verylightgray};
        }

        &:nth-child(3) {
            background: ${({theme:n})=>n.white};
        }

        p {
            font-size: .9rem;
            margin: 0px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp:2;
        }
    }
l`,dn=xe.div`

.testimonials {
    background-color:${({theme:n})=>n.testimonialsBg}; 
    color:${({theme:n})=>n.testimonialsTextColor};
    min-height: 480px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    // border: 1px solid ${({theme:n})=>n.gray888};
    // background: rgb(255,255,255);
    // background: linear-gradient(360deg, ${({theme:n})=>n.white} 0%, ${({theme:n})=>n.primaryColor} 100%);
    // border-radius: 30px;
    // padding: 70px 75px !important;

    .testimonialImg {
        width: 125px;
        height: 125px;
        object-fit: cover;
        box-shadow: 0 5px 5px rgba(0,0,0, .5) !important
      }

      i.fa {
        color:${({theme:n})=>n.testimonialsLinkColor};

        &:hover {
            color:${({theme:n})=>n.testimonialsLinkHoverColor};
        }
      }

    .title {color:${({theme:n})=>n.black};}
    p {color:${({theme:n})=>n.textColor};}

    .article {
        /* top: 0;
          left: 0; */
        /* width: 100%;
          height: 100%; */
        opacity: 0;
        transition: all 0.3s linear;
      }
      
      .article.activeSlide {
        opacity: 1;
        transform: translateX(0);
      }
      
      .fa-user {
        font-size: 100px;
      }
      .article.lastSlide {
        // transform: translateX(-100%); 
      }
      
      .article.nextSlide {
        //  transform: translateX(100%); 
      }
}
`,fn=xe.div`
    .randomServices img {
        border-top-right-radius: 10px;
        border-bottom-right-radius: 10px;
        height: 320px;
        object-fit: cover;
        filter: grayscale(100%);
        transition: filter 0.3s ease-in-out, transform 0.3s ease-in-out;

        &:hover {
            filter: grayscale(0%);
            transform: scaleX(1.05);
        }
    }
    .randomServices .row:nth-child(2) img {
        border-top-left-radius: 10px;
        border-bottom-left-radius: 10px;
        border-top-right-radius: 0px;
        border-bottom-right-radius: 0px
    }

    @media (max-width: 576px) {
        .randomServices .row img {
            border-radius: 0px !important;
            height: 200px;
        }
    }
l`,Ge=({componentEdit:n,formgetURL:o,formvalues:d,setFormValues:p})=>(A.useEffect(()=>{n||(async()=>{try{let b=await ye.get(o);p(b.data.intro)}catch{console.log("Unable to get the intro")}})()},[n]),e.jsxs(e.Fragment,{children:[e.jsx(he,{title:d==null?void 0:d.intro_title,cssClass:"fs-4 fw-bold text-left"}),e.jsx("p",{className:"mt-2 mb-3",children:d==null?void 0:d.intro_desc}),e.jsx(pe,{to:d==null?void 0:d.intro_morelink,className:"moreLink",children:"more.."})]}));function Qe({editHandler:n,componentType:o,componentTitle:d="Form ",editObject:p,setEditState:f,setSaveState:b,dynamicFormFields:g=[],formPostURL:C,formUpdateURL:w}){const j=()=>{n(o,!1),document.body.style.overflow=""},[O,z]=A.useState(!1),[Y,Z]=A.useState(""),{register:X,reset:_,handleSubmit:B,formState:{errors:D}}=Gr({defaultValues:A.useMemo(()=>p,[p])}),[V,J]=A.useState(""),G=async s=>{JSON.stringify(s);let v=new FormData;Object.keys(s).forEach(k=>{v.append(k,s[k])});let y="";try{s!=null&&s.id?y=await Cr.put(`${w}${s.pageType}/`,v):y=await Cr.post(C,v),j()}catch(k){Le.error(k[0])}};return e.jsxs(e.Fragment,{children:[e.jsx(pi,{closeHandler:j,title:d}),e.jsx("hr",{}),e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 px-5",children:[O&&e.jsx("div",{className:"fw-bold",children:O&&e.jsx(mi,{children:O})}),e.jsxs("form",{onSubmit:B(G),children:[Object.keys(g).map((s,v)=>{var S;const{label:y,type:k,fieldName:c,value:a}=g[s];return k=="richText"?e.jsx(bi,{label:y,editorSetState:J,initialText:""},v):e.jsx(de,{label:y,type:k,value:a,error:(S=D==null?void 0:D[c])==null?void 0:S.message,fieldName:c,register:X,...g[s]},v)}),e.jsxs("div",{className:"d-flex justify-content-center flex-wrap flex-column flex-sm-row align-items-center gap-1 gap-md-3 mt-5",children:[e.jsx("button",{className:"btn btn-secondary mx-3",children:"save"}),e.jsx(Qr,{type:"submit",cssClass:"btn btn-outline",label:"Close",handlerChange:j})]})]})]})})})]})}const vn=({client:n})=>{const[o,d]=A.useState(!1),p=Xr(),f=g=>{d(!0)},b=g=>{d(!1)};return e.jsx("div",{onMouseEnter:f,onMouseLeave:b,children:e.jsx("img",{src:`${p}${n.path}`,alt:n.client_title,style:{height:"100px"}},n.id)})},hn=()=>{const[n,o]=A.useState([]),d=async()=>{const p=await ye.get("/project/clientCategory/");(p==null?void 0:p.status)===200&&o(p.data)};return A.useEffect(()=>{d()},[]),e.jsxs("div",{children:[e.jsx(he,{title:"PROJECTS",cssClass:"text-center fs-1"}),e.jsx("div",{className:"row my-3 homeProjectsBg",children:e.jsx("div",{className:"col-md-12 d-flex justify-content-center align-items-center",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:n==null?void 0:n.map((p,f)=>e.jsx("div",{className:"col-md-4",children:e.jsxs("div",{className:"card border-0",children:[e.jsxs("div",{className:"card-body",children:[e.jsx(he,{title:p.category_Label,cssClass:""}),e.jsx("hr",{className:"mb-0 title-border ongoing"})]}),e.jsxs("div",{className:"card-body pt-0",children:[e.jsx("img",{src:p!=null&&p.path?Re(p.path):gi(),alt:p==null?void 0:p.alternitivetext,className:"w-100",style:{width:"100px",height:"100px",objectFit:"cover"}}),e.jsx("p",{className:"card-text my-4",children:p.category_description}),e.jsxs(pe,{to:`${p.readMore_link}`,children:["Continue"," "]})]})]})},f))})})})})]})},pn=({item:n,index:o})=>{const d=yi();return e.jsx("div",{className:`carousel-item ${o===0?"active":""}`,children:e.jsx("div",{className:"container",children:e.jsxs("div",{className:"row align-items-start",children:[e.jsx("div",{className:"col-sm-6 col-md-6 p-0 carouselImg",children:e.jsx("img",{src:Re(n.path),alt:n.altText,className:"d-block w-100"})}),e.jsx("div",{className:"col-sm-6 col-md-6 carouselDescription d-flex align-items-center",children:e.jsxs("div",{className:"d-flex flex-column justify-content-start align-items-start gap-2",children:[e.jsx("span",{children:"PROJECTS"}),n.projectTitle&&e.jsx("h1",{className:"",children:n.projectTitle}),n.projectDescription||n.imageDescription&&e.jsx("p",{className:"fw-normal description fs-5",children:n.imageDescription?n.imageDescription:n.projectDescription}),e.jsx("div",{children:e.jsx("button",{className:"btn btn-primary btn-sm",onClick:()=>d("/project-details",{state:{selectedPorject:n.projectType,projectid:n.id}}),children:"more details"})})]})})]})})},n.index)},mn=({carouselState:n})=>{const{clientProjects:o}=Se(g=>g.clientProjects),d=ti(),{isLoading:p}=Se(g=>g.loader),[f,b]=A.useState([]);return A.useEffect(()=>{o.length===0&&d(xi())},[d,o]),A.useEffect(()=>{var g;if(((g=o==null?void 0:o.projectList)==null?void 0:g.length)>0){const C=Si(o),w=ji(o),j=[];w.forEach(O=>{var z,Y,Z,X;j.push({id:O.id,projectTitle:O.projectTitle,projectDescription:O.description,altText:(z=O==null?void 0:O.imgs[0])==null?void 0:z.alternitivetext,path:(Y=O==null?void 0:O.imgs[0])==null?void 0:Y.path,imageDescription:(Z=O==null?void 0:O.imgs[0])==null?void 0:Z.imageDescription,imageTitle:(X=O==null?void 0:O.imgs[0])==null?void 0:X.imageTitle,projectType:C[O.projectCategoryValue]})}),b(j)}},[o]),e.jsxs("div",{id:"carouselExampleDark",className:"homeMultyPurposeCarousel carousel slide","data-bs-ride":"carousel",children:[e.jsx("div",{className:"carousel-indicators",children:f.length>0&&(f==null?void 0:f.map((g,C)=>e.jsx("button",{type:"button","data-bs-target":"#carouselExampleDark","data-bs-slide-to":C,className:`${C===0?"active":""}`,"aria-current":"true","aria-label":`Slide ${C} `},C)))}),e.jsxs("div",{className:"carousel-inner",children:[p?e.jsx(ri,{}):"",f.length>0?f==null?void 0:f.map((g,C)=>e.jsx(pn,{item:g,index:C},C)):e.jsx("div",{className:"d-flex justify-content-center align-items-center fs-5 text-muted text-center noImg",children:!p&&e.jsx("p",{children:"Please add images for Carousel..."})})]}),f.length>1&&e.jsxs(e.Fragment,{children:[e.jsxs("button",{className:"carousel-control-prev",type:"button","data-bs-target":"#carouselExampleDark","data-bs-slide":"prev",children:[e.jsx("span",{className:"carousel-control-prev-icon","aria-hidden":"true"}),e.jsx("span",{className:"visually-hidden",children:"Previous"})]}),e.jsxs("button",{className:"carousel-control-next",type:"button","data-bs-target":"#carouselExampleDark","data-bs-slide":"next",children:[e.jsx("span",{className:"carousel-control-next-icon","aria-hidden":"true"}),e.jsx("span",{className:"visually-hidden",children:"Next"})]})]})]})};var Xe={},Ye={},Me={},$e={},Pr;function bn(){return Pr||(Pr=1,function(n){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o={animating:!1,autoplaying:null,currentDirection:0,currentLeft:null,currentSlide:0,direction:1,dragging:!1,edgeDragged:!1,initialized:!1,lazyLoadedList:[],listHeight:null,listWidth:null,scrolling:!1,slideCount:null,slideHeight:null,slideWidth:null,swipeLeft:null,swiped:!1,swiping:!1,touchObject:{startX:0,startY:0,curX:0,curY:0},trackStyle:{},trackWidth:0,targetSlide:0};n.default=o}($e)),$e}var Je,Mr;function gn(){if(Mr)return Je;Mr=1;var n="Expected a function",o=NaN,d="[object Symbol]",p=/^\s+|\s+$/g,f=/^[-+]0x[0-9a-f]+$/i,b=/^0b[01]+$/i,g=/^0o[0-7]+$/i,C=parseInt,w=typeof globalThis=="object"&&globalThis&&globalThis.Object===Object&&globalThis,j=typeof self=="object"&&self&&self.Object===Object&&self,O=w||j||Function("return this")(),z=Object.prototype,Y=z.toString,Z=Math.max,X=Math.min,_=function(){return O.Date.now()};function B(s,v,y){var k,c,a,S,i,h,x=0,E=!1,P=!1,t=!0;if(typeof s!="function")throw new TypeError(n);v=G(v)||0,D(y)&&(E=!!y.leading,P="maxWait"in y,a=P?Z(G(y.maxWait)||0,v):a,t="trailing"in y?!!y.trailing:t);function q(I){var U=k,W=c;return k=c=void 0,x=I,S=s.apply(W,U),S}function u(I){return x=I,i=setTimeout(m,v),E?q(I):S}function r(I){var U=I-h,W=I-x,K=v-U;return P?X(K,a-W):K}function l(I){var U=I-h,W=I-x;return h===void 0||U>=v||U<0||P&&W>=a}function m(){var I=_();if(l(I))return T(I);i=setTimeout(m,r(I))}function T(I){return i=void 0,t&&k?q(I):(k=c=void 0,S)}function N(){i!==void 0&&clearTimeout(i),x=0,k=h=c=i=void 0}function L(){return i===void 0?S:T(_())}function M(){var I=_(),U=l(I);if(k=arguments,c=this,h=I,U){if(i===void 0)return u(h);if(P)return i=setTimeout(m,v),q(h)}return i===void 0&&(i=setTimeout(m,v)),S}return M.cancel=N,M.flush=L,M}function D(s){var v=typeof s;return!!s&&(v=="object"||v=="function")}function V(s){return!!s&&typeof s=="object"}function J(s){return typeof s=="symbol"||V(s)&&Y.call(s)==d}function G(s){if(typeof s=="number")return s;if(J(s))return o;if(D(s)){var v=typeof s.valueOf=="function"?s.valueOf():s;s=D(v)?v+"":v}if(typeof s!="string")return s===0?s:+s;s=s.replace(p,"");var y=b.test(s);return y||g.test(s)?C(s.slice(2),y?2:8):f.test(s)?o:+s}return Je=B,Je}var et={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/var _r;function We(){return _r||(_r=1,function(n){(function(){var o={}.hasOwnProperty;function d(){for(var b="",g=0;g<arguments.length;g++){var C=arguments[g];C&&(b=f(b,p(C)))}return b}function p(b){if(typeof b=="string"||typeof b=="number")return b;if(typeof b!="object")return"";if(Array.isArray(b))return d.apply(null,b);if(b.toString!==Object.prototype.toString&&!b.toString.toString().includes("[native code]"))return b.toString();var g="";for(var C in b)o.call(b,C)&&b[C]&&(g=f(g,C));return g}function f(b,g){return g?b?b+" "+g:b+g:b}n.exports?(d.default=d,n.exports=d):window.classNames=d})()}(et)),et.exports}var R={},tt={},Er;function ii(){return Er||(Er=1,function(n){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=d(Ne());function d(f){return f&&f.__esModule?f:{default:f}}var p={accessibility:!0,adaptiveHeight:!1,afterChange:null,appendDots:function(b){return o.default.createElement("ul",{style:{display:"block"}},b)},arrows:!0,autoplay:!1,autoplaySpeed:3e3,beforeChange:null,centerMode:!1,centerPadding:"50px",className:"",cssEase:"ease",customPaging:function(b){return o.default.createElement("button",null,b+1)},dots:!1,dotsClass:"slick-dots",draggable:!0,easing:"linear",edgeFriction:.35,fade:!1,focusOnSelect:!1,infinite:!0,initialSlide:0,lazyLoad:null,nextArrow:null,onEdge:null,onInit:null,onLazyLoadError:null,onReInit:null,pauseOnDotsHover:!1,pauseOnFocus:!1,pauseOnHover:!0,prevArrow:null,responsive:null,rows:1,rtl:!1,slide:"div",slidesPerRow:1,slidesToScroll:1,slidesToShow:1,speed:500,swipe:!0,swipeEvent:null,swipeToSlide:!1,touchMove:!0,touchThreshold:5,useCSS:!0,useTransform:!0,variableWidth:!1,vertical:!1,waitForAnimate:!0,asNavFor:null,unslick:!1};n.default=p}(tt)),tt}var Lr;function De(){if(Lr)return R;Lr=1,Object.defineProperty(R,"__esModule",{value:!0}),R.checkSpecKeys=R.checkNavigable=R.changeSlide=R.canUseDOM=R.canGoNext=void 0,R.clamp=j,R.extractObject=void 0,R.filterSettings=q,R.validSettings=R.swipeStart=R.swipeMove=R.swipeEnd=R.slidesOnRight=R.slidesOnLeft=R.slideHandler=R.siblingDirection=R.safePreventDefault=R.lazyStartIndex=R.lazySlidesOnRight=R.lazySlidesOnLeft=R.lazyEndIndex=R.keyHandler=R.initializedState=R.getWidth=R.getTrackLeft=R.getTrackCSS=R.getTrackAnimateCSS=R.getTotalSlides=R.getSwipeDirection=R.getSlideCount=R.getRequiredLazySlides=R.getPreClones=R.getPostClones=R.getOnDemandLazySlides=R.getNavigableIndexes=R.getHeight=void 0;var n=d(Ne()),o=d(ii());function d(u){return u&&u.__esModule?u:{default:u}}function p(u){"@babel/helpers - typeof";return p=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(r){return typeof r}:function(r){return r&&typeof Symbol=="function"&&r.constructor===Symbol&&r!==Symbol.prototype?"symbol":typeof r},p(u)}function f(u,r){var l=Object.keys(u);if(Object.getOwnPropertySymbols){var m=Object.getOwnPropertySymbols(u);r&&(m=m.filter(function(T){return Object.getOwnPropertyDescriptor(u,T).enumerable})),l.push.apply(l,m)}return l}function b(u){for(var r=1;r<arguments.length;r++){var l=arguments[r]!=null?arguments[r]:{};r%2?f(Object(l),!0).forEach(function(m){g(u,m,l[m])}):Object.getOwnPropertyDescriptors?Object.defineProperties(u,Object.getOwnPropertyDescriptors(l)):f(Object(l)).forEach(function(m){Object.defineProperty(u,m,Object.getOwnPropertyDescriptor(l,m))})}return u}function g(u,r,l){return r=C(r),r in u?Object.defineProperty(u,r,{value:l,enumerable:!0,configurable:!0,writable:!0}):u[r]=l,u}function C(u){var r=w(u,"string");return p(r)=="symbol"?r:String(r)}function w(u,r){if(p(u)!="object"||!u)return u;var l=u[Symbol.toPrimitive];if(l!==void 0){var m=l.call(u,r);if(p(m)!="object")return m;throw new TypeError("@@toPrimitive must return a primitive value.")}return(r==="string"?String:Number)(u)}function j(u,r,l){return Math.max(r,Math.min(u,l))}var O=R.safePreventDefault=function(r){var l=["onTouchStart","onTouchMove","onWheel"];l.includes(r._reactName)||r.preventDefault()},z=R.getOnDemandLazySlides=function(r){for(var l=[],m=Y(r),T=Z(r),N=m;N<T;N++)r.lazyLoadedList.indexOf(N)<0&&l.push(N);return l};R.getRequiredLazySlides=function(r){for(var l=[],m=Y(r),T=Z(r),N=m;N<T;N++)l.push(N);return l};var Y=R.lazyStartIndex=function(r){return r.currentSlide-X(r)},Z=R.lazyEndIndex=function(r){return r.currentSlide+_(r)},X=R.lazySlidesOnLeft=function(r){return r.centerMode?Math.floor(r.slidesToShow/2)+(parseInt(r.centerPadding)>0?1:0):0},_=R.lazySlidesOnRight=function(r){return r.centerMode?Math.floor((r.slidesToShow-1)/2)+1+(parseInt(r.centerPadding)>0?1:0):r.slidesToShow},B=R.getWidth=function(r){return r&&r.offsetWidth||0},D=R.getHeight=function(r){return r&&r.offsetHeight||0},V=R.getSwipeDirection=function(r){var l=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1,m,T,N,L;return m=r.startX-r.curX,T=r.startY-r.curY,N=Math.atan2(T,m),L=Math.round(N*180/Math.PI),L<0&&(L=360-Math.abs(L)),L<=45&&L>=0||L<=360&&L>=315?"left":L>=135&&L<=225?"right":l===!0?L>=35&&L<=135?"up":"down":"vertical"},J=R.canGoNext=function(r){var l=!0;return r.infinite||(r.centerMode&&r.currentSlide>=r.slideCount-1||r.slideCount<=r.slidesToShow||r.currentSlide>=r.slideCount-r.slidesToShow)&&(l=!1),l};R.extractObject=function(r,l){var m={};return l.forEach(function(T){return m[T]=r[T]}),m},R.initializedState=function(r){var l=n.default.Children.count(r.children),m=r.listRef,T=Math.ceil(B(m)),N=r.trackRef&&r.trackRef.node,L=Math.ceil(B(N)),M;if(r.vertical)M=T;else{var I=r.centerMode&&parseInt(r.centerPadding)*2;typeof r.centerPadding=="string"&&r.centerPadding.slice(-1)==="%"&&(I*=T/100),M=Math.ceil((T-I)/r.slidesToShow)}var U=m&&D(m.querySelector('[data-index="0"]')),W=U*r.slidesToShow,K=r.currentSlide===void 0?r.initialSlide:r.currentSlide;r.rtl&&r.currentSlide===void 0&&(K=l-1-r.initialSlide);var re=r.lazyLoadedList||[],ee=z(b(b({},r),{},{currentSlide:K,lazyLoadedList:re}));re=re.concat(ee);var Q={slideCount:l,slideWidth:M,listWidth:T,trackWidth:L,currentSlide:K,slideHeight:U,listHeight:W,lazyLoadedList:re};return r.autoplaying===null&&r.autoplay&&(Q.autoplaying="playing"),Q},R.slideHandler=function(r){var l=r.waitForAnimate,m=r.animating,T=r.fade,N=r.infinite,L=r.index,M=r.slideCount,I=r.lazyLoad,U=r.currentSlide,W=r.centerMode,K=r.slidesToScroll,re=r.slidesToShow,ee=r.useCSS,Q=r.lazyLoadedList;if(l&&m)return{};var F=L,$,le,H,ne={},oe={},se=N?L:j(L,0,M-1);if(T){if(!N&&(L<0||L>=M))return{};L<0?F=L+M:L>=M&&(F=L-M),I&&Q.indexOf(F)<0&&(Q=Q.concat(F)),ne={animating:!0,currentSlide:F,lazyLoadedList:Q,targetSlide:F},oe={animating:!1,targetSlide:F}}else $=F,F<0?($=F+M,N?M%K!==0&&($=M-M%K):$=0):!J(r)&&F>U?F=$=U:W&&F>=M?(F=N?M:M-1,$=N?0:M-1):F>=M&&($=F-M,N?M%K!==0&&($=0):$=M-re),!N&&F+re>=M&&($=M-re),le=a(b(b({},r),{},{slideIndex:F})),H=a(b(b({},r),{},{slideIndex:$})),N||(le===H&&(F=$),le=H),I&&(Q=Q.concat(z(b(b({},r),{},{currentSlide:F})))),ee?(ne={animating:!0,currentSlide:$,trackStyle:c(b(b({},r),{},{left:le})),lazyLoadedList:Q,targetSlide:se},oe={animating:!1,currentSlide:$,trackStyle:k(b(b({},r),{},{left:H})),swipeLeft:null,targetSlide:se}):ne={currentSlide:$,trackStyle:k(b(b({},r),{},{left:H})),lazyLoadedList:Q,targetSlide:se};return{state:ne,nextState:oe}},R.changeSlide=function(r,l){var m,T,N,L,M,I=r.slidesToScroll,U=r.slidesToShow,W=r.slideCount,K=r.currentSlide,re=r.targetSlide,ee=r.lazyLoad,Q=r.infinite;if(L=W%I!==0,m=L?0:(W-K)%I,l.message==="previous")N=m===0?I:U-m,M=K-N,ee&&!Q&&(T=K-N,M=T===-1?W-1:T),Q||(M=re-I);else if(l.message==="next")N=m===0?I:m,M=K+N,ee&&!Q&&(M=(K+I)%W+m),Q||(M=re+I);else if(l.message==="dots")M=l.index*l.slidesToScroll;else if(l.message==="children"){if(M=l.index,Q){var F=x(b(b({},r),{},{targetSlide:M}));M>l.currentSlide&&F==="left"?M=M-W:M<l.currentSlide&&F==="right"&&(M=M+W)}}else l.message==="index"&&(M=Number(l.index));return M},R.keyHandler=function(r,l,m){return r.target.tagName.match("TEXTAREA|INPUT|SELECT")||!l?"":r.keyCode===37?m?"next":"previous":r.keyCode===39?m?"previous":"next":""},R.swipeStart=function(r,l,m){return r.target.tagName==="IMG"&&O(r),!l||!m&&r.type.indexOf("mouse")!==-1?"":{dragging:!0,touchObject:{startX:r.touches?r.touches[0].pageX:r.clientX,startY:r.touches?r.touches[0].pageY:r.clientY,curX:r.touches?r.touches[0].pageX:r.clientX,curY:r.touches?r.touches[0].pageY:r.clientY}}},R.swipeMove=function(r,l){var m=l.scrolling,T=l.animating,N=l.vertical,L=l.swipeToSlide,M=l.verticalSwiping,I=l.rtl,U=l.currentSlide,W=l.edgeFriction,K=l.edgeDragged,re=l.onEdge,ee=l.swiped,Q=l.swiping,F=l.slideCount,$=l.slidesToScroll,le=l.infinite,H=l.touchObject,ne=l.swipeEvent,oe=l.listHeight,se=l.listWidth;if(!m){if(T)return O(r);N&&L&&M&&O(r);var ce,be={},Ce=a(l);H.curX=r.touches?r.touches[0].pageX:r.clientX,H.curY=r.touches?r.touches[0].pageY:r.clientY,H.swipeLength=Math.round(Math.sqrt(Math.pow(H.curX-H.startX,2)));var Te=Math.round(Math.sqrt(Math.pow(H.curY-H.startY,2)));if(!M&&!Q&&Te>10)return{scrolling:!0};M&&(H.swipeLength=Te);var je=(I?-1:1)*(H.curX>H.startX?1:-1);M&&(je=H.curY>H.startY?1:-1);var Ae=Math.ceil(F/$),me=V(l.touchObject,M),we=H.swipeLength;return le||(U===0&&(me==="right"||me==="down")||U+1>=Ae&&(me==="left"||me==="up")||!J(l)&&(me==="left"||me==="up"))&&(we=H.swipeLength*W,K===!1&&re&&(re(me),be.edgeDragged=!0)),!ee&&ne&&(ne(me),be.swiped=!0),N?ce=Ce+we*(oe/se)*je:I?ce=Ce-we*je:ce=Ce+we*je,M&&(ce=Ce+we*je),be=b(b({},be),{},{touchObject:H,swipeLeft:ce,trackStyle:k(b(b({},l),{},{left:ce}))}),Math.abs(H.curX-H.startX)<Math.abs(H.curY-H.startY)*.8||H.swipeLength>10&&(be.swiping=!0,O(r)),be}},R.swipeEnd=function(r,l){var m=l.dragging,T=l.swipe,N=l.touchObject,L=l.listWidth,M=l.touchThreshold,I=l.verticalSwiping,U=l.listHeight,W=l.swipeToSlide,K=l.scrolling,re=l.onSwipe,ee=l.targetSlide,Q=l.currentSlide,F=l.infinite;if(!m)return T&&O(r),{};var $=I?U/M:L/M,le=V(N,I),H={dragging:!1,edgeDragged:!1,scrolling:!1,swiping:!1,swiped:!1,swipeLeft:null,touchObject:{}};if(K||!N.swipeLength)return H;if(N.swipeLength>$){O(r),re&&re(le);var ne,oe,se=F?Q:ee;switch(le){case"left":case"up":oe=se+v(l),ne=W?s(l,oe):oe,H.currentDirection=0;break;case"right":case"down":oe=se-v(l),ne=W?s(l,oe):oe,H.currentDirection=1;break;default:ne=se}H.triggerSlideHandler=ne}else{var ce=a(l);H.trackStyle=c(b(b({},l),{},{left:ce}))}return H};var G=R.getNavigableIndexes=function(r){for(var l=r.infinite?r.slideCount*2:r.slideCount,m=r.infinite?r.slidesToShow*-1:0,T=r.infinite?r.slidesToShow*-1:0,N=[];m<l;)N.push(m),m=T+r.slidesToScroll,T+=Math.min(r.slidesToScroll,r.slidesToShow);return N},s=R.checkNavigable=function(r,l){var m=G(r),T=0;if(l>m[m.length-1])l=m[m.length-1];else for(var N in m){if(l<m[N]){l=T;break}T=m[N]}return l},v=R.getSlideCount=function(r){var l=r.centerMode?r.slideWidth*Math.floor(r.slidesToShow/2):0;if(r.swipeToSlide){var m,T=r.listRef,N=T.querySelectorAll&&T.querySelectorAll(".slick-slide")||[];if(Array.from(N).every(function(I){if(r.vertical){if(I.offsetTop+D(I)/2>r.swipeLeft*-1)return m=I,!1}else if(I.offsetLeft-l+B(I)/2>r.swipeLeft*-1)return m=I,!1;return!0}),!m)return 0;var L=r.rtl===!0?r.slideCount-r.currentSlide:r.currentSlide,M=Math.abs(m.dataset.index-L)||1;return M}else return r.slidesToScroll},y=R.checkSpecKeys=function(r,l){return l.reduce(function(m,T){return m&&r.hasOwnProperty(T)},!0)?null:console.error("Keys Missing:",r)},k=R.getTrackCSS=function(r){y(r,["left","variableWidth","slideCount","slidesToShow","slideWidth"]);var l,m,T=r.slideCount+2*r.slidesToShow;r.vertical?m=T*r.slideHeight:l=h(r)*r.slideWidth;var N={opacity:1,transition:"",WebkitTransition:""};if(r.useTransform){var L=r.vertical?"translate3d(0px, "+r.left+"px, 0px)":"translate3d("+r.left+"px, 0px, 0px)",M=r.vertical?"translate3d(0px, "+r.left+"px, 0px)":"translate3d("+r.left+"px, 0px, 0px)",I=r.vertical?"translateY("+r.left+"px)":"translateX("+r.left+"px)";N=b(b({},N),{},{WebkitTransform:L,transform:M,msTransform:I})}else r.vertical?N.top=r.left:N.left=r.left;return r.fade&&(N={opacity:1}),l&&(N.width=l),m&&(N.height=m),window&&!window.addEventListener&&window.attachEvent&&(r.vertical?N.marginTop=r.left+"px":N.marginLeft=r.left+"px"),N},c=R.getTrackAnimateCSS=function(r){y(r,["left","variableWidth","slideCount","slidesToShow","slideWidth","speed","cssEase"]);var l=k(r);return r.useTransform?(l.WebkitTransition="-webkit-transform "+r.speed+"ms "+r.cssEase,l.transition="transform "+r.speed+"ms "+r.cssEase):r.vertical?l.transition="top "+r.speed+"ms "+r.cssEase:l.transition="left "+r.speed+"ms "+r.cssEase,l},a=R.getTrackLeft=function(r){if(r.unslick)return 0;y(r,["slideIndex","trackRef","infinite","centerMode","slideCount","slidesToShow","slidesToScroll","slideWidth","listWidth","variableWidth","slideHeight"]);var l=r.slideIndex,m=r.trackRef,T=r.infinite,N=r.centerMode,L=r.slideCount,M=r.slidesToShow,I=r.slidesToScroll,U=r.slideWidth,W=r.listWidth,K=r.variableWidth,re=r.slideHeight,ee=r.fade,Q=r.vertical,F=0,$,le,H=0;if(ee||r.slideCount===1)return 0;var ne=0;if(T?(ne=-S(r),L%I!==0&&l+I>L&&(ne=-(l>L?M-(l-L):L%I)),N&&(ne+=parseInt(M/2))):(L%I!==0&&l+I>L&&(ne=M-L%I),N&&(ne=parseInt(M/2))),F=ne*U,H=ne*re,Q?$=l*re*-1+H:$=l*U*-1+F,K===!0){var oe,se=m&&m.node;if(oe=l+S(r),le=se&&se.childNodes[oe],$=le?le.offsetLeft*-1:0,N===!0){oe=T?l+S(r):l,le=se&&se.children[oe],$=0;for(var ce=0;ce<oe;ce++)$-=se&&se.children[ce]&&se.children[ce].offsetWidth;$-=parseInt(r.centerPadding),$+=le&&(W-le.offsetWidth)/2}}return $},S=R.getPreClones=function(r){return r.unslick||!r.infinite?0:r.variableWidth?r.slideCount:r.slidesToShow+(r.centerMode?1:0)},i=R.getPostClones=function(r){return r.unslick||!r.infinite?0:r.slideCount},h=R.getTotalSlides=function(r){return r.slideCount===1?1:S(r)+r.slideCount+i(r)},x=R.siblingDirection=function(r){return r.targetSlide>r.currentSlide?r.targetSlide>r.currentSlide+E(r)?"left":"right":r.targetSlide<r.currentSlide-P(r)?"right":"left"},E=R.slidesOnRight=function(r){var l=r.slidesToShow,m=r.centerMode,T=r.rtl,N=r.centerPadding;if(m){var L=(l-1)/2+1;return parseInt(N)>0&&(L+=1),T&&l%2===0&&(L+=1),L}return T?0:l-1},P=R.slidesOnLeft=function(r){var l=r.slidesToShow,m=r.centerMode,T=r.rtl,N=r.centerPadding;if(m){var L=(l-1)/2+1;return parseInt(N)>0&&(L+=1),!T&&l%2===0&&(L+=1),L}return T?l-1:0};R.canUseDOM=function(){return!!(typeof window<"u"&&window.document&&window.document.createElement)};var t=R.validSettings=Object.keys(o.default);function q(u){return t.reduce(function(r,l){return u.hasOwnProperty(l)&&(r[l]=u[l]),r},{})}return R}var _e={},Ir;function yn(){if(Ir)return _e;Ir=1,Object.defineProperty(_e,"__esModule",{value:!0}),_e.Track=void 0;var n=p(Ne()),o=p(We()),d=De();function p(c){return c&&c.__esModule?c:{default:c}}function f(c){"@babel/helpers - typeof";return f=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(a){return typeof a}:function(a){return a&&typeof Symbol=="function"&&a.constructor===Symbol&&a!==Symbol.prototype?"symbol":typeof a},f(c)}function b(){return b=Object.assign?Object.assign.bind():function(c){for(var a=1;a<arguments.length;a++){var S=arguments[a];for(var i in S)Object.prototype.hasOwnProperty.call(S,i)&&(c[i]=S[i])}return c},b.apply(this,arguments)}function g(c,a){if(!(c instanceof a))throw new TypeError("Cannot call a class as a function")}function C(c,a){for(var S=0;S<a.length;S++){var i=a[S];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(c,J(i.key),i)}}function w(c,a,S){return a&&C(c.prototype,a),Object.defineProperty(c,"prototype",{writable:!1}),c}function j(c,a){if(typeof a!="function"&&a!==null)throw new TypeError("Super expression must either be null or a function");c.prototype=Object.create(a&&a.prototype,{constructor:{value:c,writable:!0,configurable:!0}}),Object.defineProperty(c,"prototype",{writable:!1}),a&&O(c,a)}function O(c,a){return O=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(i,h){return i.__proto__=h,i},O(c,a)}function z(c){var a=X();return function(){var i=_(c),h;if(a){var x=_(this).constructor;h=Reflect.construct(i,arguments,x)}else h=i.apply(this,arguments);return Y(this,h)}}function Y(c,a){if(a&&(f(a)==="object"||typeof a=="function"))return a;if(a!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return Z(c)}function Z(c){if(c===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return c}function X(){try{var c=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(X=function(){return!!c})()}function _(c){return _=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(S){return S.__proto__||Object.getPrototypeOf(S)},_(c)}function B(c,a){var S=Object.keys(c);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(c);a&&(i=i.filter(function(h){return Object.getOwnPropertyDescriptor(c,h).enumerable})),S.push.apply(S,i)}return S}function D(c){for(var a=1;a<arguments.length;a++){var S=arguments[a]!=null?arguments[a]:{};a%2?B(Object(S),!0).forEach(function(i){V(c,i,S[i])}):Object.getOwnPropertyDescriptors?Object.defineProperties(c,Object.getOwnPropertyDescriptors(S)):B(Object(S)).forEach(function(i){Object.defineProperty(c,i,Object.getOwnPropertyDescriptor(S,i))})}return c}function V(c,a,S){return a=J(a),a in c?Object.defineProperty(c,a,{value:S,enumerable:!0,configurable:!0,writable:!0}):c[a]=S,c}function J(c){var a=G(c,"string");return f(a)=="symbol"?a:String(a)}function G(c,a){if(f(c)!="object"||!c)return c;var S=c[Symbol.toPrimitive];if(S!==void 0){var i=S.call(c,a);if(f(i)!="object")return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return(a==="string"?String:Number)(c)}var s=function(a){var S,i,h,x,E;a.rtl?E=a.slideCount-1-a.index:E=a.index,h=E<0||E>=a.slideCount,a.centerMode?(x=Math.floor(a.slidesToShow/2),i=(E-a.currentSlide)%a.slideCount===0,E>a.currentSlide-x-1&&E<=a.currentSlide+x&&(S=!0)):S=a.currentSlide<=E&&E<a.currentSlide+a.slidesToShow;var P;a.targetSlide<0?P=a.targetSlide+a.slideCount:a.targetSlide>=a.slideCount?P=a.targetSlide-a.slideCount:P=a.targetSlide;var t=E===P;return{"slick-slide":!0,"slick-active":S,"slick-center":i,"slick-cloned":h,"slick-current":t}},v=function(a){var S={};return(a.variableWidth===void 0||a.variableWidth===!1)&&(S.width=a.slideWidth),a.fade&&(S.position="relative",a.vertical?S.top=-a.index*parseInt(a.slideHeight):S.left=-a.index*parseInt(a.slideWidth),S.opacity=a.currentSlide===a.index?1:0,S.zIndex=a.currentSlide===a.index?999:998,a.useCSS&&(S.transition="opacity "+a.speed+"ms "+a.cssEase+", visibility "+a.speed+"ms "+a.cssEase)),S},y=function(a,S){return a.key||S},k=function(a){var S,i=[],h=[],x=[],E=n.default.Children.count(a.children),P=(0,d.lazyStartIndex)(a),t=(0,d.lazyEndIndex)(a);return n.default.Children.forEach(a.children,function(q,u){var r,l={message:"children",index:u,slidesToScroll:a.slidesToScroll,currentSlide:a.currentSlide};!a.lazyLoad||a.lazyLoad&&a.lazyLoadedList.indexOf(u)>=0?r=q:r=n.default.createElement("div",null);var m=v(D(D({},a),{},{index:u})),T=r.props.className||"",N=s(D(D({},a),{},{index:u}));if(i.push(n.default.cloneElement(r,{key:"original"+y(r,u),"data-index":u,className:(0,o.default)(N,T),tabIndex:"-1","aria-hidden":!N["slick-active"],style:D(D({outline:"none"},r.props.style||{}),m),onClick:function(I){r.props&&r.props.onClick&&r.props.onClick(I),a.focusOnSelect&&a.focusOnSelect(l)}})),a.infinite&&a.fade===!1){var L=E-u;L<=(0,d.getPreClones)(a)&&(S=-L,S>=P&&(r=q),N=s(D(D({},a),{},{index:S})),h.push(n.default.cloneElement(r,{key:"precloned"+y(r,S),"data-index":S,tabIndex:"-1",className:(0,o.default)(N,T),"aria-hidden":!N["slick-active"],style:D(D({},r.props.style||{}),m),onClick:function(I){r.props&&r.props.onClick&&r.props.onClick(I),a.focusOnSelect&&a.focusOnSelect(l)}}))),S=E+u,S<t&&(r=q),N=s(D(D({},a),{},{index:S})),x.push(n.default.cloneElement(r,{key:"postcloned"+y(r,S),"data-index":S,tabIndex:"-1",className:(0,o.default)(N,T),"aria-hidden":!N["slick-active"],style:D(D({},r.props.style||{}),m),onClick:function(I){r.props&&r.props.onClick&&r.props.onClick(I),a.focusOnSelect&&a.focusOnSelect(l)}}))}}),a.rtl?h.concat(i,x).reverse():h.concat(i,x)};return _e.Track=function(c){j(S,c);var a=z(S);function S(){var i;g(this,S);for(var h=arguments.length,x=new Array(h),E=0;E<h;E++)x[E]=arguments[E];return i=a.call.apply(a,[this].concat(x)),V(Z(i),"node",null),V(Z(i),"handleRef",function(P){i.node=P}),i}return w(S,[{key:"render",value:function(){var h=k(this.props),x=this.props,E=x.onMouseEnter,P=x.onMouseOver,t=x.onMouseLeave,q={onMouseEnter:E,onMouseOver:P,onMouseLeave:t};return n.default.createElement("div",b({ref:this.handleRef,className:"slick-track",style:this.props.trackStyle},q),h)}}]),S}(n.default.PureComponent),_e}var Ee={},Rr;function xn(){if(Rr)return Ee;Rr=1;function n(s){"@babel/helpers - typeof";return n=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(v){return typeof v}:function(v){return v&&typeof Symbol=="function"&&v.constructor===Symbol&&v!==Symbol.prototype?"symbol":typeof v},n(s)}Object.defineProperty(Ee,"__esModule",{value:!0}),Ee.Dots=void 0;var o=f(Ne()),d=f(We()),p=De();function f(s){return s&&s.__esModule?s:{default:s}}function b(s,v){var y=Object.keys(s);if(Object.getOwnPropertySymbols){var k=Object.getOwnPropertySymbols(s);v&&(k=k.filter(function(c){return Object.getOwnPropertyDescriptor(s,c).enumerable})),y.push.apply(y,k)}return y}function g(s){for(var v=1;v<arguments.length;v++){var y=arguments[v]!=null?arguments[v]:{};v%2?b(Object(y),!0).forEach(function(k){C(s,k,y[k])}):Object.getOwnPropertyDescriptors?Object.defineProperties(s,Object.getOwnPropertyDescriptors(y)):b(Object(y)).forEach(function(k){Object.defineProperty(s,k,Object.getOwnPropertyDescriptor(y,k))})}return s}function C(s,v,y){return v=z(v),v in s?Object.defineProperty(s,v,{value:y,enumerable:!0,configurable:!0,writable:!0}):s[v]=y,s}function w(s,v){if(!(s instanceof v))throw new TypeError("Cannot call a class as a function")}function j(s,v){for(var y=0;y<v.length;y++){var k=v[y];k.enumerable=k.enumerable||!1,k.configurable=!0,"value"in k&&(k.writable=!0),Object.defineProperty(s,z(k.key),k)}}function O(s,v,y){return v&&j(s.prototype,v),Object.defineProperty(s,"prototype",{writable:!1}),s}function z(s){var v=Y(s,"string");return n(v)=="symbol"?v:String(v)}function Y(s,v){if(n(s)!="object"||!s)return s;var y=s[Symbol.toPrimitive];if(y!==void 0){var k=y.call(s,v);if(n(k)!="object")return k;throw new TypeError("@@toPrimitive must return a primitive value.")}return String(s)}function Z(s,v){if(typeof v!="function"&&v!==null)throw new TypeError("Super expression must either be null or a function");s.prototype=Object.create(v&&v.prototype,{constructor:{value:s,writable:!0,configurable:!0}}),Object.defineProperty(s,"prototype",{writable:!1}),v&&X(s,v)}function X(s,v){return X=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(k,c){return k.__proto__=c,k},X(s,v)}function _(s){var v=V();return function(){var k=J(s),c;if(v){var a=J(this).constructor;c=Reflect.construct(k,arguments,a)}else c=k.apply(this,arguments);return B(this,c)}}function B(s,v){if(v&&(n(v)==="object"||typeof v=="function"))return v;if(v!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return D(s)}function D(s){if(s===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return s}function V(){try{var s=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(V=function(){return!!s})()}function J(s){return J=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(y){return y.__proto__||Object.getPrototypeOf(y)},J(s)}var G=function(v){var y;return v.infinite?y=Math.ceil(v.slideCount/v.slidesToScroll):y=Math.ceil((v.slideCount-v.slidesToShow)/v.slidesToScroll)+1,y};return Ee.Dots=function(s){Z(y,s);var v=_(y);function y(){return w(this,y),v.apply(this,arguments)}return O(y,[{key:"clickHandler",value:function(c,a){a.preventDefault(),this.props.clickHandler(c)}},{key:"render",value:function(){for(var c=this.props,a=c.onMouseEnter,S=c.onMouseOver,i=c.onMouseLeave,h=c.infinite,x=c.slidesToScroll,E=c.slidesToShow,P=c.slideCount,t=c.currentSlide,q=G({slideCount:P,slidesToScroll:x,slidesToShow:E,infinite:h}),u={onMouseEnter:a,onMouseOver:S,onMouseLeave:i},r=[],l=0;l<q;l++){var m=(l+1)*x-1,T=h?m:(0,p.clamp)(m,0,P-1),N=T-(x-1),L=h?N:(0,p.clamp)(N,0,P-1),M=(0,d.default)({"slick-active":h?t>=L&&t<=T:t===L}),I={message:"dots",index:l,slidesToScroll:x,currentSlide:t},U=this.clickHandler.bind(this,I);r=r.concat(o.default.createElement("li",{key:l,className:M},o.default.cloneElement(this.props.customPaging(l),{onClick:U})))}return o.default.cloneElement(this.props.appendDots(r),g({className:this.props.dotsClass},u))}}]),y}(o.default.PureComponent),Ee}var Oe={},Dr;function Sn(){if(Dr)return Oe;Dr=1;function n(s){"@babel/helpers - typeof";return n=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(v){return typeof v}:function(v){return v&&typeof Symbol=="function"&&v.constructor===Symbol&&v!==Symbol.prototype?"symbol":typeof v},n(s)}Object.defineProperty(Oe,"__esModule",{value:!0}),Oe.PrevArrow=Oe.NextArrow=void 0;var o=f(Ne()),d=f(We()),p=De();function f(s){return s&&s.__esModule?s:{default:s}}function b(){return b=Object.assign?Object.assign.bind():function(s){for(var v=1;v<arguments.length;v++){var y=arguments[v];for(var k in y)Object.prototype.hasOwnProperty.call(y,k)&&(s[k]=y[k])}return s},b.apply(this,arguments)}function g(s,v){var y=Object.keys(s);if(Object.getOwnPropertySymbols){var k=Object.getOwnPropertySymbols(s);v&&(k=k.filter(function(c){return Object.getOwnPropertyDescriptor(s,c).enumerable})),y.push.apply(y,k)}return y}function C(s){for(var v=1;v<arguments.length;v++){var y=arguments[v]!=null?arguments[v]:{};v%2?g(Object(y),!0).forEach(function(k){w(s,k,y[k])}):Object.getOwnPropertyDescriptors?Object.defineProperties(s,Object.getOwnPropertyDescriptors(y)):g(Object(y)).forEach(function(k){Object.defineProperty(s,k,Object.getOwnPropertyDescriptor(y,k))})}return s}function w(s,v,y){return v=Y(v),v in s?Object.defineProperty(s,v,{value:y,enumerable:!0,configurable:!0,writable:!0}):s[v]=y,s}function j(s,v){if(!(s instanceof v))throw new TypeError("Cannot call a class as a function")}function O(s,v){for(var y=0;y<v.length;y++){var k=v[y];k.enumerable=k.enumerable||!1,k.configurable=!0,"value"in k&&(k.writable=!0),Object.defineProperty(s,Y(k.key),k)}}function z(s,v,y){return v&&O(s.prototype,v),Object.defineProperty(s,"prototype",{writable:!1}),s}function Y(s){var v=Z(s,"string");return n(v)=="symbol"?v:String(v)}function Z(s,v){if(n(s)!="object"||!s)return s;var y=s[Symbol.toPrimitive];if(y!==void 0){var k=y.call(s,v);if(n(k)!="object")return k;throw new TypeError("@@toPrimitive must return a primitive value.")}return String(s)}function X(s,v){if(typeof v!="function"&&v!==null)throw new TypeError("Super expression must either be null or a function");s.prototype=Object.create(v&&v.prototype,{constructor:{value:s,writable:!0,configurable:!0}}),Object.defineProperty(s,"prototype",{writable:!1}),v&&_(s,v)}function _(s,v){return _=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(k,c){return k.__proto__=c,k},_(s,v)}function B(s){var v=J();return function(){var k=G(s),c;if(v){var a=G(this).constructor;c=Reflect.construct(k,arguments,a)}else c=k.apply(this,arguments);return D(this,c)}}function D(s,v){if(v&&(n(v)==="object"||typeof v=="function"))return v;if(v!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return V(s)}function V(s){if(s===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return s}function J(){try{var s=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(J=function(){return!!s})()}function G(s){return G=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(y){return y.__proto__||Object.getPrototypeOf(y)},G(s)}return Oe.PrevArrow=function(s){X(y,s);var v=B(y);function y(){return j(this,y),v.apply(this,arguments)}return z(y,[{key:"clickHandler",value:function(c,a){a&&a.preventDefault(),this.props.clickHandler(c,a)}},{key:"render",value:function(){var c={"slick-arrow":!0,"slick-prev":!0},a=this.clickHandler.bind(this,{message:"previous"});!this.props.infinite&&(this.props.currentSlide===0||this.props.slideCount<=this.props.slidesToShow)&&(c["slick-disabled"]=!0,a=null);var S={key:"0","data-role":"none",className:(0,d.default)(c),style:{display:"block"},onClick:a},i={currentSlide:this.props.currentSlide,slideCount:this.props.slideCount},h;return this.props.prevArrow?h=o.default.cloneElement(this.props.prevArrow,C(C({},S),i)):h=o.default.createElement("button",b({key:"0",type:"button"},S)," ","Previous"),h}}]),y}(o.default.PureComponent),Oe.NextArrow=function(s){X(y,s);var v=B(y);function y(){return j(this,y),v.apply(this,arguments)}return z(y,[{key:"clickHandler",value:function(c,a){a&&a.preventDefault(),this.props.clickHandler(c,a)}},{key:"render",value:function(){var c={"slick-arrow":!0,"slick-next":!0},a=this.clickHandler.bind(this,{message:"next"});(0,p.canGoNext)(this.props)||(c["slick-disabled"]=!0,a=null);var S={key:"1","data-role":"none",className:(0,d.default)(c),style:{display:"block"},onClick:a},i={currentSlide:this.props.currentSlide,slideCount:this.props.slideCount},h;return this.props.nextArrow?h=o.default.cloneElement(this.props.nextArrow,C(C({},S),i)):h=o.default.createElement("button",b({key:"1",type:"button"},S)," ","Next"),h}}]),y}(o.default.PureComponent),Oe}var ni=function(){if(typeof Map<"u")return Map;function n(o,d){var p=-1;return o.some(function(f,b){return f[0]===d?(p=b,!0):!1}),p}return function(){function o(){this.__entries__=[]}return Object.defineProperty(o.prototype,"size",{get:function(){return this.__entries__.length},enumerable:!0,configurable:!0}),o.prototype.get=function(d){var p=n(this.__entries__,d),f=this.__entries__[p];return f&&f[1]},o.prototype.set=function(d,p){var f=n(this.__entries__,d);~f?this.__entries__[f][1]=p:this.__entries__.push([d,p])},o.prototype.delete=function(d){var p=this.__entries__,f=n(p,d);~f&&p.splice(f,1)},o.prototype.has=function(d){return!!~n(this.__entries__,d)},o.prototype.clear=function(){this.__entries__.splice(0)},o.prototype.forEach=function(d,p){p===void 0&&(p=null);for(var f=0,b=this.__entries__;f<b.length;f++){var g=b[f];d.call(p,g[1],g[0])}},o}()}(),ct=typeof window<"u"&&typeof document<"u"&&window.document===document,Fe=function(){return typeof globalThis<"u"&&globalThis.Math===Math?globalThis:typeof self<"u"&&self.Math===Math?self:typeof window<"u"&&window.Math===Math?window:Function("return this")()}(),jn=function(){return typeof requestAnimationFrame=="function"?requestAnimationFrame.bind(Fe):function(n){return setTimeout(function(){return n(Date.now())},1e3/60)}}(),wn=2;function Cn(n,o){var d=!1,p=!1,f=0;function b(){d&&(d=!1,n()),p&&C()}function g(){jn(b)}function C(){var w=Date.now();if(d){if(w-f<wn)return;p=!0}else d=!0,p=!1,setTimeout(g,o);f=w}return C}var On=20,Nn=["top","right","bottom","left","width","height","size","weight"],kn=typeof MutationObserver<"u",Tn=function(){function n(){this.connected_=!1,this.mutationEventsAdded_=!1,this.mutationsObserver_=null,this.observers_=[],this.onTransitionEnd_=this.onTransitionEnd_.bind(this),this.refresh=Cn(this.refresh.bind(this),On)}return n.prototype.addObserver=function(o){~this.observers_.indexOf(o)||this.observers_.push(o),this.connected_||this.connect_()},n.prototype.removeObserver=function(o){var d=this.observers_,p=d.indexOf(o);~p&&d.splice(p,1),!d.length&&this.connected_&&this.disconnect_()},n.prototype.refresh=function(){var o=this.updateObservers_();o&&this.refresh()},n.prototype.updateObservers_=function(){var o=this.observers_.filter(function(d){return d.gatherActive(),d.hasActive()});return o.forEach(function(d){return d.broadcastActive()}),o.length>0},n.prototype.connect_=function(){!ct||this.connected_||(document.addEventListener("transitionend",this.onTransitionEnd_),window.addEventListener("resize",this.refresh),kn?(this.mutationsObserver_=new MutationObserver(this.refresh),this.mutationsObserver_.observe(document,{attributes:!0,childList:!0,characterData:!0,subtree:!0})):(document.addEventListener("DOMSubtreeModified",this.refresh),this.mutationEventsAdded_=!0),this.connected_=!0)},n.prototype.disconnect_=function(){!ct||!this.connected_||(document.removeEventListener("transitionend",this.onTransitionEnd_),window.removeEventListener("resize",this.refresh),this.mutationsObserver_&&this.mutationsObserver_.disconnect(),this.mutationEventsAdded_&&document.removeEventListener("DOMSubtreeModified",this.refresh),this.mutationsObserver_=null,this.mutationEventsAdded_=!1,this.connected_=!1)},n.prototype.onTransitionEnd_=function(o){var d=o.propertyName,p=d===void 0?"":d,f=Nn.some(function(b){return!!~p.indexOf(b)});f&&this.refresh()},n.getInstance=function(){return this.instance_||(this.instance_=new n),this.instance_},n.instance_=null,n}(),ai=function(n,o){for(var d=0,p=Object.keys(o);d<p.length;d++){var f=p[d];Object.defineProperty(n,f,{value:o[f],enumerable:!1,writable:!1,configurable:!0})}return n},ke=function(n){var o=n&&n.ownerDocument&&n.ownerDocument.defaultView;return o||Fe},li=Ze(0,0,0,0);function qe(n){return parseFloat(n)||0}function Ar(n){for(var o=[],d=1;d<arguments.length;d++)o[d-1]=arguments[d];return o.reduce(function(p,f){var b=n["border-"+f+"-width"];return p+qe(b)},0)}function Pn(n){for(var o=["top","right","bottom","left"],d={},p=0,f=o;p<f.length;p++){var b=f[p],g=n["padding-"+b];d[b]=qe(g)}return d}function Mn(n){var o=n.getBBox();return Ze(0,0,o.width,o.height)}function _n(n){var o=n.clientWidth,d=n.clientHeight;if(!o&&!d)return li;var p=ke(n).getComputedStyle(n),f=Pn(p),b=f.left+f.right,g=f.top+f.bottom,C=qe(p.width),w=qe(p.height);if(p.boxSizing==="border-box"&&(Math.round(C+b)!==o&&(C-=Ar(p,"left","right")+b),Math.round(w+g)!==d&&(w-=Ar(p,"top","bottom")+g)),!Ln(n)){var j=Math.round(C+b)-o,O=Math.round(w+g)-d;Math.abs(j)!==1&&(C-=j),Math.abs(O)!==1&&(w-=O)}return Ze(f.left,f.top,C,w)}var En=function(){return typeof SVGGraphicsElement<"u"?function(n){return n instanceof ke(n).SVGGraphicsElement}:function(n){return n instanceof ke(n).SVGElement&&typeof n.getBBox=="function"}}();function Ln(n){return n===ke(n).document.documentElement}function In(n){return ct?En(n)?Mn(n):_n(n):li}function Rn(n){var o=n.x,d=n.y,p=n.width,f=n.height,b=typeof DOMRectReadOnly<"u"?DOMRectReadOnly:Object,g=Object.create(b.prototype);return ai(g,{x:o,y:d,width:p,height:f,top:d,right:o+p,bottom:f+d,left:o}),g}function Ze(n,o,d,p){return{x:n,y:o,width:d,height:p}}var Dn=function(){function n(o){this.broadcastWidth=0,this.broadcastHeight=0,this.contentRect_=Ze(0,0,0,0),this.target=o}return n.prototype.isActive=function(){var o=In(this.target);return this.contentRect_=o,o.width!==this.broadcastWidth||o.height!==this.broadcastHeight},n.prototype.broadcastRect=function(){var o=this.contentRect_;return this.broadcastWidth=o.width,this.broadcastHeight=o.height,o},n}(),An=function(){function n(o,d){var p=Rn(d);ai(this,{target:o,contentRect:p})}return n}(),zn=function(){function n(o,d,p){if(this.activeObservations_=[],this.observations_=new ni,typeof o!="function")throw new TypeError("The callback provided as parameter 1 is not a function.");this.callback_=o,this.controller_=d,this.callbackCtx_=p}return n.prototype.observe=function(o){if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.");if(!(typeof Element>"u"||!(Element instanceof Object))){if(!(o instanceof ke(o).Element))throw new TypeError('parameter 1 is not of type "Element".');var d=this.observations_;d.has(o)||(d.set(o,new Dn(o)),this.controller_.addObserver(this),this.controller_.refresh())}},n.prototype.unobserve=function(o){if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.");if(!(typeof Element>"u"||!(Element instanceof Object))){if(!(o instanceof ke(o).Element))throw new TypeError('parameter 1 is not of type "Element".');var d=this.observations_;d.has(o)&&(d.delete(o),d.size||this.controller_.removeObserver(this))}},n.prototype.disconnect=function(){this.clearActive(),this.observations_.clear(),this.controller_.removeObserver(this)},n.prototype.gatherActive=function(){var o=this;this.clearActive(),this.observations_.forEach(function(d){d.isActive()&&o.activeObservations_.push(d)})},n.prototype.broadcastActive=function(){if(this.hasActive()){var o=this.callbackCtx_,d=this.activeObservations_.map(function(p){return new An(p.target,p.broadcastRect())});this.callback_.call(o,d,o),this.clearActive()}},n.prototype.clearActive=function(){this.activeObservations_.splice(0)},n.prototype.hasActive=function(){return this.activeObservations_.length>0},n}(),oi=typeof WeakMap<"u"?new WeakMap:new ni,si=function(){function n(o){if(!(this instanceof n))throw new TypeError("Cannot call a class as a function.");if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.");var d=Tn.getInstance(),p=new zn(o,d,this);oi.set(this,p)}return n}();["observe","unobserve","disconnect"].forEach(function(n){si.prototype[n]=function(){var o;return(o=oi.get(this))[n].apply(o,arguments)}});var Bn=function(){return typeof Fe.ResizeObserver<"u"?Fe.ResizeObserver:si}();const Vn=Object.freeze(Object.defineProperty({__proto__:null,default:Bn},Symbol.toStringTag,{value:"Module"})),Hn=wi(Vn);var zr;function Fn(){if(zr)return Me;zr=1,Object.defineProperty(Me,"__esModule",{value:!0}),Me.InnerSlider=void 0;var n=j(Ne()),o=j(bn()),d=j(gn()),p=j(We()),f=De(),b=yn(),g=xn(),C=Sn(),w=j(Hn);function j(h){return h&&h.__esModule?h:{default:h}}function O(h){"@babel/helpers - typeof";return O=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(x){return typeof x}:function(x){return x&&typeof Symbol=="function"&&x.constructor===Symbol&&x!==Symbol.prototype?"symbol":typeof x},O(h)}function z(){return z=Object.assign?Object.assign.bind():function(h){for(var x=1;x<arguments.length;x++){var E=arguments[x];for(var P in E)Object.prototype.hasOwnProperty.call(E,P)&&(h[P]=E[P])}return h},z.apply(this,arguments)}function Y(h,x){if(h==null)return{};var E=Z(h,x),P,t;if(Object.getOwnPropertySymbols){var q=Object.getOwnPropertySymbols(h);for(t=0;t<q.length;t++)P=q[t],!(x.indexOf(P)>=0)&&Object.prototype.propertyIsEnumerable.call(h,P)&&(E[P]=h[P])}return E}function Z(h,x){if(h==null)return{};var E={},P=Object.keys(h),t,q;for(q=0;q<P.length;q++)t=P[q],!(x.indexOf(t)>=0)&&(E[t]=h[t]);return E}function X(h,x){var E=Object.keys(h);if(Object.getOwnPropertySymbols){var P=Object.getOwnPropertySymbols(h);x&&(P=P.filter(function(t){return Object.getOwnPropertyDescriptor(h,t).enumerable})),E.push.apply(E,P)}return E}function _(h){for(var x=1;x<arguments.length;x++){var E=arguments[x]!=null?arguments[x]:{};x%2?X(Object(E),!0).forEach(function(P){a(h,P,E[P])}):Object.getOwnPropertyDescriptors?Object.defineProperties(h,Object.getOwnPropertyDescriptors(E)):X(Object(E)).forEach(function(P){Object.defineProperty(h,P,Object.getOwnPropertyDescriptor(E,P))})}return h}function B(h,x){if(!(h instanceof x))throw new TypeError("Cannot call a class as a function")}function D(h,x){for(var E=0;E<x.length;E++){var P=x[E];P.enumerable=P.enumerable||!1,P.configurable=!0,"value"in P&&(P.writable=!0),Object.defineProperty(h,S(P.key),P)}}function V(h,x,E){return x&&D(h.prototype,x),Object.defineProperty(h,"prototype",{writable:!1}),h}function J(h,x){if(typeof x!="function"&&x!==null)throw new TypeError("Super expression must either be null or a function");h.prototype=Object.create(x&&x.prototype,{constructor:{value:h,writable:!0,configurable:!0}}),Object.defineProperty(h,"prototype",{writable:!1}),x&&G(h,x)}function G(h,x){return G=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(P,t){return P.__proto__=t,P},G(h,x)}function s(h){var x=k();return function(){var P=c(h),t;if(x){var q=c(this).constructor;t=Reflect.construct(P,arguments,q)}else t=P.apply(this,arguments);return v(this,t)}}function v(h,x){if(x&&(O(x)==="object"||typeof x=="function"))return x;if(x!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return y(h)}function y(h){if(h===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return h}function k(){try{var h=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(k=function(){return!!h})()}function c(h){return c=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(E){return E.__proto__||Object.getPrototypeOf(E)},c(h)}function a(h,x,E){return x=S(x),x in h?Object.defineProperty(h,x,{value:E,enumerable:!0,configurable:!0,writable:!0}):h[x]=E,h}function S(h){var x=i(h,"string");return O(x)=="symbol"?x:String(x)}function i(h,x){if(O(h)!="object"||!h)return h;var E=h[Symbol.toPrimitive];if(E!==void 0){var P=E.call(h,x);if(O(P)!="object")return P;throw new TypeError("@@toPrimitive must return a primitive value.")}return(x==="string"?String:Number)(h)}return Me.InnerSlider=function(h){J(E,h);var x=s(E);function E(P){var t;B(this,E),t=x.call(this,P),a(y(t),"listRefHandler",function(u){return t.list=u}),a(y(t),"trackRefHandler",function(u){return t.track=u}),a(y(t),"adaptHeight",function(){if(t.props.adaptiveHeight&&t.list){var u=t.list.querySelector('[data-index="'.concat(t.state.currentSlide,'"]'));t.list.style.height=(0,f.getHeight)(u)+"px"}}),a(y(t),"componentDidMount",function(){if(t.props.onInit&&t.props.onInit(),t.props.lazyLoad){var u=(0,f.getOnDemandLazySlides)(_(_({},t.props),t.state));u.length>0&&(t.setState(function(l){return{lazyLoadedList:l.lazyLoadedList.concat(u)}}),t.props.onLazyLoad&&t.props.onLazyLoad(u))}var r=_({listRef:t.list,trackRef:t.track},t.props);t.updateState(r,!0,function(){t.adaptHeight(),t.props.autoplay&&t.autoPlay("update")}),t.props.lazyLoad==="progressive"&&(t.lazyLoadTimer=setInterval(t.progressiveLazyLoad,1e3)),t.ro=new w.default(function(){t.state.animating?(t.onWindowResized(!1),t.callbackTimers.push(setTimeout(function(){return t.onWindowResized()},t.props.speed))):t.onWindowResized()}),t.ro.observe(t.list),document.querySelectorAll&&Array.prototype.forEach.call(document.querySelectorAll(".slick-slide"),function(l){l.onfocus=t.props.pauseOnFocus?t.onSlideFocus:null,l.onblur=t.props.pauseOnFocus?t.onSlideBlur:null}),window.addEventListener?window.addEventListener("resize",t.onWindowResized):window.attachEvent("onresize",t.onWindowResized)}),a(y(t),"componentWillUnmount",function(){t.animationEndCallback&&clearTimeout(t.animationEndCallback),t.lazyLoadTimer&&clearInterval(t.lazyLoadTimer),t.callbackTimers.length&&(t.callbackTimers.forEach(function(u){return clearTimeout(u)}),t.callbackTimers=[]),window.addEventListener?window.removeEventListener("resize",t.onWindowResized):window.detachEvent("onresize",t.onWindowResized),t.autoplayTimer&&clearInterval(t.autoplayTimer),t.ro.disconnect()}),a(y(t),"componentDidUpdate",function(u){if(t.checkImagesLoad(),t.props.onReInit&&t.props.onReInit(),t.props.lazyLoad){var r=(0,f.getOnDemandLazySlides)(_(_({},t.props),t.state));r.length>0&&(t.setState(function(T){return{lazyLoadedList:T.lazyLoadedList.concat(r)}}),t.props.onLazyLoad&&t.props.onLazyLoad(r))}t.adaptHeight();var l=_(_({listRef:t.list,trackRef:t.track},t.props),t.state),m=t.didPropsChange(u);m&&t.updateState(l,m,function(){t.state.currentSlide>=n.default.Children.count(t.props.children)&&t.changeSlide({message:"index",index:n.default.Children.count(t.props.children)-t.props.slidesToShow,currentSlide:t.state.currentSlide}),t.props.autoplay?t.autoPlay("update"):t.pause("paused")})}),a(y(t),"onWindowResized",function(u){t.debouncedResize&&t.debouncedResize.cancel(),t.debouncedResize=(0,d.default)(function(){return t.resizeWindow(u)},50),t.debouncedResize()}),a(y(t),"resizeWindow",function(){var u=arguments.length>0&&arguments[0]!==void 0?arguments[0]:!0,r=!!(t.track&&t.track.node);if(r){var l=_(_({listRef:t.list,trackRef:t.track},t.props),t.state);t.updateState(l,u,function(){t.props.autoplay?t.autoPlay("update"):t.pause("paused")}),t.setState({animating:!1}),clearTimeout(t.animationEndCallback),delete t.animationEndCallback}}),a(y(t),"updateState",function(u,r,l){var m=(0,f.initializedState)(u);u=_(_(_({},u),m),{},{slideIndex:m.currentSlide});var T=(0,f.getTrackLeft)(u);u=_(_({},u),{},{left:T});var N=(0,f.getTrackCSS)(u);(r||n.default.Children.count(t.props.children)!==n.default.Children.count(u.children))&&(m.trackStyle=N),t.setState(m,l)}),a(y(t),"ssrInit",function(){if(t.props.variableWidth){var u=0,r=0,l=[],m=(0,f.getPreClones)(_(_(_({},t.props),t.state),{},{slideCount:t.props.children.length})),T=(0,f.getPostClones)(_(_(_({},t.props),t.state),{},{slideCount:t.props.children.length}));t.props.children.forEach(function(le){l.push(le.props.style.width),u+=le.props.style.width});for(var N=0;N<m;N++)r+=l[l.length-1-N],u+=l[l.length-1-N];for(var L=0;L<T;L++)u+=l[L];for(var M=0;M<t.state.currentSlide;M++)r+=l[M];var I={width:u+"px",left:-r+"px"};if(t.props.centerMode){var U="".concat(l[t.state.currentSlide],"px");I.left="calc(".concat(I.left," + (100% - ").concat(U,") / 2 ) ")}return{trackStyle:I}}var W=n.default.Children.count(t.props.children),K=_(_(_({},t.props),t.state),{},{slideCount:W}),re=(0,f.getPreClones)(K)+(0,f.getPostClones)(K)+W,ee=100/t.props.slidesToShow*re,Q=100/re,F=-Q*((0,f.getPreClones)(K)+t.state.currentSlide)*ee/100;t.props.centerMode&&(F+=(100-Q*ee/100)/2);var $={width:ee+"%",left:F+"%"};return{slideWidth:Q+"%",trackStyle:$}}),a(y(t),"checkImagesLoad",function(){var u=t.list&&t.list.querySelectorAll&&t.list.querySelectorAll(".slick-slide img")||[],r=u.length,l=0;Array.prototype.forEach.call(u,function(m){var T=function(){return++l&&l>=r&&t.onWindowResized()};if(!m.onclick)m.onclick=function(){return m.parentNode.focus()};else{var N=m.onclick;m.onclick=function(L){N(L),m.parentNode.focus()}}m.onload||(t.props.lazyLoad?m.onload=function(){t.adaptHeight(),t.callbackTimers.push(setTimeout(t.onWindowResized,t.props.speed))}:(m.onload=T,m.onerror=function(){T(),t.props.onLazyLoadError&&t.props.onLazyLoadError()}))})}),a(y(t),"progressiveLazyLoad",function(){for(var u=[],r=_(_({},t.props),t.state),l=t.state.currentSlide;l<t.state.slideCount+(0,f.getPostClones)(r);l++)if(t.state.lazyLoadedList.indexOf(l)<0){u.push(l);break}for(var m=t.state.currentSlide-1;m>=-(0,f.getPreClones)(r);m--)if(t.state.lazyLoadedList.indexOf(m)<0){u.push(m);break}u.length>0?(t.setState(function(T){return{lazyLoadedList:T.lazyLoadedList.concat(u)}}),t.props.onLazyLoad&&t.props.onLazyLoad(u)):t.lazyLoadTimer&&(clearInterval(t.lazyLoadTimer),delete t.lazyLoadTimer)}),a(y(t),"slideHandler",function(u){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1,l=t.props,m=l.asNavFor,T=l.beforeChange,N=l.onLazyLoad,L=l.speed,M=l.afterChange,I=t.state.currentSlide,U=(0,f.slideHandler)(_(_(_({index:u},t.props),t.state),{},{trackRef:t.track,useCSS:t.props.useCSS&&!r})),W=U.state,K=U.nextState;if(W){T&&T(I,W.currentSlide);var re=W.lazyLoadedList.filter(function(ee){return t.state.lazyLoadedList.indexOf(ee)<0});N&&re.length>0&&N(re),!t.props.waitForAnimate&&t.animationEndCallback&&(clearTimeout(t.animationEndCallback),M&&M(I),delete t.animationEndCallback),t.setState(W,function(){m&&t.asNavForIndex!==u&&(t.asNavForIndex=u,m.innerSlider.slideHandler(u)),K&&(t.animationEndCallback=setTimeout(function(){var ee=K.animating,Q=Y(K,["animating"]);t.setState(Q,function(){t.callbackTimers.push(setTimeout(function(){return t.setState({animating:ee})},10)),M&&M(W.currentSlide),delete t.animationEndCallback})},L))})}}),a(y(t),"changeSlide",function(u){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1,l=_(_({},t.props),t.state),m=(0,f.changeSlide)(l,u);if(!(m!==0&&!m)&&(r===!0?t.slideHandler(m,r):t.slideHandler(m),t.props.autoplay&&t.autoPlay("update"),t.props.focusOnSelect)){var T=t.list.querySelectorAll(".slick-current");T[0]&&T[0].focus()}}),a(y(t),"clickHandler",function(u){t.clickable===!1&&(u.stopPropagation(),u.preventDefault()),t.clickable=!0}),a(y(t),"keyHandler",function(u){var r=(0,f.keyHandler)(u,t.props.accessibility,t.props.rtl);r!==""&&t.changeSlide({message:r})}),a(y(t),"selectHandler",function(u){t.changeSlide(u)}),a(y(t),"disableBodyScroll",function(){var u=function(l){l=l||window.event,l.preventDefault&&l.preventDefault(),l.returnValue=!1};window.ontouchmove=u}),a(y(t),"enableBodyScroll",function(){window.ontouchmove=null}),a(y(t),"swipeStart",function(u){t.props.verticalSwiping&&t.disableBodyScroll();var r=(0,f.swipeStart)(u,t.props.swipe,t.props.draggable);r!==""&&t.setState(r)}),a(y(t),"swipeMove",function(u){var r=(0,f.swipeMove)(u,_(_(_({},t.props),t.state),{},{trackRef:t.track,listRef:t.list,slideIndex:t.state.currentSlide}));r&&(r.swiping&&(t.clickable=!1),t.setState(r))}),a(y(t),"swipeEnd",function(u){var r=(0,f.swipeEnd)(u,_(_(_({},t.props),t.state),{},{trackRef:t.track,listRef:t.list,slideIndex:t.state.currentSlide}));if(r){var l=r.triggerSlideHandler;delete r.triggerSlideHandler,t.setState(r),l!==void 0&&(t.slideHandler(l),t.props.verticalSwiping&&t.enableBodyScroll())}}),a(y(t),"touchEnd",function(u){t.swipeEnd(u),t.clickable=!0}),a(y(t),"slickPrev",function(){t.callbackTimers.push(setTimeout(function(){return t.changeSlide({message:"previous"})},0))}),a(y(t),"slickNext",function(){t.callbackTimers.push(setTimeout(function(){return t.changeSlide({message:"next"})},0))}),a(y(t),"slickGoTo",function(u){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1;if(u=Number(u),isNaN(u))return"";t.callbackTimers.push(setTimeout(function(){return t.changeSlide({message:"index",index:u,currentSlide:t.state.currentSlide},r)},0))}),a(y(t),"play",function(){var u;if(t.props.rtl)u=t.state.currentSlide-t.props.slidesToScroll;else if((0,f.canGoNext)(_(_({},t.props),t.state)))u=t.state.currentSlide+t.props.slidesToScroll;else return!1;t.slideHandler(u)}),a(y(t),"autoPlay",function(u){t.autoplayTimer&&clearInterval(t.autoplayTimer);var r=t.state.autoplaying;if(u==="update"){if(r==="hovered"||r==="focused"||r==="paused")return}else if(u==="leave"){if(r==="paused"||r==="focused")return}else if(u==="blur"&&(r==="paused"||r==="hovered"))return;t.autoplayTimer=setInterval(t.play,t.props.autoplaySpeed+50),t.setState({autoplaying:"playing"})}),a(y(t),"pause",function(u){t.autoplayTimer&&(clearInterval(t.autoplayTimer),t.autoplayTimer=null);var r=t.state.autoplaying;u==="paused"?t.setState({autoplaying:"paused"}):u==="focused"?(r==="hovered"||r==="playing")&&t.setState({autoplaying:"focused"}):r==="playing"&&t.setState({autoplaying:"hovered"})}),a(y(t),"onDotsOver",function(){return t.props.autoplay&&t.pause("hovered")}),a(y(t),"onDotsLeave",function(){return t.props.autoplay&&t.state.autoplaying==="hovered"&&t.autoPlay("leave")}),a(y(t),"onTrackOver",function(){return t.props.autoplay&&t.pause("hovered")}),a(y(t),"onTrackLeave",function(){return t.props.autoplay&&t.state.autoplaying==="hovered"&&t.autoPlay("leave")}),a(y(t),"onSlideFocus",function(){return t.props.autoplay&&t.pause("focused")}),a(y(t),"onSlideBlur",function(){return t.props.autoplay&&t.state.autoplaying==="focused"&&t.autoPlay("blur")}),a(y(t),"render",function(){var u=(0,p.default)("slick-slider",t.props.className,{"slick-vertical":t.props.vertical,"slick-initialized":!0}),r=_(_({},t.props),t.state),l=(0,f.extractObject)(r,["fade","cssEase","speed","infinite","centerMode","focusOnSelect","currentSlide","lazyLoad","lazyLoadedList","rtl","slideWidth","slideHeight","listHeight","vertical","slidesToShow","slidesToScroll","slideCount","trackStyle","variableWidth","unslick","centerPadding","targetSlide","useCSS"]),m=t.props.pauseOnHover;l=_(_({},l),{},{onMouseEnter:m?t.onTrackOver:null,onMouseLeave:m?t.onTrackLeave:null,onMouseOver:m?t.onTrackOver:null,focusOnSelect:t.props.focusOnSelect&&t.clickable?t.selectHandler:null});var T;if(t.props.dots===!0&&t.state.slideCount>=t.props.slidesToShow){var N=(0,f.extractObject)(r,["dotsClass","slideCount","slidesToShow","currentSlide","slidesToScroll","clickHandler","children","customPaging","infinite","appendDots"]),L=t.props.pauseOnDotsHover;N=_(_({},N),{},{clickHandler:t.changeSlide,onMouseEnter:L?t.onDotsLeave:null,onMouseOver:L?t.onDotsOver:null,onMouseLeave:L?t.onDotsLeave:null}),T=n.default.createElement(g.Dots,N)}var M,I,U=(0,f.extractObject)(r,["infinite","centerMode","currentSlide","slideCount","slidesToShow","prevArrow","nextArrow"]);U.clickHandler=t.changeSlide,t.props.arrows&&(M=n.default.createElement(C.PrevArrow,U),I=n.default.createElement(C.NextArrow,U));var W=null;t.props.vertical&&(W={height:t.state.listHeight});var K=null;t.props.vertical===!1?t.props.centerMode===!0&&(K={padding:"0px "+t.props.centerPadding}):t.props.centerMode===!0&&(K={padding:t.props.centerPadding+" 0px"});var re=_(_({},W),K),ee=t.props.touchMove,Q={className:"slick-list",style:re,onClick:t.clickHandler,onMouseDown:ee?t.swipeStart:null,onMouseMove:t.state.dragging&&ee?t.swipeMove:null,onMouseUp:ee?t.swipeEnd:null,onMouseLeave:t.state.dragging&&ee?t.swipeEnd:null,onTouchStart:ee?t.swipeStart:null,onTouchMove:t.state.dragging&&ee?t.swipeMove:null,onTouchEnd:ee?t.touchEnd:null,onTouchCancel:t.state.dragging&&ee?t.swipeEnd:null,onKeyDown:t.props.accessibility?t.keyHandler:null},F={className:u,dir:"ltr",style:t.props.style};return t.props.unslick&&(Q={className:"slick-list"},F={className:u}),n.default.createElement("div",F,t.props.unslick?"":M,n.default.createElement("div",z({ref:t.listRefHandler},Q),n.default.createElement(b.Track,z({ref:t.trackRefHandler},l),t.props.children)),t.props.unslick?"":I,t.props.unslick?"":T)}),t.list=null,t.track=null,t.state=_(_({},o.default),{},{currentSlide:t.props.initialSlide,targetSlide:t.props.initialSlide?t.props.initialSlide:0,slideCount:n.default.Children.count(t.props.children)}),t.callbackTimers=[],t.clickable=!0,t.debouncedResize=null;var q=t.ssrInit();return t.state=_(_({},t.state),q),t}return V(E,[{key:"didPropsChange",value:function(t){for(var q=!1,u=0,r=Object.keys(this.props);u<r.length;u++){var l=r[u];if(!t.hasOwnProperty(l)){q=!0;break}if(!(O(t[l])==="object"||typeof t[l]=="function"||isNaN(t[l]))&&t[l]!==this.props[l]){q=!0;break}}return q||n.default.Children.count(this.props.children)!==n.default.Children.count(t.children)}}]),E}(n.default.Component),Me}var rt,Br;function qn(){if(Br)return rt;Br=1;var n=function(o){return o.replace(/[A-Z]/g,function(d){return"-"+d.toLowerCase()}).toLowerCase()};return rt=n,rt}var it,Vr;function Un(){if(Vr)return it;Vr=1;var n=qn(),o=function(f){var b=/[height|width]$/;return b.test(f)},d=function(f){var b="",g=Object.keys(f);return g.forEach(function(C,w){var j=f[C];C=n(C),o(C)&&typeof j=="number"&&(j=j+"px"),j===!0?b+=C:j===!1?b+="not "+C:b+="("+C+": "+j+")",w<g.length-1&&(b+=" and ")}),b},p=function(f){var b="";return typeof f=="string"?f:f instanceof Array?(f.forEach(function(g,C){b+=d(g),C<f.length-1&&(b+=", ")}),b):d(f)};return it=p,it}var nt,Hr;function Wn(){if(Hr)return nt;Hr=1;function n(o){this.options=o,!o.deferSetup&&this.setup()}return n.prototype={constructor:n,setup:function(){this.options.setup&&this.options.setup(),this.initialised=!0},on:function(){!this.initialised&&this.setup(),this.options.match&&this.options.match()},off:function(){this.options.unmatch&&this.options.unmatch()},destroy:function(){this.options.destroy?this.options.destroy():this.off()},equals:function(o){return this.options===o||this.options.match===o}},nt=n,nt}var at,Fr;function ci(){if(Fr)return at;Fr=1;function n(p,f){var b=0,g=p.length,C;for(b;b<g&&(C=f(p[b],b),C!==!1);b++);}function o(p){return Object.prototype.toString.apply(p)==="[object Array]"}function d(p){return typeof p=="function"}return at={isFunction:d,isArray:o,each:n},at}var lt,qr;function Zn(){if(qr)return lt;qr=1;var n=Wn(),o=ci().each;function d(p,f){this.query=p,this.isUnconditional=f,this.handlers=[],this.mql=window.matchMedia(p);var b=this;this.listener=function(g){b.mql=g.currentTarget||g,b.assess()},this.mql.addListener(this.listener)}return d.prototype={constuctor:d,addHandler:function(p){var f=new n(p);this.handlers.push(f),this.matches()&&f.on()},removeHandler:function(p){var f=this.handlers;o(f,function(b,g){if(b.equals(p))return b.destroy(),!f.splice(g,1)})},matches:function(){return this.mql.matches||this.isUnconditional},clear:function(){o(this.handlers,function(p){p.destroy()}),this.mql.removeListener(this.listener),this.handlers.length=0},assess:function(){var p=this.matches()?"on":"off";o(this.handlers,function(f){f[p]()})}},lt=d,lt}var ot,Ur;function Kn(){if(Ur)return ot;Ur=1;var n=Zn(),o=ci(),d=o.each,p=o.isFunction,f=o.isArray;function b(){if(!window.matchMedia)throw new Error("matchMedia not present, legacy browsers require a polyfill");this.queries={},this.browserIsIncapable=!window.matchMedia("only all").matches}return b.prototype={constructor:b,register:function(g,C,w){var j=this.queries,O=w&&this.browserIsIncapable;return j[g]||(j[g]=new n(g,O)),p(C)&&(C={match:C}),f(C)||(C=[C]),d(C,function(z){p(z)&&(z={match:z}),j[g].addHandler(z)}),this},unregister:function(g,C){var w=this.queries[g];return w&&(C?w.removeHandler(C):(w.clear(),delete this.queries[g])),this}},ot=b,ot}var st,Wr;function Gn(){if(Wr)return st;Wr=1;var n=Kn();return st=new n,st}var Zr;function Qn(){return Zr||(Zr=1,function(n){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=g(Ne()),d=Fn(),p=g(Un()),f=g(ii()),b=De();function g(c){return c&&c.__esModule?c:{default:c}}function C(c){"@babel/helpers - typeof";return C=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(a){return typeof a}:function(a){return a&&typeof Symbol=="function"&&a.constructor===Symbol&&a!==Symbol.prototype?"symbol":typeof a},C(c)}function w(){return w=Object.assign?Object.assign.bind():function(c){for(var a=1;a<arguments.length;a++){var S=arguments[a];for(var i in S)Object.prototype.hasOwnProperty.call(S,i)&&(c[i]=S[i])}return c},w.apply(this,arguments)}function j(c,a){var S=Object.keys(c);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(c);a&&(i=i.filter(function(h){return Object.getOwnPropertyDescriptor(c,h).enumerable})),S.push.apply(S,i)}return S}function O(c){for(var a=1;a<arguments.length;a++){var S=arguments[a]!=null?arguments[a]:{};a%2?j(Object(S),!0).forEach(function(i){s(c,i,S[i])}):Object.getOwnPropertyDescriptors?Object.defineProperties(c,Object.getOwnPropertyDescriptors(S)):j(Object(S)).forEach(function(i){Object.defineProperty(c,i,Object.getOwnPropertyDescriptor(S,i))})}return c}function z(c,a){if(!(c instanceof a))throw new TypeError("Cannot call a class as a function")}function Y(c,a){for(var S=0;S<a.length;S++){var i=a[S];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(c,v(i.key),i)}}function Z(c,a,S){return a&&Y(c.prototype,a),Object.defineProperty(c,"prototype",{writable:!1}),c}function X(c,a){if(typeof a!="function"&&a!==null)throw new TypeError("Super expression must either be null or a function");c.prototype=Object.create(a&&a.prototype,{constructor:{value:c,writable:!0,configurable:!0}}),Object.defineProperty(c,"prototype",{writable:!1}),a&&_(c,a)}function _(c,a){return _=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(i,h){return i.__proto__=h,i},_(c,a)}function B(c){var a=J();return function(){var i=G(c),h;if(a){var x=G(this).constructor;h=Reflect.construct(i,arguments,x)}else h=i.apply(this,arguments);return D(this,h)}}function D(c,a){if(a&&(C(a)==="object"||typeof a=="function"))return a;if(a!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return V(c)}function V(c){if(c===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return c}function J(){try{var c=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(J=function(){return!!c})()}function G(c){return G=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(S){return S.__proto__||Object.getPrototypeOf(S)},G(c)}function s(c,a,S){return a=v(a),a in c?Object.defineProperty(c,a,{value:S,enumerable:!0,configurable:!0,writable:!0}):c[a]=S,c}function v(c){var a=y(c,"string");return C(a)=="symbol"?a:String(a)}function y(c,a){if(C(c)!="object"||!c)return c;var S=c[Symbol.toPrimitive];if(S!==void 0){var i=S.call(c,a);if(C(i)!="object")return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return(a==="string"?String:Number)(c)}var k=(0,b.canUseDOM)()&&Gn();n.default=function(c){X(S,c);var a=B(S);function S(i){var h;return z(this,S),h=a.call(this,i),s(V(h),"innerSliderRefHandler",function(x){return h.innerSlider=x}),s(V(h),"slickPrev",function(){return h.innerSlider.slickPrev()}),s(V(h),"slickNext",function(){return h.innerSlider.slickNext()}),s(V(h),"slickGoTo",function(x){var E=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1;return h.innerSlider.slickGoTo(x,E)}),s(V(h),"slickPause",function(){return h.innerSlider.pause("paused")}),s(V(h),"slickPlay",function(){return h.innerSlider.autoPlay("play")}),h.state={breakpoint:null},h._responsiveMediaHandlers=[],h}return Z(S,[{key:"media",value:function(h,x){k.register(h,x),this._responsiveMediaHandlers.push({query:h,handler:x})}},{key:"componentDidMount",value:function(){var h=this;if(this.props.responsive){var x=this.props.responsive.map(function(P){return P.breakpoint});x.sort(function(P,t){return P-t}),x.forEach(function(P,t){var q;t===0?q=(0,p.default)({minWidth:0,maxWidth:P}):q=(0,p.default)({minWidth:x[t-1]+1,maxWidth:P}),(0,b.canUseDOM)()&&h.media(q,function(){h.setState({breakpoint:P})})});var E=(0,p.default)({minWidth:x.slice(-1)[0]});(0,b.canUseDOM)()&&this.media(E,function(){h.setState({breakpoint:null})})}}},{key:"componentWillUnmount",value:function(){this._responsiveMediaHandlers.forEach(function(h){k.unregister(h.query,h.handler)})}},{key:"render",value:function(){var h=this,x,E;this.state.breakpoint?(E=this.props.responsive.filter(function(L){return L.breakpoint===h.state.breakpoint}),x=E[0].settings==="unslick"?"unslick":O(O(O({},f.default),this.props),E[0].settings)):x=O(O({},f.default),this.props),x.centerMode&&(x.slidesToScroll>1,x.slidesToScroll=1),x.fade&&(x.slidesToShow>1,x.slidesToScroll>1,x.slidesToShow=1,x.slidesToScroll=1);var P=o.default.Children.toArray(this.props.children);P=P.filter(function(L){return typeof L=="string"?!!L.trim():!!L}),x.variableWidth&&(x.rows>1||x.slidesPerRow>1)&&(console.warn("variableWidth is not supported in case of rows > 1 or slidesPerRow > 1"),x.variableWidth=!1);for(var t=[],q=null,u=0;u<P.length;u+=x.rows*x.slidesPerRow){for(var r=[],l=u;l<u+x.rows*x.slidesPerRow;l+=x.slidesPerRow){for(var m=[],T=l;T<l+x.slidesPerRow&&(x.variableWidth&&P[T].props.style&&(q=P[T].props.style.width),!(T>=P.length));T+=1)m.push(o.default.cloneElement(P[T],{key:100*u+10*l+T,tabIndex:-1,style:{width:"".concat(100/x.slidesPerRow,"%"),display:"inline-block"}}));r.push(o.default.createElement("div",{key:10*u+l},m))}x.variableWidth?t.push(o.default.createElement("div",{key:u,style:{width:q}},r)):t.push(o.default.createElement("div",{key:u},r))}if(x==="unslick"){var N="regular slider "+(this.props.className||"");return o.default.createElement("div",{className:N},P)}else t.length<=x.slidesToShow&&!x.infinite&&(x.unslick=!0);return o.default.createElement(d.InnerSlider,w({style:this.props.style,ref:this.innerSliderRefHandler},(0,b.filterSettings)(x)),t)}}]),S}(o.default.Component)}(Ye)),Ye}var Kr;function Xn(){return Kr||(Kr=1,function(n){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=d(Qn());function d(p){return p&&p.__esModule?p:{default:p}}n.default=o.default}(Xe)),Xe}var Yn=Xn();const ui=Ci(Yn),$n=({clientsList:n})=>{const o={className:"slider variable-width",dots:!1,infinite:!0,slidesToShow:1,slidesToScroll:1,autoplay:!0,speed:2e3,autoplaySpeed:3e3,variableWidth:!0,draggable:!0,swipeToSlide:!0,cssEase:"ease"};return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"text-center",children:e.jsx("span",{className:"fs-2 px-4 py-0",children:"Our Clients We Proudly Served"})}),e.jsx("div",{className:"slider-container",children:e.jsx(ui,{...o,children:n.map(d=>e.jsx(vn,{client:d},d.id))})})]})};A.forwardRef(({item:n,date:o,id:d,dragHandleProps:p,snapshot:f,handleCarouselEdit:b,thumbDelete:g,...C},w)=>e.jsx("li",{ref:w,...C,className:"card p-2 my-2 "+(f.isDragging?"hovering":""),children:e.jsx("div",{...p,children:e.jsxs("div",{className:"row position-reltive",children:[e.jsx("div",{className:"col-8",children:e.jsx("p",{className:"m-0 fw-bold",children:n==null?void 0:n.intro_title})}),e.jsxs("div",{className:"col-4 d-flex justify-content-around align-items-center flex-md-row gap-3",children:[e.jsx(pe,{onClick:j=>b(j,n),children:e.jsx("i",{className:"fa fa-pencil fs-4 text-warning","aria-hidden":"true"})}),e.jsx(pe,{onClick:j=>g(n==null?void 0:n.id,n==null?void 0:n.intro_title),children:e.jsx("i",{className:"fa fa-trash fs-4 text-danger","aria-hidden":"true"})})]})]})})}));A.forwardRef(({children:n,...o},d)=>e.jsx("ul",{ref:d,className:"addresslist",style:{height:"100%"},children:n}));xe.div`
.homeServices .row.service:nth-child(odd) {
  flex-direction: row-reverse;
}


.homeServices {
    position: relative;


    img {
        object-fit: cover;
    }

    h3 {
        font-size: 2rem;
        font-weight: bold;
    }
    .briefIntro h5 {
        font-size: 2.5rem;
        padding-left: 15px;
        border: 0px;
        border-left-width: 15px;
        border-style: solid;
        text-align: left;
    }

    .serviceTitle {
        color: #141414;
        font-size: 40px;

        @media (max-width: 576px) {
            font-size: 2rem;
        }
    }

    .homeServiceImg {
        height: 270px;
        -o-object-fit: contain;
        -o-object-position: center;
    }

    .breiftopMargin .container > div {
        padding: 10px 0 !important;
    }

    
    .row.service {
        background-color: #fff;
        /* box-shadow: 0 .125rem .25rem rgba(0, 0, 0, .075); */
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        border-radius: 8px;
        overflow: hidden;

        h5 {
            font-size: 1.3rem !important;
            color: ${({theme:n})=>n.gray444};
            text-transform: uppercase;
            font-weight: 500 !important;
            margin-bottom: 1rem;
        }

        .ql-editor {
            padding: 0 !important;
        }

        .homeServiceImg {
            padding: 0 !important;
        }

        .homeServiceDetails {
            display: flex;
            flex-direction: column;
            align-items: start;
            justify-content: center;

            .ql-editor .description > *:not(p:first-of-type) {
                display: none;
            }

        }
    }
    .row.service:last-child {
        margin-bottom: 0px !important;
    }

    homeServiceDetails {
        .description {
            p:first-child {
                display: block;
                display: -webkit-box;
                -webkit-line-clamp: 4;
                -webkit-box-orient: vertical;
                overflow: hidden;
            }
        }
    }
}
`;const Jn=xe.div`

.homeDynamciServicesIntro {
  padding: 30px 0;
  background-color:${({theme:n})=>n.lightWhiteF8}; 
  color: ${({theme:n})=>n.textColor};

  .briefIntro {
    .btn {
      border: 0 !important;
      text-decoration: underline;

      &:hover {
        background-color: transparent !important;
      }
    }
  }

  .introDecTitleCss {
    p, p span {
      text-align: left !important;
    }
  }

  .homeDynamciServices {

    .briefIntro {
        position: relative;
        height: 300px;
        max-height: 100%;
        padding: 32px;
        border-bottom: 10px solid rgba(1, 32, 96, .85); 
        background-size: 72px;
        cursor: pointer;
        background-repeat: no-repeat;
        background-position: right 15px bottom;
        transition: border-color 0.4s ease, border-bottom-width 0.3s ease, background-color 0.4s ease;

        @media (max-width: 1023px) {
          padding: 16px;
        }

        &:hover {
            background-color:rgba(0, 0, 0, 0.2);
            border-bottom: 15px solid #FF9D00; 

            * {
            color: #fff;
            }
        }
        
        h5, .quill, a {
          position: relative
        }
        h5 {
            z-index: 2;
            font-weight: 500 !important;
            font-size: 1.6rem !important;
            color: #fff !important;
            hyphens: manual;
            overflow-wrap: break-word; /* optional, for better word breaking */
            word-break: break-word;    /* optional, for better word breaking */
        }

        .quill {
          z-index: 3;

          p, p span {
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 6;
            color: #fff !important;
            
          }

          .description {
            p:not(:first-child) {
              display: none;
            }
          }

          
          }

          a {
            color: #fff;
            z-index: 4;
            font-size: .9rem;
            margin-top: 2rem;
            display: block;
          }
        }

        .briefIntro:after {
          content: "";
          // background: linear-gradient(173deg,rgba(109, 47, 155, 0.9) 1%, rgba(1, 32, 96, .75) 100%);
          background: linear-gradient(135deg,rgba(109, 47, 155, 0.9) 15%, rgba(0, 0, 0, .2) 100%);
          position: absolute;
          top: 0;
          bottom: 0;
          right: 0;
          left: 0;
          z-index: 0;
          color: #fff;
        }
    }
  }


`;xe.div`
    .carousel-caption {
    position: absolute;
    z-index: 999;
    }

    .carousel-caption h1 {
    letter-spacing: 0.3rem;
    }

    @media (max-width: 768px) {
    .banner {
        height: 200px !important;
    }

    .carousel-item img,
    .homeCarousel::after {
        height: 50vh;
    }
    }

    /* .homeCarousel::after {
  content: "";
  display: block;
  background: radial-gradient(
    circle,
    rgba(0, 0, 0, 0) 0%,
    rgba(22, 93, 61, 0.95) 95%
  );
  position: absolute;
  height: 100vh;
  width: 100%;
  top: 0;
} */

.noImg {
  min-height: 300px;
}

.carousel-item {
  overflow: hidden;
  height: 60vh;
  position: relative;
  /* box-shadow: 0 15px 0px #3cd9d2; */
}
.carousel-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.carousel-item::after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(180deg, rgba(0, 0, 0, .95) 0%, rgba(0, 0, 0, .25) 80%);
  z-index: 1;
  pointer-events: none;
}

.carousel-caption {
  /* background-color: rgba(34, 34, 34, .1); */
  position: absolute;
  z-index: 999;
  text-align: right !important;
  bottom: 30%;
  right: 10%;
  /* width: 75%; */
}

.carousel-caption h1 {
  letter-spacing: 0 !important;
  font-weight: 600 !important;
  font-size: 3rem;
  margin: 0px;
  /* font-family: "PT Sans Narrow", sans-serif; */
  /* font-weight: 700 !important; */
  /* font-style: normal; */
  text-shadow: 0px 4px 0 rgba(0,0,0, .3);
  font-family: "Barlow",sans-serif;
}

.subtitle {
  color: #ffffff;
  letter-spacing: .1rem;
  text-transform: uppercase;
  font-weight: normal !important;
  font-family: "Barlow",sans-serif;
}

@media (max-width: 768px) {
  .banner {
    height: 200px !important;
  }
  .carousel-caption {
    width: 70%;
    top: 50%;
  }
  .carousel-caption h1 {
    font-size: 1.6rem;
    font-weight: normal;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
  }

  .carousel-caption span.subtitle {
    display: none;
  }
  .carousel-caption p.description {
    font-size: 0.9rem !important;
    letter-spacing: 0.1rem;
    font-weight: normal;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
  }

  .carousel-item img,
  .homeCarousel::after {
    height: 50vh;
  }

  .homeCarousel::after {
  content: "";
  display: block;
  /* background: radial-gradient(
    circle,
    rgba(0, 0, 0, 0) 0%,
    rgba(22, 93, 61, 0.95) 95%
  ); */
  position: absolute;
  /* height: 65vh; */
  width: 100%;
  top: 0;
}

.carousel-caption {
    h1 { color:${({theme:n})=>n.carouselSlideTitleColor};     }
    p { color:${({theme:n})=>n.carouselSlideCaptionColor}; }
}

.homeMultyPurposeCarousel {
  /* background-color: rgba(34, 34, 34, .1); */
  position: relative;

  .container {
    background-color: rgba(34, 34, 34, 0.1);
  }

  .carousel-indicators {
    display: none;
    button {
      width: 16px;
    }
  }

  .carousel-control-prev,
  .carousel-control-next {
    top: 24px !important;
    align-items: start;
    opacity: 0.7 !important;

    @media (max-width: 480px) {
      top: -16px !important;
    }
  }

  .carousel-control-prev {
    left: 88% !important;

    @media (min-width: 421px) and (max-width: 991px) {
      left: 78% !important;
    }

    @media (max-width: 480px) {
      left: 65% !important;
    }
  }

  .carousel-control-prev-icon,
  .carousel-control-next-icon {
    padding: 12px;
    background-color: #222;
    border-radius: 4px;
    display: inline-block;
    background-size: 60%;
  }

  .carouselImg,
  .carouselDescription {
    height: 500px;

    @media (max-width: 480px) {
      height: auto;
    }
  }
  .carouselImg img {
    height: 100%;
    object-fit: cover;
  }

  .carouselDescription {
    padding: 0 80px;

    @media (max-width: 820px) {
      padding: 32px;
    }

    h1 {
      font-size: 32px;
      color: #222;
    }
    span {
      color: #6d2f9b;
    }
  }
}
}

`;const ea=({item:n,index:o})=>{const[d,p]=A.useState(!1),f=g=>{p(!0)},b=g=>{p(!1)};return e.jsxs("div",{onMouseEnter:f,onMouseLeave:b,children:[e.jsx("img",{src:Re(n.path),alt:n.alternitivetext,className:"d-block w-100"}),e.jsx("div",{className:"carousel-caption ",children:n.carouse_title&&e.jsx("h1",{className:"fw-bold my-4",children:n.carouse_title})}),e.jsx(Oi,{data:n==null?void 0:n.carouse_description,showMorelink:!1})]},n.id)},ta=({carouselState:n,category:o})=>{const{isLoading:d}=Se(g=>g.loader),[p,f]=A.useState([]),b={className:"slider variable-width",dots:!1,infinite:!0,slidesToShow:1,slidesToScroll:1,autoplay:!0,speed:2e3,autoplaySpeed:3e3,variableWidth:!0,draggable:!0,swipeToSlide:!0,cssEase:"ease"};return A.useEffect(()=>{n||(async()=>{try{const C=await ye.get(`carousel/clientCarousel/${o}/`);if((C==null?void 0:C.status)===200){let w=Object.keys(C.data);const j=Ie(C.data[w],"carouse_position");f(j)}}catch{console.log("unable to access ulr because of server is down")}})()},[n]),e.jsxs("div",{className:"",children:[d?e.jsx(ri,{}):"",e.jsx("div",{className:"slider-container",children:e.jsx(ui,{...b,children:p.map((g,C)=>e.jsx(ea,{item:g,index:C},g.id))})}),p.length===0&&e.jsx("div",{className:"d-flex justify-content-center align-items-center fs-5 text-muted text-center noImg",children:!d&&e.jsx("p",{children:"Please add images for Carousel..."})})]})},ra=xe.div`
    .homeBrochure {
        .floatingButton {
            position: fixed;
            top: 600px;
            right: 0;
            z-index: 99999;
            transition: top 0.4s ease;

            @media(max-width: 1023px) {
                top: 600px;
            }

            @media(max-width: 480px) {
                top: 400px;
            }

            img {
                width: 68px;
            }

            button:not(.modal button) {
                border-top-right-radius: 0px !important;
                border-bottom-right-radius: 0px !important;
            }

            button.btn.btn-primary {
                background-color: #6D2F9B;
                box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15) !important;
                // background: radial-gradient(circle,rgba(109, 47, 155, 0.89) 1%, rgba(0, 0, 0, 1) 100%);
                // background-color: #012060;
            }

            button {
                i {
                    font-size: 24px;
                    margin-right:8px
                }

                @media(max-width: 768px) {
                    padding: 10px !important;

                    i {
                        margin-right:0
                    }
                    span {
                        display: none;
                    }
                }
            }

            ul.dropdown-menu {
                max-width: 300px;
                width: 300px;
                border-top-right-radius: 0;
                top: -8px !important;

                li {
                    padding: 12px 24px;
                    border-bottom: 1px solid #ddd;

                    &:last-child {
                        border: 0;
                    }
                }
            }

            .modal {
                z-index: 99999;
            }
        }

        .floatingButton.scrolled {
            top: 100px;     /* On scroll position */

            span {
                display: none;
            }

            button:not(.modal button) {
                padding: 10px !important;
                i {
                margin-right:0px
            }
            }
        }
}


`,xa=()=>{var T,N,L,M,I,U,W,K,re,ee,Q,F,$,le,H,ne,oe,se,ce,be,Ce,Te,je,Ae,me,we,ut,dt,ft,vt,ht,pt,mt,bt,gt,yt,xt,St,jt,wt,Ct,Ot,Nt,kt,Tt,Pt,Mt,_t,Et,Lt,It,Rt,Dt,At,zt,Bt,Vt,Ht,Ft,qt,Ut,Wt,Zt,Kt,Gt,Qt,Xt,Yt,$t,Jt,er,tr,rr,ir,nr,ar,lr,or,sr,cr,ur,dr,fr,vr,hr,pr,mr,br,gr,yr,xr,Sr,jr;const n={carousel:!1,briefIntro:!1,homeServicebriefIntro:!1,projects:!1,projectsBrief:!1,testmonial:!1,serviceOffered:!1,product_development:!1,product_distribution:!1,iconsHelightsBrief:!1,projectbriefIntro:!1,homeService0:!1,homeService1:!1,homeService2:!1,homeService3:!1,homeService4:!1,homeService5:!1,homeDynamciServices:!1,homeDynamciServicesBrief:!1},o={product_development:"product_development",product_distribution:"product_distribution",product_registration:"product_registration"},[d,p]=A.useState(0),f="home",b="serviceOffered",[g,C]=A.useState([]),{isAdmin:w,hasPermission:j}=Yr(),[O,z]=A.useState(n),[Y,Z]=A.useState(!1),[X,_]=A.useState([]),[B,D]=A.useState([]),[V,J]=A.useState([]),{categories:G}=Se(te=>te.categoryList),{isLoading:s}=Se(te=>te.loader);A.useRef(!0);const[v,y]=A.useState(""),[k,c]=A.useState(""),[a,S]=A.useState(""),[i,h]=A.useState([]),{serviceMenu:x}=Se(te=>te.serviceMenu),{homeIntroList:E}=Se(te=>te.homeIntroList),P=ti(),t=(te,ie)=>{z(ue=>({...ue,[te]:ie})),Z(ie),document.body.style.overflow="hidden"},q=te=>{if((te==null?void 0:te.results.length)>0){const ie=ei(te.results[0]),ue=Ie(te.results,ie);_(ue.slice(0,4))}else _([])};A.useEffect(()=>{E.length==0&&P(Ni())},[E==null?void 0:E.length]),A.useEffect(()=>{const te=async()=>{G.map(ue=>ue.id);const ie=[];G.forEach((ue,wr)=>{ie.push(ye.get(`/products/getClinetProduct/${ue.id}/`))}),await Promise.all(ie).then(function(ue){const wr=Ei(ue,G);J(wr)})};(G==null?void 0:G.length)>0&&(V==null?void 0:V.length)===0&&te()},[G]),A.useEffect(()=>{ki(),P(Ti())},[]),A.useEffect(()=>{const te=async()=>{try{const ie=await ye.get("/testimonials/clientTestimonials/");if((ie==null?void 0:ie.status)===200){const ue=Ie(ie.data.results,"testimonial_position");C(ue)}}catch{console.log("unable to access ulr because of server is down")}};O.testmonial||te()},[O.testmonial]),A.useEffect(()=>{(async()=>{try{const ie=await ye.get("/client/getAllClientLogos/");if((ie==null?void 0:ie.status)===200){const ue=Ie(ie.data.clientLogo,"client_position");D(ue)}}catch{console.log("unable to access ulr because of server is down")}})()},[]),A.useEffect(()=>{window.scrollTo(0,0)},[]);const{error:u,success:r,showHideList:l}=Se(te=>te.showHide);A.useEffect(()=>{l.length>0&&h(Pi(l))},[l]);const m=async(te,ie)=>{if(te)P(Li(te));else{const ue={componentName:ie.toLowerCase(),pageType:f};P(Ii(ue))}};return e.jsx(e.Fragment,{children:e.jsxs("div",{className:"container-fluid p-0",children:[e.jsx(ra,{children:e.jsx("div",{className:"homeBrochure",children:e.jsx(Wi,{})})}),e.jsxs("div",{className:(T=i==null?void 0:i.carousel)!=null&&T.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(N=i==null?void 0:i.carousel)==null?void 0:N.visibility,title:"Carousel",componentName:"carousel",showHideHandler:m,id:(L=i==null?void 0:i.carousel)==null?void 0:L.id}),((M=i==null?void 0:i.carousel)==null?void 0:M.visibility)&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"container-fluid",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 p-0 carousel",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("carousel",!0)}),e.jsx(Nr,{carouselState:O.carousel,category:"carousel"})]})})}),O.carousel&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Be,{editHandler:t,componentType:"carousel",popupTitle:"Carousel Banners",getImageListURL:"carousel/createCarousel/carousel/",deleteImageURL:"carousel/updateCarousel/",imagePostURL:"carousel/createCarousel/carousel/",imageUpdateURL:"carousel/updateCarousel/",imageIndexURL:"carousel/updateCarouselindex/",imageLabel:"Add Carousel Image",showDescription:!1,showExtraFormFields:Or("carousel"),dimensions:ge("carousel")})})]})]}),e.jsxs("div",{className:(I=i==null?void 0:i.briefintro)!=null&&I.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(U=i==null?void 0:i.briefintro)==null?void 0:U.visibility,title:"A Brief Introduction Component",componentName:"briefintro",showHideHandler:m,id:(W=i==null?void 0:i.briefintro)==null?void 0:W.id}),((K=i==null?void 0:i.briefintro)==null?void 0:K.visibility)&&e.jsxs("div",{children:[e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"breiftopMargin",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("briefIntro",!0)}),e.jsx(Pe,{introState:O.briefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"fs-3 text-center mb-3",introSubTitleCss:"fw-medium fs-5 text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center lh-6",detailsContainerCss:"col-md-12 py-2 text-center",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:f})]})})}),O.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ze,{editHandler:t,componentType:"briefIntro",popupTitle:"Brief Intro Banner",pageType:"Home"})})]})]}),e.jsxs("div",{className:(re=i==null?void 0:i.homedynamciservicesbrief)!=null&&re.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(ee=i==null?void 0:i.homedynamciservicesbrief)==null?void 0:ee.visibility,title:"Dynamci Services Brief",componentName:"homedynamciservicesbrief",showHideHandler:m,id:(Q=i==null?void 0:i.homedynamciservicesbrief)==null?void 0:Q.id}),((F=i==null?void 0:i.homedynamciservicesbrief)==null?void 0:F.visibility)&&e.jsx(Jn,{children:e.jsxs("div",{className:"homeDynamciServicesIntro",children:[e.jsx("div",{className:"container",children:e.jsxs("div",{className:"breiftopMargin",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("homeDynamciServicesBrief",!0)}),e.jsx(Pe,{introState:O.homeDynamciServicesBrief,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"mb-0",introSubTitleCss:"fw-medium text-muted text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center",detailsContainerCss:"col-md-12",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:"homeDynamciServicesBrief",maxHeight:"300"}),O.homeDynamciServicesBrief&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ze,{editHandler:t,componentType:"homeDynamciServicesBrief",popupTitle:"Brief Intro Banner",pageType:"homeDynamciServicesBrief"})})]})}),e.jsxs("div",{className:"container homeDynamciServices",children:[e.jsx("div",{className:"row",children:e.jsx(kr,{})}),e.jsx("div",{className:"text-center text-md-end",children:e.jsx(He,{AncherLabel:"View All Services",Ancherpath:"/all-serivces",AncherClass:"mt-4 d-block",AnchersvgColor:"#ffffff"})})]})]})})]}),e.jsxs("div",{className:($=i==null?void 0:i.iconshelightsbrief)!=null&&$.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(le=i==null?void 0:i.iconshelightsbrief)==null?void 0:le.visibility,title:"Icons Brief",componentName:"iconshelightsbrief",showHideHandler:m,id:(H=i==null?void 0:i.iconshelightsbrief)==null?void 0:H.id}),((ne=i==null?void 0:i.iconshelightsbrief)==null?void 0:ne.visibility)&&e.jsx("div",{className:"homeBriefheilights",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"breiftopMargin",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("iconsHelightsBrief",!0)}),e.jsx(Pe,{introState:O.iconsHelightsBrief,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"fs-3 fw-bold text-center mb-4",introSubTitleCss:"fw-medium text-muted text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center lh-6",detailsContainerCss:"col-md-12 py-3",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:"iconsHelightsBrief"}),O.iconsHelightsBrief&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ze,{editHandler:t,componentType:"iconsHelightsBrief",popupTitle:"Brief Intro Banner",pageType:"iconsHelightsBrief"})})]})})})})]}),e.jsxs("div",{className:(oe=i==null?void 0:i.homeprojectcarousel)!=null&&oe.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(se=i==null?void 0:i.homeprojectcarousel)==null?void 0:se.visibility,title:"Home Project Carousel",componentName:"homeprojectcarousel",showHideHandler:m,id:(ce=i==null?void 0:i.homeprojectcarousel)==null?void 0:ce.id}),((be=i==null?void 0:i.homeprojectcarousel)==null?void 0:be.visibility)&&e.jsx(mn,{})]}),e.jsxs("div",{className:(Ce=i==null?void 0:i.homeclient)!=null&&Ce.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(Te=i==null?void 0:i.homeclient)==null?void 0:Te.visibility,title:"Home Client",componentName:"homeclient",showHideHandler:m,id:(je=i==null?void 0:i.homeclient)==null?void 0:je.id}),((Ae=i==null?void 0:i.homeclient)==null?void 0:Ae.visibility)&&e.jsx(ln,{children:e.jsx($n,{clientsList:B})})]}),e.jsxs("div",{className:(me=i==null?void 0:i.banner)!=null&&me.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(we=i==null?void 0:i.banner)==null?void 0:we.visibility,title:"Only Banner",componentName:"banner",showHideHandler:m,id:(ut=i==null?void 0:i.banner)==null?void 0:ut.id}),((dt=i==null?void 0:i.banner)==null?void 0:dt.visibility)&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 p-0 position-relative homePage",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("banner",!0)}),e.jsx(Ai,{getBannerAPIURL:`banner/clientBannerIntro/${f}-banner/`,bannerState:O.banner})]})}),O.banner&&e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx($r,{editHandler:t,componentType:"banner",pageType:`${f}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:Jr(`${f}-banner`),dimensions:ge("banner")})})]})]}),e.jsxs("div",{className:(ft=i==null?void 0:i.industriesweserve)!=null&&ft.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(vt=i==null?void 0:i.industriesweserve)==null?void 0:vt.visibility,title:"Industries We Serve",componentName:"industriesweserve",showHideHandler:m,id:(ht=i==null?void 0:i.industriesweserve)==null?void 0:ht.id}),((pt=i==null?void 0:i.industriesweserve)==null?void 0:pt.visibility)&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"container-fluid",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 p-0 carousel",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("industriesweserve",!0)}),e.jsx(ta,{carouselState:O.industriesweserve,category:"industriesweserve"})]})})}),O.industriesweserve&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Be,{editHandler:t,componentType:"industriesweserve",popupTitle:"Industries We Serve",getImageListURL:"carousel/createCarousel/industriesweserve/",deleteImageURL:"carousel/updateCarousel/",imagePostURL:"carousel/createCarousel/industriesweserve/",imageUpdateURL:"carousel/updateCarousel/",imageIndexURL:"carousel/updateCarouselindex/",imageLabel:"industries we serve",showDescription:!1,showExtraFormFields:Or("industriesweserve"),dimensions:ge("carousel")})})]})]}),e.jsxs("div",{className:(mt=i==null?void 0:i.producthilight)!=null&&mt.visibility&&w&&j?"border border-info mb-2":"",style:(bt=i==null?void 0:i.producthilight)!=null&&bt.visibility?{height:"160px"}:{},children:[w&&j&&e.jsx(ae,{showhideStatus:(gt=i==null?void 0:i.producthilight)==null?void 0:gt.visibility,title:"Product highlight",componentName:"producthilight",showHideHandler:m,id:(yt=i==null?void 0:i.producthilight)==null?void 0:yt.id}),((xt=i==null?void 0:i.producthilight)==null?void 0:xt.visibility)&&e.jsx(un,{children:e.jsx("div",{className:"container position-relative d-none d-md-block",children:e.jsxs("div",{className:"row rounded-3 overflow-hidden position-absolute hiligntsContainer",children:[e.jsx("div",{className:"col-sm-4 p-4 p-lg-5 py-lg-4 ",children:e.jsxs("div",{className:"position-relative",children:[w&&j&&e.jsx(fe,{editHandler:()=>t(o.product_development,!0)}),e.jsx(Ge,{formgetURL:`/carousel/clientHomeIntro/${o.product_development}/`,componentEdit:O.product_development,setFormValues:y,formvalues:v}),O.product_development&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Qe,{editHandler:t,componentType:o.product_development,componentTitle:"Product Development component",formPostURL:"/carousel/createHomeIntro/",formUpdateURL:"/carousel/updateHomeIntro/",editObject:v,dynamicFormFields:Ke(o.product_development)})})]})}),e.jsx("div",{className:"col-sm-4 p-4 p-lg-5 py-lg-4 ",children:e.jsxs("div",{className:"position-relative",children:[w&&j&&e.jsx(fe,{editHandler:()=>t(o.product_distribution,!0)}),e.jsx(Ge,{formgetURL:`/carousel/clientHomeIntro/${o.product_distribution}/`,componentEdit:O.product_distribution,setFormValues:c,formvalues:k}),O.product_distribution&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Qe,{editHandler:t,componentType:o.product_distribution,componentTitle:"Product Distribution component",formPostURL:"/carousel/createHomeIntro/",formUpdateURL:"/carousel/updateHomeIntro/",editObject:k,dynamicFormFields:Ke(o.product_distribution)})})]})}),e.jsx("div",{className:"col-sm-4 p-4 p-lg-5 py-lg-4 ",children:e.jsxs("div",{className:"position-relative",children:[w&&j&&e.jsx(fe,{editHandler:()=>t(o.product_registration,!0)}),e.jsx(Ge,{formgetURL:`/carousel/clientHomeIntro/${o.product_registration}/`,componentEdit:O.product_registration,setFormValues:S,formvalues:a}),O.product_registration&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Qe,{editHandler:t,componentType:o.product_registration,componentTitle:"Product Distribution component",formPostURL:"/carousel/createHomeIntro/",formUpdateURL:"/carousel/updateHomeIntro/",editObject:a,dynamicFormFields:Ke(o.product_registration)})})]})})]})})})]}),e.jsxs("div",{className:(St=i==null?void 0:i.services)!=null&&St.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(jt=i==null?void 0:i.services)==null?void 0:jt.visibility,title:"Service",componentName:"services",showHideHandler:m,id:(wt=i==null?void 0:i.services)==null?void 0:wt.id}),((Ct=i==null?void 0:i.services)==null?void 0:Ct.visibility)&&e.jsxs(Ri,{children:[e.jsx("h1",{className:"fs-1 fw-bold text-center text-uppercase",children:"Services"}),e.jsxs("div",{className:"container-lg mx-0 mx-md-0 px-md-0 mx-lg-auto randomServices",children:[e.jsx("div",{className:"row",children:e.jsx(Ve,{col1:"col-md-6 ps-sm-0",col2:"col-md-6 p-4 p-md-5 d-flex justify-content-center align-items-start flex-column",cssClass:"fs-3 mb-3 fw-bolder title",imageClass:"w-100 object-fit-cover imgStylingLeft shadow",dimensions:ge("whoweare"),pageType:"productPortfolio",componentFlip:!1})}),e.jsx("div",{className:"row d-flex flex-row-reverse my-3 my-md-5",children:e.jsx(Ve,{col1:"col-md-6 pe-sm-0",col2:"col-md-6 p-4 p-md-5 d-flex justify-content-center align-items-start flex-column",cssClass:"fs-3 mb-3 fw-bolder title",imageClass:"w-100 object-fit-cover imgStylingRight shadow imgStyling",dimensions:ge("whoweare"),pageType:"promoting",componentFlip:!1})}),e.jsx("div",{className:"row",children:e.jsx(Ve,{col1:"col-md-6 ps-sm-0",col2:"col-md-6 p-4 p-md-5 d-flex justify-content-center align-items-start flex-column",cssClass:"fs-3 mb-3 fw-bolder title",imageClass:"w-100 object-fit-cover imgStylingLeft shadow",dimensions:ge("whoweare"),pageType:"whatwedo",componentFlip:!1})})]})]})]}),e.jsxs("div",{className:(Ot=i==null?void 0:i.homeproducts)!=null&&Ot.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(Nt=i==null?void 0:i.homeproducts)==null?void 0:Nt.visibility,title:"Home Products",componentName:"homeproducts",showHideHandler:m,id:(kt=i==null?void 0:i.homeproducts)==null?void 0:kt.id}),((Tt=i==null?void 0:i.homeproducts)==null?void 0:Tt.visibility)&&e.jsxs("div",{className:"container",children:[e.jsx(he,{title:"Products",cssClass:"fs-1 fw-bold text-center my-5 pt-0 pt-md-5 text-uppercase"}),e.jsx("div",{className:"row",children:V.map(te=>{var ie;return((ie=te==null?void 0:te.products)==null?void 0:ie.length)>0&&e.jsx("div",{children:e.jsx(Vi,{item:te.products[0],categoryId:te.id})},te.id)})})]})]}),e.jsxs("div",{className:(Pt=i==null?void 0:i.testimonis)!=null&&Pt.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(Mt=i==null?void 0:i.testimonis)==null?void 0:Mt.visibility,title:"Testimonials",componentName:"testimonis",showHideHandler:m,id:(_t=i==null?void 0:i.testimonis)==null?void 0:_t.id}),((Et=i==null?void 0:i.testimonis)==null?void 0:Et.visibility)&&e.jsx(dn,{children:e.jsxs("div",{className:"container-fluid",children:[e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-12",children:e.jsx(he,{title:"Testimonials",cssClass:"fs-1 fw-bold text-center my-5 text-uppercase"})})}),e.jsxs("div",{className:"row",children:[e.jsxs("div",{className:"col-md-12 testimonials text-center",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("testmonial",!0)}),g.length<1?(g.length,"No Testimonials Found"):g.length===1?e.jsx("h4",{children:"Please add 2 or more testimonials."}):g.length>1?e.jsx(Zi,{testimonis:g}):""]}),O.testmonial&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Be,{editHandler:t,componentType:"testmonial",popupTitle:"Testmonial Banner",getImageListURL:"testimonials/clientTestimonials/",deleteImageURL:"testimonials/updateTestimonials/",imagePostURL:"testimonials/createTestimonials/",imageUpdateURL:"testimonials/updateTestimonials/",imageIndexURL:"testimonials/updateTestimonialsindex/",imageLabel:"Add your Image",titleTitle:"Testmonial Name",descriptionTitle:"Testimonial Writeup ",showDescription:!1,showExtraFormFields:Mi("testmonial"),dimensions:ge("testimonial")})})]})]})})]}),e.jsxs("div",{className:(Lt=i==null?void 0:i.productslist)!=null&&Lt.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(It=i==null?void 0:i.productslist)==null?void 0:It.visibility,title:"Product Details",componentName:"productslist",showHideHandler:m,id:(Rt=i==null?void 0:i.productslist)==null?void 0:Rt.id}),((Dt=i==null?void 0:i.productslist)==null?void 0:Dt.visibility)&&e.jsx(fn,{children:e.jsxs("div",{className:"container py-5 randomServices",children:[e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6",children:e.jsx("img",{src:on,alt:"",className:"w-100 shadow"})}),e.jsxs("div",{className:"col-md-6 p-3 p-md-5 d-flex flex-column justify-content-center",children:[e.jsx(he,{title:"Product portfolio",cssClass:"text-black fs-3 fw-medium"}),e.jsx("p",{children:"Through our relentless pursuit of quality and innovation, we have achieved several milestones that highlight our success in the healthcare industry."}),e.jsx(pe,{to:"",className:"moreLink",children:"More..."})]})]}),e.jsxs("div",{className:"row my-2 my-md-5 d-flex flex-row flex-md-row-reverse",children:[e.jsx("div",{className:"col-md-6",children:e.jsx("img",{src:sn,alt:"",className:"w-100 shadow"})}),e.jsxs("div",{className:"col-md-6 p-3 p-md-5 d-flex flex-column justify-content-center",children:[e.jsx(he,{title:"Promoting healt and well being",cssClass:"text-black fs-3 fw-medium"}),e.jsx("p",{children:"Through our relentless pursuit of quality and innovation, we have achieved several milestones that highlight our success in the healthcare industry."}),e.jsx(pe,{to:"",className:"moreLink",children:"More..."})]})]}),e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6",children:e.jsx("img",{src:cn,alt:"",className:"w-100 shadow"})}),e.jsxs("div",{className:"col-md-6 p-3 p-md-5 d-flex flex-column justify-content-center",children:[e.jsx(he,{title:"What we do",cssClass:"text-black fs-3 fw-medium"}),e.jsx("p",{children:"Through our relentless pursuit of quality and innovation, we have achieved several milestones that highlight our success in the healthcare industry."}),e.jsx(pe,{to:"",className:"moreLink",children:"More..."})]})]})]})})]}),e.jsxs("div",{className:(At=i==null?void 0:i.news)!=null&&At.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(zt=i==null?void 0:i.news)==null?void 0:zt.visibility,title:"News",componentName:"news",showHideHandler:m,id:(Bt=i==null?void 0:i.news)==null?void 0:Bt.id}),((Vt=i==null?void 0:i.news)==null?void 0:Vt.visibility)&&e.jsx("div",{className:"row py-5 homeNews",children:e.jsx("div",{className:"col-md-12 d-flex justify-content-center align-items-center",children:e.jsxs("div",{className:"container",children:[e.jsx(he,{title:"News",cssClass:"fs-1 fw-bold text-center my-5 pt-0 pt-md-5 text-uppercase"}),e.jsx(Di,{news:X,setNews:q,pagetype:f}),e.jsx("div",{className:"d-flex justify-content-center align-items-center mt-4",children:e.jsx(He,{AncherLabel:"View more news articles",Ancherpath:"/news",AncherClass:"btn btn-outline d-flex justify-content-center align-items-center ",AnchersvgColor:"#17427C"})})]})})})]}),e.jsxs("div",{className:(Ht=i==null?void 0:i.news)!=null&&Ht.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(Ft=i==null?void 0:i.homeservices)==null?void 0:Ft.visibility,title:"Home Service",componentName:"homeservices",showHideHandler:m,id:(qt=i==null?void 0:i.homeservices)==null?void 0:qt.id}),((Ut=i==null?void 0:i.homeservices)==null?void 0:Ut.visibility)&&e.jsxs("div",{className:"container py-5 homeServices",children:[e.jsx("h2",{className:"mb-5",children:"What We Do"}),e.jsx(kr,{})]})]}),e.jsxs("div",{className:(Wt=i==null?void 0:i.features)!=null&&Wt.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(Zt=i==null?void 0:i.features)==null?void 0:Zt.visibility,title:"Features",componentName:"features",showHideHandler:m,id:(Kt=i==null?void 0:i.features)==null?void 0:Kt.id}),((Gt=i==null?void 0:i.features)==null?void 0:Gt.visibility)&&e.jsx(nn,{})]}),e.jsxs("div",{className:(Qt=i==null?void 0:i.news)!=null&&Qt.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(Xt=i==null?void 0:i.whoweare)==null?void 0:Xt.visibility,title:"Who we are",componentName:"whoweare",showHideHandler:m,id:(Yt=i==null?void 0:i.whoweare)==null?void 0:Yt.id}),(($t=i==null?void 0:i.whoweare)==null?void 0:$t.visibility)&&e.jsx("div",{className:"row ABriefAbout mb-5",children:e.jsx(Ve,{cssClass:"mb-2 fw-bold title text-black",dimensions:ge("whoweare")})})]}),e.jsxs("div",{className:(Jt=i==null?void 0:i.homeservicedetails)!=null&&Jt.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(er=i==null?void 0:i.homeservicedetails)==null?void 0:er.visibility,title:"Services Details",componentName:"homeservicedetails",showHideHandler:m,id:(tr=i==null?void 0:i.homeservicedetails)==null?void 0:tr.id}),((rr=i==null?void 0:i.homeservicedetails)==null?void 0:rr.visibility)&&e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-12 ABrief",children:e.jsx(Ki,{cssClass:"fw-bold title",dimensions:ge("homeCareers")})})})]}),e.jsxs("div",{className:(ir=i==null?void 0:i.homecareers)!=null&&ir.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(nr=i==null?void 0:i.homecareers)==null?void 0:nr.visibility,title:"Careers",componentName:"homecareers",showHideHandler:m,id:(ar=i==null?void 0:i.homecareers)==null?void 0:ar.id}),((lr=i==null?void 0:i.homecareers)==null?void 0:lr.visibility)&&e.jsxs("div",{className:"row homeCareers py-5",children:[e.jsx("div",{className:"col-lg-6"}),e.jsxs("div",{className:"col-md-12 col-lg-6 pe-lg-5",children:[e.jsx(Pe,{introState:O.briefIntro,pageType:"careers",introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center"}),e.jsx("div",{className:"bg-white px-5 pb-4 d-flex justify-content-center align-items-center",children:e.jsx(He,{AncherLabel:"Careers",Ancherpath:"/profile/careers",AncherClass:"btn btn-primary d-flex justify-content-center align-items-center gap-3 w-50",AnchersvgColor:"#ffffff"})})]})]})]}),e.jsxs("div",{className:(or=i==null?void 0:i.gallery)!=null&&or.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(sr=i==null?void 0:i.gallery)==null?void 0:sr.visibility,title:"Gallery",componentName:"gallery",showHideHandler:m,id:(cr=i==null?void 0:i.gallery)==null?void 0:cr.id}),((ur=i==null?void 0:i.gallery)==null?void 0:ur.visibility)&&e.jsxs(Bi,{children:[e.jsx("div",{className:"text-center mb-5",style:{marginTop:"100px"},children:e.jsx("span",{className:"fs-1 px-4 py-2",style:{borderBottom:"1px solid #444444"},children:"View Gallery"})}),e.jsx("div",{className:"row ",children:e.jsx("div",{className:"col-md-10 offset-md-1 homeGalleryCarousel",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-10 offset-md-1",children:e.jsx(Nr,{carouselState:O.carousel})})})})})}),e.jsx("div",{className:"text-center py-4 position-relative ",style:{marginTop:"200px"},children:e.jsx(pe,{to:"/imageGallery",className:"btn btn-outline",children:"View All"})})]})]}),e.jsxs("div",{className:(dr=i==null?void 0:i.servicesoffered)!=null&&dr.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(fr=i==null?void 0:i.servicesoffered)==null?void 0:fr.visibility,title:"Services Offered",componentName:"servicesoffered",showHideHandler:m,id:(vr=i==null?void 0:i.servicesoffered)==null?void 0:vr.id}),((hr=i==null?void 0:i.servicesoffered)==null?void 0:hr.visibility)&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"text-center mb-5",style:{marginTop:"100px"},children:e.jsx("span",{className:"fs-1 px-4 py-2",style:{borderBottom:"1px solid #444444"},children:"Services Offered"})}),e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 carousel",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("serviceOffered",!0)}),e.jsx(Qi,{getBannerAPIURL:`carousel/clientCarouselbyCategory/${b}/`,componentEdit:O})]})}),O.serviceOffered&&e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(Be,{editHandler:t,componentType:"serviceOffered",getImageListURL:`carousel/getCarousel/${b}/`,deleteImageURL:"carousel/updateCarousel/",imagePostURL:"carousel/createCarousel/",imageUpdateURL:"carousel/updateCarousel/",imageIndexURL:"carousel/updateCarouselindex/",imageLabel:"Add Images",showDescription:!1,showExtraFormFields:_i(b),dimensions:ge("carousel")})})]})]}),e.jsxs("div",{className:(pr=i==null?void 0:i.hprinfra)!=null&&pr.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(mr=i==null?void 0:i.hprinfra)==null?void 0:mr.visibility,title:"Projects",componentName:"hprinfra",showHideHandler:m,id:(br=i==null?void 0:i.hprinfra)==null?void 0:br.id}),((gr=i==null?void 0:i.hprinfra)==null?void 0:gr.visibility)&&e.jsx(hn,{})]}),e.jsxs("div",{className:(yr=i==null?void 0:i.projectsbrief)!=null&&yr.visibility&&w&&j?"border border-info mb-2":"",children:[w&&j&&e.jsx(ae,{showhideStatus:(xr=i==null?void 0:i.projectsbrief)==null?void 0:xr.visibility,title:"Projects Brief",componentName:"projectsbrief",showHideHandler:m,id:(Sr=i==null?void 0:i.projectsbrief)==null?void 0:Sr.id}),((jr=i==null?void 0:i.projectsbrief)==null?void 0:jr.visibility)&&e.jsxs("div",{className:"homeProjectsInfo",children:[e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"breiftopMargin",children:[w&&j&&e.jsx(fe,{editHandler:()=>t("projectsBrief",!0)}),e.jsx(Pe,{introState:O.projectsBrief,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"fs-3 fw-bold text-center mb-4",introSubTitleCss:"fw-medium text-muted text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center lh-6",detailsContainerCss:"col-md-12 py-3",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:"projectsBrief"})]})})}),O.projectsBrief&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ze,{editHandler:t,componentType:"projectsBrief",popupTitle:"Brief Intro Banner",pageType:"projectsBrief"})})]})]}),Y&&e.jsx(Ue,{})]})})};export{xa as default};
